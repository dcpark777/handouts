# kubeflow-utils — transfer handoff (v0.5)

Plain-Python pipelines that run on a laptop and on KFP. Two decorators;
code identical everywhere; behavior via per-environment config; secrets
fetched at run start and exported as environment variables. Import name
`kubeflow_utils`; dist `kubeflow-utils`; console script `kfu`.

## Contents
- `package/` — `uv pip install -e ".[dev]"`, 22 tests (all passing),
  core deps fsspec + pyyaml, lazy extras `[sql]` `[spark]` `[snowflake]`.
- `example-repo/` — the authoring reference (read README.md there first).

## The design in seven lines
1. `@step` on plain functions (string paths + scalars). Marks a component.
   No arguments — behavior lives in config.
2. `@pipeline` on a run script: calls steps in order. Datasets and the run
   key are INPUTS of the function. Callable directly in a notebook; the
   framework records it (calls it once with probe values, steps record
   instead of running) to learn its structure.
3. `pipelines/kfp.yaml` = cluster runtime: BAKED keys (cpu, memory, image,
   retries, parallel — compiled once, cannot vary by env) + values uat and
   prod share. NOT an environment.
4. `pipelines/environments/{local,uat,prod}.yaml` = exactly the valid
   `--env` values. local is complete; uat/prod are deltas over kfp.yaml.
   Sections: params (template variables), datasets (the ONLY templated
   section; "{name}" must be an input or a param), settings (->
   KUBEFLOW_UTILS_* env vars; never secrets), secrets (references, fetched
   at run start, exported as env vars), steps (skip_if_exists, spark), only.
5. Run key: `snap_date: str = "today"` in the signature. Resolved ONCE per
   run (framework's first component on KFP; in-process locally); passed
   explicitly for backfills/notebooks. Never computed by a user step.
6. Runner (same code local and in-container): resolve sentinels -> load
   config -> fetch secrets not already in env, export, mint OAUTH_TOKEN ->
   format datasets -> record calls -> per step: skip if configured and all
   dataset args exist; run under that step's spark conf; refuse non-None
   returns; every dataset arg must exist afterwards.
7. Commands: `kfu run|check|compile|submit <pipeline>`; compile once;
   `submit --env prod` resolves "today" and submits with env as an input.

## Enforced (all tested)
value-passing between steps refused; branching around steps refused;
baked key in an env file refused; `--env kfp` refused; uat/prod must set
the same keys; placeholder not an input/param refused; secret-shaped
settings key refused; unknown step names refused; env-valued inputs cannot
be overridden at run time; step that doesn't write its dataset args fails;
undecorated function in a steps module flagged; os.path / os.environ lints;
"today" resolved once; skip on rerun; `only`; secrets fetched + exported +
token minted; the resolve component writes dates; datasets/params are NOT
compile inputs; kfp.yaml layout differs from local layout by design.

## Deliberately not in the package
reads/writes contracts (no named pre-checks — a missing input fails inside
the step), a `notebook` runtime (== local), dynamic per-env resources (KFP
lacks it), computed defaults beyond today/yesterday, a local orchestrator
beyond sequential (parallel is baked for KFP only), base+overlay for local.
RULE: nothing gets added until a real migration demands it.

## Work-machine TODO (in order)
1. Bind `kubeflow_utils/lake_broker.py` (seven callables incl. fetch_secret)
   to the platform — adapt from the shared stage-utils package's utils/.
2. Implement `to_kfp()` (compile.py; contract in its docstring) against the
   existing inline compiler; then `kfu submit` against the platform submit API.
3. Confirm `kfp.local` availability — if present, consider delegating
   `kfu run --env uat` parity checks to it.
4. Validate staging/production-lake DataStore branches on real locations.
5. Migrate the first real pipeline. Then, and only then, decide what's missing.

Scrub gate (run before any future export):
grep -rniE "capital|c1[-_]|\bcof\b|badge|bcfg|mlzone|onelake|talos|chamber|bogie|selene|aiml|bank|fraud|neptune|kubekit" .
