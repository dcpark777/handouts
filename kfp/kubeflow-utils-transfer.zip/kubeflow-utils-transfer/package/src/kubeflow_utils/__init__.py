"""kubeflow-utils — plain-Python pipelines that run on a laptop and on KFP.

    from kubeflow_utils import step, pipeline          # the two decorators
    from kubeflow_utils import DataStore, Spark, Snowflake, get_logger   # resolvers
"""
import logging as _logging
import os as _os
import re as _re

from kubeflow_utils.datastore import DataStore, SourceKind, classify_source   # noqa
from kubeflow_utils.decorators import step, pipeline, PipelineError          # noqa
from kubeflow_utils.spark import Spark                                        # noqa
from kubeflow_utils.snowflake import Snowflake                                # noqa

_SECRET_NAME = _re.compile(
    r"(^|_)(SECRET|PASSWORD|PASSWD|TOKEN|API_KEY|ACCESS_KEY|PRIVATE_KEY|CREDENTIALS?)$", _re.I)


class _Redact(_logging.Filter):
    """Masks the VALUES of secret-shaped environment variables in log records."""
    def filter(self, record: _logging.LogRecord) -> bool:
        secrets = [v for k, v in _os.environ.items() if _SECRET_NAME.search(k) and len(v) > 3]
        if secrets:
            msg = record.getMessage()
            for value in secrets:
                msg = msg.replace(value, "***")
            record.msg, record.args = msg, ()
        return True


def get_logger(name: str = "kubeflow_utils") -> _logging.Logger:
    logger = _logging.getLogger(name)
    if not logger.handlers:
        handler = _logging.StreamHandler()
        handler.setFormatter(_logging.Formatter("%(asctime)s %(levelname)s %(name)s :: %(message)s"))
        handler.addFilter(_Redact())
        logger.addHandler(handler)
        logger.setLevel(_os.environ.get("KUBEFLOW_UTILS_LOG_LEVEL", "INFO"))
    return logger
