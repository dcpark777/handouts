"""kubeflow_utils.lake_broker — the ONE platform-binding seam.

Every touchpoint between kubeflow-utils and your organization's data-lake /
credential-broker SDK lives in this module and nowhere else. Porting
kubeflow-utils to a platform means implementing these six callables; nothing
else in the package knows the platform exists.

The reference wiring below targets a generic "lake broker" SDK with a
sidecar-credential model:

  staging lake     s3 buckets reached via per-profile sidecar creds,
                   recognized by path prefix
  production lake  governed datasets addressed by DATASET ID
                   (schemeless token or prodlake://<id>), one token
                   for all datasets

Each function raises a clear error when the SDK is absent so a laptop
run that never touches lake paths works with zero platform deps.
"""
from __future__ import annotations

from typing import Any

_SDK_HINT = ("lake-broker sdk not importable — bind kubeflow_utils.lake_broker "
             "to your platform sdk (see module docstring)")


def _sdk():
    try:
        import lake_broker_sdk  # type: ignore   # <- your platform package
        return lake_broker_sdk
    except ImportError as error:
        raise ImportError(_SDK_HINT) from error


def is_dataset_id(token: str) -> bool:
    """Is this schemeless token a production-lake dataset id?
    Return False when unsure — LOCAL must win ambiguity."""
    try:
        return bool(_sdk().is_dataset_id(token))
    except ImportError:
        return False


def is_staging_lake_path(source_path: str) -> bool:
    """Does this s3 path live in the staging lake (vs generic S3)?"""
    try:
        return bool(_sdk().is_staging_lake_path(source_path))
    except ImportError:
        return False


def sidecar_profile_mapping() -> dict[str, str]:
    """location-root -> credential-profile mapping for the staging lake."""
    return dict(_sdk().get_sidecar_uri_to_profile_mapping())


def staging_sidecar(profile: str) -> Any:
    """Sidecar handle for a staging-lake profile. Must expose:
    .location  .get_s3fs()  and optionally .polars_provider /
    .storage_options."""
    return _sdk().get_sidecar(profile=profile)


def production_dataset(dataset_id: str) -> Any:
    """Dataset handle for a production-lake dataset id. Must expose:
    .location  .get_s3fs()  and optionally .polars_provider /
    .storage_options."""
    return _sdk().get_dataset(dataset_id=dataset_id)


def fetch_secret(reference: str) -> str:
    """Resolve a `secrets:` reference (e.g. "vault:secret/prod/x#client_id")
    to its value. Bound to the platform's secret store at work."""
    return str(_sdk().fetch_secret(reference))


def broker_storage_conf() -> dict[str, str]:
    """The lake's storage access expressed as Spark s3a conf (endpoint +
    brokered token) — the same broker DataStore uses, so Spark and
    polars see identical storage."""
    return dict(_sdk().spark_storage_conf())
