"""kubeflow_utils.spark — Spark(...).get_session(): the session resolver.

Layered configuration, resolved by RUNTIME_MODE:

    session conf = base(mode) | user extra_conf        (user WINS)

  * base(local): local[*] master, modest driver memory, and — when the
    run touches remote storage — the same s3a credential conf as the
    cluster, so `spark.read.parquet("s3://...")` works in a notebook.
  * base(kfp):   cluster master from the pod env, storage-access conf
    (endpoint + brokered token) that components REQUIRE.
  * user extra_conf: always applied last. Overriding a PROTECTED key
    (storage access) is allowed but warned — compile lints it too.
"""
from __future__ import annotations

import warnings
from typing import Any, Optional

from kubeflow_utils.runtime import is_cluster

import contextlib
import contextvars

_step_conf: contextvars.ContextVar[dict] = contextvars.ContextVar("kfu_step_spark_conf", default={})


@contextlib.contextmanager
def step_conf(conf: dict):
    """Set by the runner around each step: that step's `spark:` block from
    the environment config. Layered under the user's inline extra_conf."""
    token = _step_conf.set(dict(conf))
    try:
        yield
    finally:
        _step_conf.reset(token)

# keys the environment depends on; user may override, but is told.
PROTECTED_KEYS = (
    "spark.hadoop.fs.s3a.endpoint",
    "spark.hadoop.fs.s3a.access.key",
    "spark.hadoop.fs.s3a.secret.key",
    "spark.hadoop.fs.s3a.session.token",
    "spark.hadoop.fs.s3a.aws.credentials.provider",
)


class Spark:
    def __init__(self, app_name: str = "kubeflow-utils",
                 extra_conf: Optional[dict[str, str]] = None) -> None:
        self._app_name = app_name
        self._extra_conf = dict(extra_conf or {})

    def get_session(self) -> Any:
        from pyspark.sql import SparkSession

        active = SparkSession.getActiveSession()
        if active is not None:
            if self._extra_conf:
                warnings.warn(
                    "An active Spark session already exists; extra_conf was "
                    "NOT applied (Spark reuses the running session). Call "
                    "spark.stop() or restart the kernel to apply it.",
                    stacklevel=2)
            return active

        base = self._cluster_base() if is_cluster() else self._local_base()

        for key in self._extra_conf:
            if key in PROTECTED_KEYS:
                warnings.warn(
                    f"extra_conf overrides protected key {key!r} — this is "
                    f"storage-access conf the environment normally owns. "
                    f"Applying your value.", stacklevel=2)
        merged = {**base, **_step_conf.get(), **self._extra_conf}   # config, then user, wins

        builder = SparkSession.builder.appName(self._app_name)
        for key, value in merged.items():
            builder = builder.config(key, value)
        if not is_cluster():
            builder = builder.master("local[*]")
        return builder.getOrCreate()

    # ── conf layers ─────────────────────────────────────────────────
    def _local_base(self) -> dict[str, str]:
        conf = {"spark.driver.memory": "8g",
                "spark.sql.session.timeZone": "UTC"}
        try:
            conf.update(self._broker_conf())     # laptop with lake access
        except Exception as error:               # pure-local run: fine
            import logging
            logging.getLogger("kubeflow_utils.spark").debug(
                "no lake storage conf applied locally: %r", error)
        return conf

    def _cluster_base(self) -> dict[str, str]:
        conf = {"spark.sql.session.timeZone": "UTC"}
        conf.update(self._broker_conf())         # required on cluster: raise
        return conf

    @staticmethod
    def _broker_conf() -> dict[str, str]:
        """s3a endpoint + brokered token — the SAME broker DataStore uses,
        so Spark and polars see identical storage. One token covers all
        datasets (single-session model)."""
        from kubeflow_utils.lake_broker import broker_storage_conf
        return broker_storage_conf()
