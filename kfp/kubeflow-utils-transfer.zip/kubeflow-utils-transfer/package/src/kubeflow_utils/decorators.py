"""kubeflow_utils.decorators — @step and @pipeline.

Outside of recording, both are transparent: a @step function is the
function; a @pipeline function runs its body as plain Python (after
resolving sentinel inputs once). During recording — `check`, `compile`,
and the runner deciding what to execute — calling a @step records
(function, args) instead of running it, so the framework can read the
pipeline's structure by calling it once with probe values.
"""
from __future__ import annotations

import contextvars
import functools
import inspect
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

_recording: contextvars.ContextVar[Optional["Recording"]] = contextvars.ContextVar(
    "kubeflow_utils_recording", default=None)


class PipelineError(ValueError):
    pass


@dataclass
class StepCall:
    fn: Callable
    kwargs: dict[str, Any]

    @property
    def name(self) -> str:
        return self.fn.__name__


@dataclass
class Recording:
    calls: list[StepCall] = field(default_factory=list)


class Placeholder:
    """Stands in for a step's return value during recording. If it is ever
    passed to another step, that's value-passing across the storage
    boundary — refused at compile."""
    def __init__(self, producer: str) -> None:
        self.producer = producer

    def __repr__(self) -> str:
        return f"<output of {self.producer}>"


def step(fn: Optional[Callable] = None):
    """Marks a component entrypoint. No arguments; behavior lives in config."""
    def wrap(f: Callable) -> Callable:
        sig = inspect.signature(f)

        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            rec = _recording.get()
            if rec is None:
                return f(*args, **kwargs)
            bound = sig.bind(*args, **kwargs)
            bound.apply_defaults()
            for name, value in bound.arguments.items():
                if isinstance(value, Placeholder):
                    raise PipelineError(
                        f"{f.__name__}() received {value!r} as {name!r} — steps "
                        f"communicate through storage: write a dataset in "
                        f"{value.producer} and pass its path here.")
            rec.calls.append(StepCall(f, dict(bound.arguments)))
            return Placeholder(f.__name__)

        wrapper.__kfu_step__ = True
        wrapper.__wrapped_fn__ = f
        return wrapper
    return wrap(fn) if fn is not None else wrap


def is_step(obj: Any) -> bool:
    return bool(getattr(obj, "__kfu_step__", False))


def pipeline(fn: Callable) -> Callable:
    """Marks the pipeline function. Calling it directly runs the body as
    plain Python (sentinel inputs like "today" resolved once, up front)."""
    sig = inspect.signature(fn)

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        from kubeflow_utils.runner import resolve_sentinels
        bound = sig.bind_partial(*args, **kwargs)
        bound.apply_defaults()
        return fn(**resolve_sentinels(dict(bound.arguments)))

    wrapper.__kfu_pipeline__ = True
    wrapper.__wrapped_fn__ = fn
    wrapper.__signature__ = sig
    return wrapper


def record(pipeline_fn: Callable, **inputs: Any) -> list[StepCall]:
    """Call the pipeline body once with `inputs`, recording step calls."""
    fn = getattr(pipeline_fn, "__wrapped_fn__", pipeline_fn)
    rec = Recording()
    token = _recording.set(rec)
    try:
        fn(**inputs)
    finally:
        _recording.reset(token)
    return rec.calls


def signature_inputs(pipeline_fn: Callable) -> dict[str, tuple[type, Any]]:
    """name -> (annotation, default) ; default is inspect.Parameter.empty if none."""
    return {n: (p.annotation if p.annotation is not inspect.Parameter.empty else str, p.default)
            for n, p in inspect.signature(pipeline_fn).parameters.items()}


def probe_inputs(pipeline_fn: Callable, index: int) -> dict[str, Any]:
    out = {}
    for name, (kind, _) in signature_inputs(pipeline_fn).items():
        out[name] = (bool(index % 2) if kind is bool else index if kind is int
                     else float(index) if kind is float else f"<{name}-{index}>")
    return out


def structure(pipeline_fn: Callable) -> list[StepCall]:
    """Record with two probe value sets; the call sequence must not
    depend on values. Undecorated calls to step-looking functions are
    caught by the AST scan in validate."""
    first = record(pipeline_fn, **probe_inputs(pipeline_fn, 1))
    second = record(pipeline_fn, **probe_inputs(pipeline_fn, 2))
    if [c.name for c in first] != [c.name for c in second]:
        raise PipelineError(
            f"{pipeline_fn.__name__}() calls different steps for different "
            f"input values ({[c.name for c in first]} vs {[c.name for c in second]}). "
            f"A pipeline's structure must be fixed — no branching around steps; "
            f"put the condition inside the step.")
    return first
