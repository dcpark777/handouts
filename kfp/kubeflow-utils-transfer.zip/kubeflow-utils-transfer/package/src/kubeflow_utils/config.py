"""kubeflow_utils.config — pipelines/kfp.yaml + pipelines/environments/*.yaml.

    pipelines/customer.py          the pipeline (code; identical everywhere)
    pipelines/kfp.yaml             cluster runtime: BAKED keys + values uat/prod share
    pipelines/environments/
        local.yaml                 complete, standalone   (--env local)
        uat.yaml                   delta over kfp.yaml     (--env uat)
        prod.yaml                  delta over kfp.yaml     (--env prod)

Sections: params, datasets (the ONLY templated section: "{name}" must be a
pipeline input), settings (-> KUBEFLOW_UTILS_* env vars, never secrets),
secrets (references fetched at run start, exported as env vars), steps
(per-step knobs), only, parallel.

Rules enforced at load:
  * baked keys (cpu, memory, image, retries, parallel) only in kfp.yaml
  * uat/prod may only set runtime keys, and must set the SAME keys
  * every dataset name is a pipeline input; every {placeholder} in a
    dataset is a pipeline input or a param
  * secret-shaped keys are refused under settings (secrets go under secrets:)
  * step names under steps:/only:/parallel: must be recorded steps
"""
from __future__ import annotations

import inspect
import re
import string
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from kubeflow_utils.decorators import PipelineError, signature_inputs

BAKED_STEP_KEYS = ("cpu", "memory", "image", "retries")
RUNTIME_STEP_KEYS = ("skip_if_exists", "spark")
SECTIONS = ("params", "datasets", "settings", "secrets", "steps", "only", "parallel")
_SECRET_KEY = re.compile(
    r"(^|_)(SECRET|PASSWORD|PASSWD|TOKEN|API_KEY|ACCESS_KEY|PRIVATE_KEY|CREDENTIALS?)$", re.I)


@dataclass
class Config:
    env: str
    params: dict[str, Any] = field(default_factory=dict)
    datasets: dict[str, str] = field(default_factory=dict)      # templates
    settings: dict[str, str] = field(default_factory=dict)
    secrets: dict[str, str] = field(default_factory=dict)       # NAME -> reference
    steps: dict[str, dict[str, Any]] = field(default_factory=dict)
    only: list[str] | None = None
    parallel: list[list[str]] = field(default_factory=list)

    def step_opt(self, step: str, key: str, default: Any = None) -> Any:
        return self.steps.get(step, {}).get(key, default)


def pipeline_dir(pipeline_fn: Callable) -> Path:
    return Path(inspect.getfile(getattr(pipeline_fn, "__wrapped_fn__", pipeline_fn))).parent


def environments(pipeline_fn: Callable) -> list[str]:
    folder = pipeline_dir(pipeline_fn) / "environments"
    return sorted(p.stem for p in folder.glob("*.yaml")) if folder.exists() else []


def _read(path: Path) -> dict:
    import yaml
    raw = yaml.safe_load(path.read_text()) or {}
    unknown = set(raw) - set(SECTIONS)
    if unknown:
        raise PipelineError(f"{path.name}: unknown section(s) {sorted(unknown)} — "
                            f"allowed: {', '.join(SECTIONS)}")
    return raw


def _merge(base: dict, over: dict) -> dict:
    out = {k: (dict(v) if isinstance(v, dict) else v) for k, v in base.items()}
    for key, value in over.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            for sub, sv in value.items():
                if isinstance(sv, dict) and isinstance(out[key].get(sub), dict):
                    out[key][sub] = {**out[key][sub], **sv}
                else:
                    out[key][sub] = sv
        else:
            out[key] = value
    return out


def load_config(pipeline_fn: Callable, env: str, step_names: list[str]) -> Config:
    """Load the effective config for `env`, validating every rule."""
    root = pipeline_dir(pipeline_fn)
    envs = environments(pipeline_fn)
    if env == "kfp" or env not in envs:
        raise PipelineError(
            f"no such environment {env!r} (have: {', '.join(envs) or 'none'}). "
            + ("kfp.yaml is the cluster runtime config, not an environment." if env == "kfp" else
               "Add pipelines/environments/<env>.yaml."))

    kfp_path = root / "kfp.yaml"
    kfp = _read(kfp_path) if kfp_path.exists() else {}
    env_raw = _read(root / "environments" / f"{env}.yaml")

    if env == "local":
        raw = env_raw
        _forbid_baked(env_raw, f"environments/{env}.yaml")
    else:
        _forbid_baked(env_raw, f"environments/{env}.yaml")
        raw = _merge(kfp, env_raw)
        _check_tier_agreement(root, envs, kfp_path)

    cfg = Config(
        env=env,
        params=dict(raw.get("params") or {}),
        datasets={k: str(v) for k, v in (raw.get("datasets") or {}).items()},
        settings={k: str(v) for k, v in (raw.get("settings") or {}).items()},
        secrets={k: str(v) for k, v in (raw.get("secrets") or {}).items()},
        steps={k: dict(v or {}) for k, v in (raw.get("steps") or {}).items()},
        only=list(raw["only"]) if raw.get("only") else None,
        parallel=[list(g) for g in (raw.get("parallel") or [])],
    )
    _validate(cfg, pipeline_fn, step_names)
    return cfg


def _forbid_baked(raw: dict, label: str) -> None:
    for step_name, opts in (raw.get("steps") or {}).items():
        for key in opts or {}:
            if key in BAKED_STEP_KEYS:
                raise PipelineError(
                    f"{label}: steps.{step_name}.{key} is baked at compile and cannot "
                    f"vary by environment (the pipeline is compiled once) — set it "
                    f"in pipelines/kfp.yaml")
            if key not in RUNTIME_STEP_KEYS:
                raise PipelineError(f"{label}: unknown step option {key!r} for "
                                    f"{step_name!r}; allowed: {RUNTIME_STEP_KEYS}")
    if "parallel" in raw:
        raise PipelineError(f"{label}: parallel is baked at compile — set it in kfp.yaml")


def _check_tier_agreement(root: Path, envs: list[str], kfp_path: Path) -> None:
    tiers = [e for e in envs if e != "local"]
    shapes = {}
    for tier in tiers:
        raw = _read(root / "environments" / f"{tier}.yaml")
        shapes[tier] = {s: tuple(sorted((raw.get(s) or {}).keys()))
                        for s in ("params", "datasets", "settings", "secrets")}
    if len(set(map(str, shapes.values()))) > 1:
        a, b = list(shapes)[:2]
        raise PipelineError(
            f"cluster environments must set the same keys: {a}.yaml and {b}.yaml "
            f"differ ({shapes[a]} vs {shapes[b]}). Shared values belong in kfp.yaml.")


def _validate(cfg: Config, pipeline_fn: Callable, step_names: list[str]) -> None:
    inputs = signature_inputs(pipeline_fn)
    # params are template variables for datasets; a param that also matches a
    # pipeline input fills it (and must match its type)
    for key in cfg.params:
        if key in inputs:
            kind = inputs[key][0]
            if kind in (str, int, float, bool) and not isinstance(cfg.params[key], kind):
                raise PipelineError(f"{cfg.env}: params.{key} is "
                                    f"{type(cfg.params[key]).__name__}, signature says "
                                    f"{kind.__name__}")
    for name, template in cfg.datasets.items():
        if name not in inputs:
            raise PipelineError(f"{cfg.env}: datasets.{name} is not an input of "
                                f"{pipeline_fn.__name__}() — datasets are passed to the "
                                f"pipeline as string parameters")
        for _, placeholder, _, _ in string.Formatter().parse(template):
            if placeholder and placeholder not in inputs and placeholder not in cfg.params:
                raise PipelineError(f"{cfg.env}: datasets.{name} references {{{placeholder}}} "
                                    f"which is not a pipeline input or a param")
    for key in cfg.settings:
        if _SECRET_KEY.search(key):
            raise PipelineError(f"{cfg.env}: settings.{key} looks like a secret — put a "
                                f"reference under secrets: instead")
    for section, names in (("steps", cfg.steps), ("only", cfg.only or []),
                           ("parallel", [n for g in cfg.parallel for n in g])):
        for name in names:
            if name not in step_names:
                raise PipelineError(f"{cfg.env}: {section} names step {name!r}; the "
                                    f"pipeline's steps are {step_names}")


def load_baked(pipeline_fn: Callable, step_names: list[str]) -> Config:
    """kfp.yaml alone, for compile: resources/retries/parallel."""
    root = pipeline_dir(pipeline_fn)
    kfp_path = root / "kfp.yaml"
    raw = _read(kfp_path) if kfp_path.exists() else {}
    cfg = Config(env="kfp",
                 steps={k: dict(v or {}) for k, v in (raw.get("steps") or {}).items()},
                 parallel=[list(g) for g in (raw.get("parallel") or [])])
    for name in list(cfg.steps) + [n for g in cfg.parallel for n in g]:
        if name not in step_names:
            raise PipelineError(f"kfp.yaml names step {name!r}; the pipeline's steps "
                                f"are {step_names}")
    return cfg
