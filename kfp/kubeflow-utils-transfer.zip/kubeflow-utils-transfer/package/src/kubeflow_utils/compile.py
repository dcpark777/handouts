"""kubeflow_utils.compile — pipeline function -> deployable spec, once.

compile_spec(fn)  PURE: structure + kfp.yaml -> CompiledPipeline. Inputs
                  are `env` + the pipeline's run-valued inputs (those not
                  supplied by environments/*.yaml as params or datasets).
                  If any input has a sentinel default ("today"), a
                  framework-owned `resolve-inputs` component runs first and
                  every step consumes the resolved values.
to_kfp(...)       the ONLY kfp-touching code — validated on the cluster.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from kubeflow_utils.config import load_baked, environments, load_config
from kubeflow_utils.decorators import PipelineError, signature_inputs, structure
from kubeflow_utils.runner import SENTINELS, _EMPTY


@dataclass
class CompiledStep:
    name: str
    command: list[str]
    stage: int
    resources: dict[str, Any]
    retries: int


@dataclass
class CompiledPipeline:
    name: str
    inputs: dict[str, dict[str, Any]]        # pipeline inputs incl. env
    resolve_inputs: list[str]                # inputs the first component resolves
    pipeline_ref: str
    steps: list[CompiledStep] = field(default_factory=list)


def compile_spec(pipeline_fn: Callable) -> CompiledPipeline:
    calls = structure(pipeline_fn)
    names = [c.name for c in calls]
    baked = load_baked(pipeline_fn, names)
    tiers = [e for e in environments(pipeline_fn) if e != "local"]
    for tier in tiers:                                    # validate every env file at compile
        load_config(pipeline_fn, tier, names)
    env_valued: set[str] = set()
    sig_names = set(signature_inputs(pipeline_fn))
    if tiers:
        cfg = load_config(pipeline_fn, tiers[0], names)
        env_valued = (set(cfg.params) & set(sig_names)) | set(cfg.datasets)

    sig = signature_inputs(pipeline_fn)
    inputs: dict[str, dict[str, Any]] = {"env": {"type": "str", "choices": tiers}}
    resolve = []
    for name, (kind, default) in sig.items():
        if name in env_valued:
            continue
        spec: dict[str, Any] = {"type": getattr(kind, "__name__", str(kind))}
        if default is not _EMPTY:
            spec["default"] = default
            if isinstance(default, str) and default in SENTINELS:
                resolve.append(name)
        inputs[name] = spec

    fn = getattr(pipeline_fn, "__wrapped_fn__", pipeline_fn)
    ref = f"{fn.__module__}:{fn.__qualname__}"
    compiled = CompiledPipeline(name=fn.__name__, inputs=inputs,
                                resolve_inputs=resolve, pipeline_ref=ref)

    groups = {n: i for i, g in enumerate(baked.parallel) for n in g}
    stage, seen_groups = 0, set()
    for call in calls:
        gid = groups.get(call.name)
        if gid is None or gid not in seen_groups:
            if gid is not None:
                seen_groups.add(gid)
            current = stage
            stage += 1
        else:
            current = compiled.steps[-1].stage        # same group: same stage
        opts = baked.steps.get(call.name, {})
        compiled.steps.append(CompiledStep(
            name=call.name, stage=current,
            command=["python", "-m", "kubeflow_utils.runner",
                     "--pipeline", ref, "--step", call.name],
            resources={k: opts[k] for k in ("cpu", "memory", "image") if k in opts},
            retries=int(opts.get("retries", 0))))
    return compiled


def render_dag(compiled: CompiledPipeline) -> str:
    lines = [compiled.name]
    if compiled.resolve_inputs:
        lines.append(f"  0.    resolve-inputs  -> {', '.join(compiled.resolve_inputs)}")
    stages: dict[int, list[CompiledStep]] = {}
    for s in compiled.steps:
        stages.setdefault(s.stage, []).append(s)
    for i in sorted(stages):
        group = stages[i]
        for pos, s in enumerate(group):
            marker = "   " if len(group) == 1 else (" ├─" if pos < len(group) - 1 else " └─")
            extras = [f"{k}={v}" for k, v in s.resources.items()] + \
                     ([f"retries={s.retries}"] if s.retries else [])
            lines.append(f"  {i + 1}.{marker} {s.name}{'  (parallel)' if len(group) > 1 else ''}"
                         + (f"  [{', '.join(extras)}]" if extras else ""))
    lines.append("  inputs: " + ", ".join(compiled.inputs))
    return "\n".join(lines)


def to_kfp(compiled: CompiledPipeline, output_path: str) -> Any:
    """The kfp binding — validated on the work cluster, not guessed.
    Per step:  command = compiled.step.command + ["--env", {{env input}}]
                         + ["--input", f"{name}={{value}}"] for every non-env
                           input (resolved values for compiled.resolve_inputs,
                           taken from the resolve-inputs component's outputs)
               env      = RUNTIME_MODE=kfp  (the runner exports settings/secrets)
               after    = every component of the previous stage
               resources/retries from CompiledStep
    First component (only when resolve_inputs is non-empty):
               command = python -m kubeflow_utils.runner --pipeline REF
                         --step resolve --env {{env}} --input name={{value}}...
                         --resolve name={{output path}}..."""
    raise NotImplementedError("kfp binding is validated on the work environment")
