"""kfu — run | check | compile | submit   (console script)"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Callable


def load_pipeline(target: str) -> Callable:
    """`pipelines/customer.py` or `customer` -> the @pipeline function."""
    path = Path(target if target.endswith(".py") else f"pipelines/{target}.py")
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[path.stem] = module
    spec.loader.exec_module(module)
    fns = [v for v in vars(module).values() if getattr(v, "__kfu_pipeline__", False)]
    if len(fns) != 1:
        raise SystemExit(f"{path} must define exactly one @pipeline (found {len(fns)})")
    return fns[0]


def _flags(argv: list[str]) -> tuple[dict[str, str], list[str]]:
    flags, only = {}, []
    i = 0
    while i < len(argv):
        if argv[i] == "--only":
            only = argv[i + 1].split(","); i += 2
        elif argv[i].startswith("--") and i + 1 < len(argv):
            flags[argv[i][2:]] = argv[i + 1]; i += 2
        else:
            i += 1
    return flags, only


def main(argv: list[str] | None = None) -> None:
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) < 2:
        raise SystemExit("usage: kfu run|check|compile|submit <pipeline> [--env X] [--input value] [--only a,b]")
    verb, target, rest = argv[0], argv[1], argv[2:]
    pipeline_fn = load_pipeline(target)
    from kubeflow_utils.compile import compile_spec, render_dag, to_kfp
    from kubeflow_utils.validate import validate

    if verb == "run":
        from kubeflow_utils.runner import run_local
        flags, only = _flags(rest)
        env = flags.pop("env", "local")
        print(render_dag(compile_spec(pipeline_fn)) + f"\n  (run: env={env})")
        run_local(pipeline_fn, env=env, only=only or None, **flags)
        return

    findings = validate(pipeline_fn)
    for f in findings:
        print(("ERROR " if f.startswith("ERROR") else "warn  ") + f.removeprefix("ERROR "),
              file=sys.stderr)
    compiled = compile_spec(pipeline_fn)
    print(render_dag(compiled))
    if any(f.startswith("ERROR") for f in findings):
        raise SystemExit("errors — pipeline not compiled.")
    if verb == "check":
        print("ok — nothing emitted (check).")
    elif verb == "compile":
        to_kfp(compiled, "pipeline.yaml")
    elif verb == "submit":
        raise SystemExit("submit: bound to the platform's submit API at work "
                         "(resolves sentinel inputs, then submits with --env)")
    else:
        raise SystemExit(f"unknown verb {verb!r}")


if __name__ == "__main__":
    main()
