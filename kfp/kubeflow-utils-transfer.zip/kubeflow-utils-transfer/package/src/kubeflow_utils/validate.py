"""kubeflow_utils.validate — checks that need more than the decorators.

  * undecorated calls in the pipeline body (AST): a plain function called
    like a step would EXECUTE at compile — refused
  * steps sweep: every public function in the steps module/package is
    @step; every @step used by the pipeline lives there
  * lints on step source: os.path (lies on object storage), os.environ
    (environment awareness belongs to providers)
"""
from __future__ import annotations

import ast
import importlib
import inspect
from pathlib import Path
from typing import Callable

from kubeflow_utils.decorators import is_step, structure


def validate(pipeline_fn: Callable) -> list[str]:
    findings: list[str] = []
    calls = structure(pipeline_fn)
    findings += undecorated_calls(pipeline_fn)
    findings += steps_sweep(calls)
    for call in calls:
        findings += lint_source(call.fn)
    return findings


def undecorated_calls(pipeline_fn: Callable) -> list[str]:
    fn = getattr(pipeline_fn, "__wrapped_fn__", pipeline_fn)
    try:
        tree = ast.parse(inspect.getsource(fn))
    except (OSError, TypeError):
        return []
    module_globals = fn.__globals__
    findings = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            target = module_globals.get(node.func.id)
            if callable(target) and not is_step(target) and \
                    getattr(target, "__module__", "").startswith(_steps_package(module_globals)):
                findings.append(
                    f"ERROR {fn.__name__}() calls {node.func.id}() which is not a @step — "
                    f"it would run for real during compile. Decorate it, or move it "
                    f"out of the steps module.")
    return findings


def _steps_package(module_globals: dict) -> str:
    for value in module_globals.values():
        if is_step(value):
            mod = getattr(value, "__wrapped_fn__", value).__module__
            return mod.rsplit(".", 1)[0] if "." in mod else mod
    return "\x00"


def steps_sweep(calls) -> list[str]:
    findings = []
    modules = {getattr(c.fn, "__module__", "") for c in calls}
    for module_name in sorted(modules):
        module = importlib.import_module(module_name)
        for attr, obj in vars(module).items():
            if attr.startswith("_") or not callable(obj) or is_step(obj):
                continue
            if getattr(obj, "__module__", None) == module.__name__ and inspect.isfunction(obj):
                findings.append(f"{module.__name__}.{attr} is a public function in a steps "
                                f"module but is not a @step — decorate it, or make it "
                                f"private / move it to lib")
    return findings


def lint_source(fn: Callable) -> list[str]:
    fn = getattr(fn, "__wrapped_fn__", fn)
    try:
        source = inspect.getsource(inspect.getmodule(fn))
    except (OSError, TypeError):
        return []
    out = []
    for node in ast.walk(ast.parse(source)):
        if not isinstance(node, ast.Attribute):
            continue
        base = node.value
        if isinstance(base, ast.Attribute) and isinstance(base.value, ast.Name) \
                and base.value.id == "os" and base.attr == "path":
            out.append(f"{fn.__module__}:{node.lineno} uses os.path.{node.attr} — os.path "
                       f"lies about object storage (exists() is silently False on s3://); "
                       f"use DataStore(path).exists() or plain string paths")
        if isinstance(base, ast.Name) and base.id == "os" and node.attr == "environ":
            out.append(f"{fn.__module__}:{node.lineno} reads os.environ — environment "
                       f"awareness belongs to the providers; take a parameter instead")
    return out
