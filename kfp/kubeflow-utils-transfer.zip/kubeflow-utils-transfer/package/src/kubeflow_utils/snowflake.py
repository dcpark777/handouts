"""kubeflow_utils.snowflake — Snowflake(...).get_connection(): the auth resolver.

Credentials arrive in the process environment (exported by the runner from
`secrets:` references on the cluster; from the developer's shell / .env
locally): CLIENT_ID, CLIENT_SECRET, and OAUTH_TOKEN (minted by the runner
at start, re-minted here if expired). Non-secret coordinates come from
`settings:` as KUBEFLOW_UTILS_SNOWFLAKE_ACCOUNT / _OAUTH_TOKEN_URL.
conn_kwargs merge {**base, **user} — user wins.
"""
from __future__ import annotations

import os
import time
from typing import Any

_TOKEN: dict[str, tuple[str, float]] = {}
_MARGIN_S = 300


class Snowflake:
    def __init__(self, **conn_kwargs: Any) -> None:
        self._conn_kwargs = conn_kwargs

    def get_connection(self) -> Any:
        import snowflake.connector
        base = {"account": os.environ["KUBEFLOW_UTILS_SNOWFLAKE_ACCOUNT"],
                "authenticator": "oauth", "token": oauth_token()}
        if "KUBEFLOW_UTILS_SNOWFLAKE_USER" in os.environ:
            base["user"] = os.environ["KUBEFLOW_UTILS_SNOWFLAKE_USER"]
        return snowflake.connector.connect(**{**base, **self._conn_kwargs})


def oauth_token() -> str:
    """OAUTH_TOKEN from the environment if present and fresh; otherwise
    mint from CLIENT_ID/CLIENT_SECRET (cached with an expiry margin)."""
    cached = _TOKEN.get("token")
    if cached and cached[1] - time.time() > _MARGIN_S:
        return cached[0]
    if "OAUTH_TOKEN" in os.environ and not cached:
        _TOKEN["token"] = (os.environ["OAUTH_TOKEN"], time.time() + 3600)
        return os.environ["OAUTH_TOKEN"]
    token, expires_at = request_token(os.environ["KUBEFLOW_UTILS_OAUTH_TOKEN_URL"],
                                      os.environ["CLIENT_ID"], os.environ["CLIENT_SECRET"])
    _TOKEN["token"] = (token, expires_at)
    os.environ["OAUTH_TOKEN"] = token
    return token


def request_token(token_url: str, client_id: str, client_secret: str) -> tuple[str, float]:
    import requests
    response = requests.post(token_url, data={"grant_type": "client_credentials",
                                              "client_id": client_id,
                                              "client_secret": client_secret})
    response.raise_for_status()
    payload = response.json()
    return payload["access_token"], time.time() + float(payload.get("expires_in", 3600))
