"""kubeflow_utils.runner — one runner, three places.

  run_local(pipeline_fn, env, **inputs)   laptop: every step in-process
  main()  (python -m kubeflow_utils.runner --pipeline mod:fn --step name
           --env prod --input snap_date=... )      one step, in a container

Per component / per run:
  1. resolve sentinel inputs ONCE ("today" -> YYYY-MM-DD)  [cluster: the
     framework's resolve-inputs component does this; components receive
     the resolved value]
  2. load config for env; fetch `secrets:` references not already in the
     environment and export them; mint OAUTH_TOKEN from CLIENT_ID/SECRET
  3. format `datasets:` templates with the inputs -> dataset paths
  4. record the pipeline body with those inputs -> the step calls
  5. for the step(s) to run: skip if configured and all dataset args exist;
     pre-check dataset args that already-existed-or-must; call; post-check
     every dataset arg exists; refuse non-None returns
"""
from __future__ import annotations

import argparse
import datetime as _dt
import importlib
import json
import os
import time
from typing import Any, Callable

from kubeflow_utils.config import Config, load_config
from kubeflow_utils.decorators import (PipelineError, StepCall, record,
                                       signature_inputs, structure)

SENTINELS = {"today": 0, "yesterday": -1}
SETTINGS_PREFIX = "KUBEFLOW_UTILS_"


class RunnerError(RuntimeError):
    pass


# ── inputs ───────────────────────────────────────────────────────────

def resolve_sentinels(inputs: dict[str, Any]) -> dict[str, Any]:
    """'today' / 'yesterday' -> ISO date, resolved once per run."""
    out = dict(inputs)
    for name, value in inputs.items():
        if isinstance(value, str) and value in SENTINELS:
            out[name] = (_dt.date.today() + _dt.timedelta(days=SENTINELS[value])).isoformat()
    return out


def decode(raw: Any, kind: type) -> Any:
    if not isinstance(raw, str):
        return raw
    try:
        value = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return raw
    return raw if (kind is str and not isinstance(value, str)) else value


def effective_inputs(pipeline_fn: Callable, cfg: Config, given: dict[str, Any]) -> dict[str, Any]:
    """params from config + dataset paths from templates + explicit inputs;
    signature defaults fill the rest; sentinels resolved once."""
    sig = signature_inputs(pipeline_fn)
    env_valued = (set(cfg.params) & set(sig)) | set(cfg.datasets)
    clash = sorted((set(given) & env_valued) | (set(given) & set(cfg.params)))
    if clash:
        raise PipelineError(f"{clash} come from the environment config and cannot be "
                            f"passed at run time — edit environments/{cfg.env}.yaml")
    given = {k: decode(v, sig[k][0]) for k, v in given.items() if k in sig}
    inputs: dict[str, Any] = {k: v for k, v in cfg.params.items() if k in sig}
    for name, (_, default) in sig.items():
        if name in inputs or name in cfg.datasets:
            continue
        if name in given:
            inputs[name] = given[name]
        elif default is not _EMPTY:
            inputs[name] = default
    inputs = resolve_sentinels(inputs)
    context = {**cfg.params, **inputs}                 # template variables
    for name, template in cfg.datasets.items():
        try:
            inputs[name] = template.format(**context)
        except KeyError as e:
            raise PipelineError(f"datasets.{name} needs {e.args[0]!r} which was not "
                                f"supplied") from None
    missing = [n for n, (_, d) in sig.items() if n not in inputs and d is _EMPTY]
    if missing:
        raise PipelineError(f"{pipeline_fn.__name__}() is missing inputs {missing}")
    return inputs


import inspect as _inspect
_EMPTY = _inspect.Parameter.empty


# ── secrets / settings ───────────────────────────────────────────────

def export_environment(cfg: Config) -> None:
    from kubeflow_utils import lake_broker
    for key, value in cfg.settings.items():
        os.environ[f"{SETTINGS_PREFIX}{key}"] = value
    for name, reference in cfg.secrets.items():
        if name in os.environ:                       # local .env / shell already has it
            continue
        os.environ[name] = lake_broker.fetch_secret(reference)
    if {"CLIENT_ID", "CLIENT_SECRET"} <= set(os.environ) and "OAUTH_TOKEN" not in os.environ:
        url = cfg.settings.get("OAUTH_TOKEN_URL")
        if url:
            from kubeflow_utils.snowflake import request_token
            os.environ["OAUTH_TOKEN"] = request_token(
                url, os.environ["CLIENT_ID"], os.environ["CLIENT_SECRET"])[0]


# ── one step ─────────────────────────────────────────────────────────

def run_step(call: StepCall, cfg: Config, dataset_names: set[str]) -> None:
    from kubeflow_utils import DataStore, get_logger
    from kubeflow_utils.spark import step_conf
    log = get_logger(f"kubeflow_utils.step.{call.name}")
    datasets = {k: v for k, v in call.kwargs.items() if k in dataset_names}

    if cfg.step_opt(call.name, "skip_if_exists") and datasets \
            and all(DataStore(u).exists() for u in datasets.values()):
        log.info("skipped: all %d dataset arguments already exist", len(datasets))
        return

    started = time.monotonic()
    with step_conf(cfg.step_opt(call.name, "spark") or {}):
        result = call.fn(**call.kwargs)
    if result is not None:
        raise RunnerError(f"step {call.name!r} returned a {type(result).__name__} — steps "
                          f"communicate through storage; write a dataset instead.")
    missing = {n: u for n, u in datasets.items() if not DataStore(u).exists()}
    if missing:
        listing = "\n".join(f"  - {n}: {u}" for n, u in missing.items())
        raise RunnerError(f"step {call.name!r} finished but these dataset arguments do "
                          f"not exist:\n{listing}\nEvery dataset a step touches must "
                          f"exist when it returns.")
    log.info("ok in %.1fs", time.monotonic() - started)


# ── whole pipeline, locally ──────────────────────────────────────────

def run_local(pipeline_fn: Callable, env: str = "local", only: list[str] | None = None,
              **given: Any) -> dict[str, Any]:
    names = [c.name for c in structure(pipeline_fn)]
    cfg = load_config(pipeline_fn, env, names)
    export_environment(cfg)
    inputs = effective_inputs(pipeline_fn, cfg, given)
    selected = set(only or cfg.only or names)
    unknown = selected - set(names)
    if unknown:
        raise PipelineError(f"--only names unknown steps {sorted(unknown)}; steps are {names}")
    for call in record(pipeline_fn, **inputs):
        if call.name in selected:
            run_step(call, cfg, set(cfg.datasets))
    return inputs


# ── container entrypoint ─────────────────────────────────────────────

def import_obj(dotted: str) -> Any:
    module, _, attr = dotted.partition(":")
    return getattr(importlib.import_module(module), attr)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="kubeflow_utils.runner")
    parser.add_argument("--pipeline", required=True, help="module:function")
    parser.add_argument("--step", required=True)
    parser.add_argument("--env", required=True)
    parser.add_argument("--input", action="append", default=[], help="name=value")
    parser.add_argument("--resolve", action="append", default=[],
                        help="name=/output/path : resolve sentinel inputs and write them")
    ns = parser.parse_args(argv)

    pipeline_fn = import_obj(ns.pipeline)
    names = [c.name for c in structure(pipeline_fn)]
    cfg = load_config(pipeline_fn, ns.env, names)
    given = dict(p.split("=", 1) for p in ns.input)

    if ns.resolve:                                   # the framework's first component
        resolved = resolve_sentinels({k: decode(v, str) for k, v in given.items()})
        for pair in ns.resolve:
            name, path = pair.split("=", 1)
            with open(path, "w") as f:
                f.write(json.dumps(resolved[name]))
        return

    export_environment(cfg)
    inputs = effective_inputs(pipeline_fn, cfg, given)
    calls = [c for c in record(pipeline_fn, **inputs) if c.name == ns.step]
    if not calls:
        raise PipelineError(f"no step {ns.step!r}; steps are {names}")
    run_step(calls[0], cfg, set(cfg.datasets))


if __name__ == "__main__":
    main()
