"""Path contract: methods accept relative paths or the store's own URIs;
everything returned is a full engine-usable URI; foreign URIs raise."""
import pathlib
import pytest
from kubeflow_utils.fs_io import open_data_store


def test_remote_roundtrip_and_uris():
    store = open_data_store("memory://bucket/prefix")
    with store.open("a.parquet", "wb") as f:
        f.write(b"x")
    with store.open("b.txt", "wb") as f:
        f.write(b"y")
    assert all(p.startswith("memory://bucket/prefix/") for p in store.ls())
    globbed = store.glob("*.parquet")
    assert globbed == ["memory://bucket/prefix/a.parquet"]
    assert store.exists(globbed[0]) and store.exists("a.parquet")
    assert store.exists(store.join("a.parquet"))


def test_foreign_uri_raises():
    store = open_data_store("memory://bucket/prefix")
    with pytest.raises(ValueError, match="not under this store"):
        store.exists("s3://other-bucket/key")


def test_local_returns_plain_abs_paths(tmp_path):
    (tmp_path / "c.parquet").write_bytes(b"z")
    store = open_data_store(str(tmp_path))
    globbed = store.glob("*.parquet")
    assert globbed and globbed[0].startswith("/") and "://" not in globbed[0]
    assert store.exists(globbed[0]) and store.exists("c.parquet")


def test_relative_local_path_absolutized(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    pathlib.Path("rel").mkdir()
    pathlib.Path("rel/x.parquet").write_bytes(b"z")
    store = open_data_store("./rel")
    assert store.uri.startswith("/") and store.exists("x.parquet")
