"""v0.5: @step/@pipeline recording, config rules, runner, compile, CLI."""
import datetime
import json
import os
import pathlib
import sys
import textwrap
import pytest

from kubeflow_utils.decorators import PipelineError, structure, record
from kubeflow_utils.config import load_config, load_baked
from kubeflow_utils.compile import compile_spec, render_dag
from kubeflow_utils import runner as R

STEPS_SRC = '''
import json, pathlib
from kubeflow_utils import step

@step
def pull(raw: str, snap_date: str) -> None:
    pathlib.Path(raw).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(raw).write_text(json.dumps({"date": snap_date, "rows": [1, 2, 3]}))

@step
def process(raw: str, processed: str, min_balance: int) -> None:
    rows = json.loads(pathlib.Path(raw).read_text())["rows"]
    pathlib.Path(processed).write_text(str(sum(r for r in rows if r >= min_balance)))

@step
def publish(processed: str, published: str) -> None:
    pathlib.Path(published).mkdir(parents=True, exist_ok=True)
    pathlib.Path(published, "out.txt").write_text(pathlib.Path(processed).read_text())

def helper_not_a_step(x):
    return x
'''

PIPELINE_SRC = '''
from kubeflow_utils import pipeline
from mysteps import pull, process, publish

@pipeline
def customer(raw: str, processed: str, published: str, snap_date: str = "today", min_balance: int = 0):
    pull(raw, snap_date)
    process(raw, processed, min_balance)
    publish(processed, published)
'''

LOCAL_YAML = '''
params:   {{base_path: "{base}"}}
datasets:
  raw:       "{{base_path}}/snap_date={{snap_date}}/raw.json"
  processed: "{{base_path}}/snap_date={{snap_date}}/processed.txt"
  published: "{{base_path}}/published/"
settings: {{SNOWFLAKE_ACCOUNT: acct-dev, OAUTH_TOKEN_URL: "https://x"}}
steps:    {{pull: {{skip_if_exists: true}}}}
'''

KFP_YAML = '''
datasets:
  raw:       "{base_path}/snap_date={snap_date}/raw/data.json"
  processed: "{base_path}/snap_date={snap_date}/processed.txt"
  published: "{base_path}/published/"
settings: {OAUTH_TOKEN_URL: "https://x"}
steps:
  pull:    {cpu: "4", memory: "16Gi", retries: 2}
  publish: {cpu: "8", memory: "32Gi"}
parallel: []
'''

TIER_YAML = '''
params:   {{base_path: "{base}"}}
settings: {{SNOWFLAKE_ACCOUNT: acct-{tier}}}
secrets:  {{CLIENT_ID: "vault:{tier}#id", CLIENT_SECRET: "vault:{tier}#secret"}}
'''


@pytest.fixture
def repo(tmp_path, monkeypatch):
    (tmp_path / "pipelines" / "environments").mkdir(parents=True)
    (tmp_path / "mysteps.py").write_text(STEPS_SRC)
    (tmp_path / "pipelines" / "customer.py").write_text(PIPELINE_SRC)
    (tmp_path / "pipelines" / "kfp.yaml").write_text(KFP_YAML)
    for tier in ("uat", "prod"):
        (tmp_path / "pipelines" / "environments" / f"{tier}.yaml").write_text(
            TIER_YAML.format(base=f"{tmp_path}/{tier}", tier=tier))
    (tmp_path / "pipelines" / "environments" / "local.yaml").write_text(
        LOCAL_YAML.format(base=f"{tmp_path}/data"))
    monkeypatch.syspath_prepend(str(tmp_path))
    monkeypatch.syspath_prepend(str(tmp_path / "pipelines"))
    for name in ("mysteps", "customer"):
        sys.modules.pop(name, None)
    import customer
    # fake secret store: the seam callable
    from kubeflow_utils import lake_broker
    monkeypatch.setattr(lake_broker, "fetch_secret", lambda ref: f"value-of-{ref}")
    from kubeflow_utils import snowflake
    monkeypatch.setattr(snowflake, "request_token", lambda url, i, s: ("tok-" + i, 9e12))
    for var in ("CLIENT_ID", "CLIENT_SECRET", "OAUTH_TOKEN"):
        monkeypatch.delenv(var, raising=False)
    return customer.customer, tmp_path


# ── recording / structure ────────────────────────────────────────────
def test_recording_reads_structure(repo):
    fn, _ = repo
    assert [c.name for c in structure(fn)] == ["pull", "process", "publish"]


def test_value_passing_between_steps_is_refused(tmp_path):
    from kubeflow_utils import step, pipeline
    @step
    def load(p: str): return None
    @step
    def use(x): return None
    @pipeline
    def bad(p: str):
        df = load(p)
        use(df)
    with pytest.raises(PipelineError, match="communicate through storage"):
        structure(bad)


def test_branching_around_steps_is_refused():
    from kubeflow_utils import step, pipeline
    @step
    def a(p: str): return None
    @step
    def b(p: str): return None
    @pipeline
    def bad(p: str):
        a(p)
        if "2" in p:
            b(p)
    with pytest.raises(PipelineError, match="structure must be fixed"):
        structure(bad)


def test_pipeline_runs_as_plain_python(repo, tmp_path):
    fn, root = repo
    d = tmp_path / "plain"
    fn(raw=f"{d}/raw.json", processed=f"{d}/p.txt", published=f"{d}/pub/",
       snap_date="2026-08-06", min_balance=2)
    assert (d / "pub/out.txt").read_text() == "5"          # 2 + 3, no framework involved


# ── config rules ─────────────────────────────────────────────────────
def test_baked_key_in_environment_is_refused(repo):
    fn, root = repo
    (root / "pipelines/environments/prod.yaml").write_text(
        TIER_YAML.format(base="s3://p", tier="prod") + "steps: {pull: {memory: 64Gi}}\n")
    with pytest.raises(PipelineError, match="baked at compile"):
        load_config(fn, "prod", ["pull", "process", "publish"])


def test_kfp_is_not_an_environment(repo):
    fn, _ = repo
    with pytest.raises(PipelineError, match="cluster runtime config, not an environment"):
        load_config(fn, "kfp", ["pull"])


def test_tiers_must_agree(repo):
    fn, root = repo
    (root / "pipelines/environments/uat.yaml").write_text(
        "params: {base_path: s3://u}\nsettings: {SNOWFLAKE_ACCOUNT: a}\n")   # no secrets
    with pytest.raises(PipelineError, match="must set the same keys"):
        load_config(fn, "prod", ["pull", "process", "publish"])


def test_placeholder_must_be_an_input(repo):
    fn, root = repo
    (root / "pipelines/environments/local.yaml").write_text(
        'params: {base_path: ./d}\ndatasets: {raw: "{base_path}/{snap_dat}/r", processed: "x", published: "y"}\n')
    with pytest.raises(PipelineError, match=r"\{snap_dat\} which is not a pipeline input"):
        load_config(fn, "local", ["pull", "process", "publish"])


def test_secret_shaped_setting_refused(repo):
    fn, root = repo
    (root / "pipelines/environments/local.yaml").write_text(
        "params: {base_path: ./d}\nsettings: {SNOWFLAKE_PASSWORD: hunter2}\n")
    with pytest.raises(PipelineError, match="looks like a secret"):
        load_config(fn, "local", ["pull", "process", "publish"])


def test_unknown_step_name_in_config(repo):
    fn, root = repo
    (root / "pipelines/environments/local.yaml").write_text(
        "params: {base_path: ./d}\nsteps: {pulll: {skip_if_exists: true}}\n")
    with pytest.raises(PipelineError, match="names step 'pulll'"):
        load_config(fn, "local", ["pull", "process", "publish"])


# ── running ──────────────────────────────────────────────────────────
def test_run_local_end_to_end_with_today_and_skip(repo, caplog, monkeypatch):
    fn, root = repo
    inputs = R.run_local(fn, env="local", min_balance=2)
    today = datetime.date.today().isoformat()
    assert inputs["snap_date"] == today                       # "today" resolved once
    run_dir = root / "data" / f"snap_date={today}"
    assert (run_dir / "processed.txt").read_text() == "5"
    assert (root / "data/published/out.txt").read_text() == "5"
    assert os.environ["KUBEFLOW_UTILS_SNOWFLAKE_ACCOUNT"] == "acct-dev"
    caplog.set_level("INFO")
    R.run_local(fn, env="local", min_balance=3)               # pull skipped, process re-ran
    assert any("skipped" in r.message for r in caplog.records)
    assert (run_dir / "processed.txt").read_text() == "3"


def test_env_valued_inputs_cannot_be_overridden(repo):
    fn, _ = repo
    with pytest.raises(PipelineError, match="come from the environment config"):
        R.run_local(fn, env="local", base_path="/elsewhere")


def test_only_selects_steps(repo, caplog):
    fn, root = repo
    R.run_local(fn, env="local", snap_date="2026-08-06", only=["pull"])
    assert (root / "data/snap_date=2026-08-06/raw.json").exists()
    assert not (root / "data/snap_date=2026-08-06/processed.txt").exists()
    with pytest.raises(PipelineError, match="unknown steps"):
        R.run_local(fn, env="local", only=["nope"])


def test_step_forgetting_to_write_fails_postcheck(repo, tmp_path):
    from kubeflow_utils import step
    from kubeflow_utils.decorators import StepCall
    from kubeflow_utils.config import Config
    @step
    def lazy(out: str): return None
    call = StepCall(lazy.__wrapped_fn__, {"out": f"{tmp_path}/never.txt"})
    with pytest.raises(R.RunnerError, match="do not exist"):
        R.run_step(call, Config(env="local"), {"out"})


def test_container_entrypoint_fetches_secrets_and_runs_one_step(repo, monkeypatch):
    fn, root = repo
    base = root / "uat"
    R.main(["--pipeline", "customer:customer", "--step", "pull", "--env", "uat",
            "--input", "snap_date=2026-08-06"])
    assert (base / "snap_date=2026-08-06/raw/data.json").exists()        # kfp.yaml layout
    assert os.environ["CLIENT_ID"] == "value-of-vault:uat#id"            # fetched + exported
    assert os.environ["OAUTH_TOKEN"] == "tok-value-of-vault:uat#id"      # minted
    assert os.environ["KUBEFLOW_UTILS_SNOWFLAKE_ACCOUNT"] == "acct-uat"


def test_resolve_component_writes_dates(repo, tmp_path):
    fn, _ = repo
    out = tmp_path / "snap.txt"
    R.main(["--pipeline", "customer:customer", "--step", "resolve", "--env", "uat",
            "--input", "snap_date=today", "--resolve", f"snap_date={out}"])
    assert json.loads(out.read_text()) == datetime.date.today().isoformat()


# ── compile ──────────────────────────────────────────────────────────
def test_compile_spec_inputs_stages_and_baked(repo):
    fn, _ = repo
    spec = compile_spec(fn)
    assert set(spec.inputs) == {"env", "snap_date", "min_balance"}     # datasets/params are NOT inputs
    assert spec.inputs["env"]["choices"] == ["prod", "uat"]
    assert spec.resolve_inputs == ["snap_date"]
    pull = next(s for s in spec.steps if s.name == "pull")
    assert pull.resources == {"cpu": "4", "memory": "16Gi"} and pull.retries == 2
    assert [s.stage for s in spec.steps] == [0, 1, 2]
    assert "resolve-inputs" in render_dag(spec)


def test_validate_catches_undecorated_and_sweeps(repo):
    from kubeflow_utils.validate import validate
    fn, _ = repo
    findings = validate(fn)
    assert any("helper_not_a_step" in f and "not a @step" in f for f in findings)
    assert not any(f.startswith("ERROR") for f in findings)
