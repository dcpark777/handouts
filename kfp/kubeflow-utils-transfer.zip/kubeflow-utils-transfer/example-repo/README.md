# kubeflow-utils authoring — worked example (v0.5)

Two decorators. Code identical on a laptop and on KFP. Behavior via config.

  src/mypackage/steps.py         @step functions (a steps/ package works too)
  src/mypackage/dates.py         plain helper (business calendar), if you need one
  pipelines/customer.py          @pipeline — a run script; datasets and the
                                 run key arrive as inputs
  pipelines/kfp.yaml             cluster runtime: BAKED config (cpu/memory/
                                 image/retries/parallel) + values uat and
                                 prod share
  pipelines/environments/        exactly the valid --env values
    local.yaml                   complete, standalone
    uat.yaml / prod.yaml         deltas over kfp.yaml

Commands:
  kfu run     customer                      # laptop; local.yaml; snap_date="today"
  kfu run     customer --snap_date 2026-08-06 --only process
  kfu check   customer                      # CI: validate + DAG
  kfu compile customer                      # once -> pipeline.yaml
  kfu submit  customer --env prod           # (platform-bound) resolves "today", submits
