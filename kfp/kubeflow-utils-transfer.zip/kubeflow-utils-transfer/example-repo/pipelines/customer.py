"""The pipeline: a run script. Datasets and the run key are INPUTS —
environments/*.yaml supply the datasets; snap_date is passed (local) or
resolved once from "today" (cluster, by the framework's first component).

Call it directly in a notebook: customer(raw=..., processed=..., ...).
"""
from kubeflow_utils import pipeline
from mypackage.steps import pull, process, publish, mirror


@pipeline
def customer(raw: str, processed: str, published: str, mirrored: str,
             snap_date: str = "today", min_balance: int = 0):
    pull(raw, snap_date)
    process(raw, processed, min_balance)
    publish(processed, published)
    mirror(processed, mirrored)
