"""# ── cell: run one step by hand — it's just a function ──
from mypackage.steps import process
process("./data/snap_date=2026-08-06/raw.parquet", "./tmp/p.parquet", min_balance=100)

# ── cell: run the whole pipeline as plain Python (no framework in the loop) ──
from pipelines.customer import customer
customer(raw="./data/snap_date=2026-08-06/raw.parquet", processed="./tmp/p.parquet",
         published="./tmp/pub/", mirrored="./tmp/mirror/", snap_date="2026-08-06")

# ── cell: the same, through the runner (config, secrets, checks, skip, only) ──
from kubeflow_utils.runner import run_local
run_local(customer, env="local", snap_date="2026-08-06")
"""
