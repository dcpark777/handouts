"""Component entrypoints. @step is the only framework touch; behavior
(skip, resources, spark conf) lives in config, not here."""
import polars as pl
from kubeflow_utils import step, DataStore, Snowflake, Spark


@step
def pull(raw: str, snap_date: str) -> None:
    conn = Snowflake().get_connection()
    df = pl.read_database(f"select * from customers where as_of = '{snap_date}'", conn)
    df.write_parquet(raw)


@step
def process(raw: str, processed: str, min_balance: int) -> None:
    df = pl.read_parquet(raw)
    df.filter(pl.col("balance") >= min_balance).write_parquet(processed)


@step
def publish(processed: str, published: str) -> None:
    spark = Spark().get_session()                      # per-step conf from config
    df = spark.read.parquet(processed)
    df.write.mode("overwrite").parquet(DataStore(published).uri)   # brokered creds


@step
def mirror(processed: str, mirrored: str) -> None:
    pl.read_parquet(processed).write_parquet(f"{mirrored}/latest.parquet")
