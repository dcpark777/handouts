"""Read-only projections of the ledger: terminal (Rich), PROGRESS.md, progress.html.
Never write state. Never have buttons.

Every command renders in the same order: header · body · summary · Next.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from jinja2 import Environment, FileSystemLoader
from rich import box
from rich.console import Console, Group
from rich.panel import Panel
from rich.rule import Rule
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from .ledger import Ledger, TargetState, runner_alive

TEMPLATES = Path(__file__).parent / "templates"
_env = Environment(loader=FileSystemLoader(str(TEMPLATES)), autoescape=True)

STATE_STYLE = {
    "queued": "grey62", "running": "bold cyan", "blocked": "bold yellow", "done": "bold green",
    "failed": "bold red", "shipped": "bold bright_green", "skipped": "grey50",
}
STATE_GLYPH = {"queued": "·", "running": "▶", "blocked": "?", "done": "✓", "failed": "✗", "shipped": "⇡", "skipped": "–"}


# --------------------------------------------------------------------------- data
def _elapsed(st: TargetState) -> str:
    if not st.started:
        return "-"
    try:
        start = datetime.fromisoformat(st.started)
        end = datetime.now(timezone.utc) if st.state == "running" else datetime.fromisoformat(st.updated)
        s = int((end - start).total_seconds())
        return f"{s // 60}m{s % 60:02d}s" if s >= 60 else f"{s}s"
    except ValueError:
        return "-"


def _label(st: TargetState) -> str:
    lab = st.state
    if st.reason and st.state in ("blocked", "failed", "queued", "running"):
        lab += f" ({st.reason})"
    if st.state == "done" and st.decision:
        lab += f" ({st.decision})"
    return lab


def _detail(st: TargetState) -> str:
    bits = []
    if st.attempts > 1:
        bits.append(f"{st.attempts} sessions")
    if st.failures:
        bits.append(f"{st.failures} fail")
    return " · ".join(bits)


def rows(ledger: Ledger) -> list[dict]:
    out = []
    for st in ledger.all():
        note = st.last_note.splitlines()[0] if st.last_note else ""
        if st.state == "blocked" and st.reason == "question":
            q = ledger.read_artifact(st.id, "question.md") or ""
            body = [l for l in q.splitlines() if not l.lower().startswith("key:")]
            note = "Q: " + (body[0] if body else "")
        out.append({
            "id": st.id, "state": st.state, "label": _label(st), "detail": _detail(st), "reason": st.reason or "",
            "decision": st.decision or "", "attempts": st.attempts, "failures": st.failures, "elapsed": _elapsed(st),
            "cost": f"${st.cost_usd:.2f}", "note": note[:90], "branch": st.branch or "", "base": st.base or "",
            "worktree": st.worktree or "", "session": st.session_id or "", "verifier": st.verifier_ok,
            "summary": ledger.read_artifact(st.id, "summary.md") or "",
            "question": ledger.read_artifact(st.id, "question.md") or "",
            "answer": ledger.read_artifact(st.id, "answer.md") or "",
            "updated": st.updated,
        })
    return out


def header(ledger: Ledger) -> str:
    c = ledger.cfg
    return f"{c.run_id} · {c.wrapper or c.skill} · {c.mode} · {len(c.targets)} targets · parallel {c.parallel} · ${ledger.total_cost():.2f}"


def summary_line(ledger: Ledger) -> str:
    c = ledger.counts()
    parts = []
    for s in ("shipped", "done", "blocked", "running", "queued", "failed", "skipped"):
        if c[s]:
            label = {"done": "to review" if ledger.reviewable() else "done", "blocked": "waiting on you"}.get(s, s)
            parts.append(f"{c[s]} {label}")
    return " · ".join(parts) or "no targets"


# --------------------------------------------------------------------------- terminal
def rule(console: Console, title: str = "") -> None:
    console.print(Rule(title, style="grey50", align="left"))


def print_header(ledger: Ledger, console: Console) -> None:
    c = ledger.cfg
    alive = runner_alive(c.dir)
    t = Text()
    t.append(c.run_id, style="bold")
    t.append(f"  {c.wrapper or c.skill}", style="cyan")
    t.append(f"  {c.mode}", style="grey62")
    t.append(f"  ·  {len(c.targets)} targets · parallel {c.parallel} · ${ledger.total_cost():.2f}", style="grey62")
    t.append("  ·  runner active" if alive else "  ·  runner idle", style="green" if alive else "grey50")
    console.print(t)


def print_next(ledger: Ledger, console: Console) -> None:
    console.print(Text.assemble(("\nNext  ", "bold"), (ledger.next_hint(), "bold cyan")))


def status_table(ledger: Ledger) -> Table:
    t = Table(box=box.SIMPLE_HEAD, header_style="grey62", pad_edge=False, expand=True, show_edge=False)
    t.add_column("", width=1)
    t.add_column("target", style="bold", no_wrap=True)
    t.add_column("state", no_wrap=True)
    t.add_column("detail", style="grey62", no_wrap=True)
    t.add_column("elapsed", justify="right", no_wrap=True)
    t.add_column("cost", justify="right", no_wrap=True)
    t.add_column("note", overflow="ellipsis", no_wrap=True, ratio=1)
    for r in rows(ledger):
        style = STATE_STYLE.get(r["state"], "")
        t.add_row(Text(STATE_GLYPH[r["state"]], style=style), r["id"], Text(r["label"], style=style),
                  r["detail"], r["elapsed"], r["cost"], r["note"])
    return t


def rich_status(ledger: Ledger, console: Console | None = None) -> None:
    console = console or Console()
    print_header(ledger, console)
    console.print()
    console.print(status_table(ledger))
    console.print(Text(summary_line(ledger), style="grey62"))
    print_next(ledger, console)


def plan_panel(cfg, problems: list[str]) -> Panel:
    body = Table.grid(padding=(0, 2))
    body.add_column(style="grey62", justify="right")
    body.add_column()
    body.add_row("skill", f"[cyan]{cfg.wrapper or cfg.skill}[/cyan]" + (f"  [grey62](wrapper for {cfg.skill})[/grey62]" if cfg.wrapper else ""))
    body.add_row("mode", cfg.mode)
    ids = ", ".join(t.id for t in cfg.targets[:8]) + (f" … +{len(cfg.targets) - 8}" if len(cfg.targets) > 8 else "")
    body.add_row("targets", f"{len(cfg.targets)}  [grey62]{ids}[/grey62]")
    body.add_row("limits", f"parallel {cfg.parallel} · max_attempts {cfg.max_attempts} · timeout {cfg.timeout_s}s · turns/session {cfg.max_turns_per_session}")
    body.add_row("budget", f"${cfg.budget_usd:.2f}/target · ${cfg.run_budget_usd:.2f}/run")
    body.add_row("verifier", cfg.verifier or "[grey50]none[/grey50]")
    body.add_row("context", ", ".join(cfg.context) or "[grey50]none[/grey50]")
    body.add_row("worker", cfg.worker)
    body.add_row("gates", "plan→run · questions→answer · done→review→ship")
    body.add_row("workers", "[grey62]never push · never open PRs · never write outside their worktree[/grey62]")
    if problems:
        pt = Text("\nPreflight problems\n", style="bold red")
        for p in problems:
            pt.append(f"  ✗ {p}\n", style="red")
        content = Group(body, pt)
        style = "red"
    else:
        content = Group(body, Text("\n✓ preflight ok", style="green"))
        style = "green"
    return Panel(content, title=f"Plan  {cfg.run_id}", title_align="left", border_style=style, box=box.ROUNDED)


def question_panel(key: str, members: list[str], text: str) -> Panel:
    body = [l for l in text.splitlines() if not l.lower().startswith("key:")]
    title = f"{key}  ·  {len(members)} target{'s' if len(members) != 1 else ''}"
    sub = Text(", ".join(members), style="grey62")
    return Panel(Group(sub, Text(""), Text("\n".join(body).strip())), title=title, title_align="left",
                 border_style="yellow", box=box.ROUNDED)


def review_header(st: TargetState) -> Text:
    v = "ok" if st.verifier_ok else ("—" if st.verifier_ok is None else "FAILED")
    vstyle = "green" if st.verifier_ok else ("grey50" if st.verifier_ok is None else "red")
    t = Text()
    t.append(st.id, style="bold")
    t.append(f"   {st.attempts} session{'s' if st.attempts != 1 else ''}", style="grey62")
    t.append("   verifier ", style="grey62")
    t.append(v, style=vstyle)
    t.append(f"   ${st.cost_usd:.2f}", style="grey62")
    t.append(f"   {st.branch} → {st.base}", style="grey50")
    return t


def summary_block(text: str) -> Panel:
    return Panel(Text(text.strip() or "(no summary)"), title="summary", title_align="left", border_style="grey50", box=box.ROUNDED)


def diff_block(diff: str) -> Syntax | Text:
    if not diff.strip():
        return Text("(no changes)", style="grey50")
    return Syntax(diff, "diff", theme="ansi_dark", line_numbers=False, word_wrap=False)


# --------------------------------------------------------------------------- files
def write_progress(ledger: Ledger) -> None:
    """Called on every ledger change. Both files are pure functions of the ledger."""
    md = [f"# {header(ledger)}", "", f"Phase: **{ledger.phase()}** — Next: `{ledger.next_hint()}`", "",
          "| target | state | attempts | elapsed | cost | note |", "|---|---|---|---|---|---|"]
    rs = rows(ledger)
    for r in rs:
        md.append(f"| {r['id']} | {r['label']} | {r['attempts']} | {r['elapsed']} | {r['cost']} | {r['note'].replace('|', '/')} |")
    md += ["", summary_line(ledger), ""]
    qs = [r for r in rs if r["state"] == "blocked" and r["reason"] == "question"]
    if qs:
        md += ["## Open questions", ""]
        for r in qs:
            md += [f"### {r['id']}", "", r["question"].strip(), ""]
    if ledger.phase() in ("reviewing", "shipping", "complete") or ledger.cfg.mode == "report":
        done = [r for r in rs if r["summary"]]
        if done:
            md += ["## Summaries", ""]
            for r in done:
                md += [f"### {r['id']} — {r['label']}", "", "```", r["summary"].strip(), "```", ""]
    (ledger.cfg.dir / "PROGRESS.md").write_text("\n".join(md))
    try:
        html = _env.get_template("progress.html").render(
            header=header(ledger), phase=ledger.phase(), next_hint=ledger.next_hint(),
            summary=summary_line(ledger), rows_json=json.dumps(rs), rows=rs,
            generated=datetime.now(timezone.utc).isoformat(timespec="seconds"))
        (ledger.cfg.dir / "progress.html").write_text(html)
    except Exception:
        pass
