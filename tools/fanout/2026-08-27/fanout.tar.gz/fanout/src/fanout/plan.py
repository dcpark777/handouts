"""fanout plan: interview once, write run.yaml, preflight, summarize, gate."""
from __future__ import annotations

import os
import shutil
from pathlib import Path

from . import git_ops
from .config import RunConfig, Target, load_targets, new_run_id, personal_config, runs_dir


def skill_dirs() -> list[Path]:
    dirs = [Path.cwd() / ".claude" / "skills", Path.home() / ".claude" / "skills"]
    extra = os.environ.get("FANOUT_SKILL_PATH")
    if extra:
        dirs = [Path(p) for p in extra.split(os.pathsep)] + dirs
    return [d for d in dirs if d.exists()]


def find_skill(name: str) -> Path | None:
    for d in skill_dirs():
        p = d / name / "SKILL.md"
        if p.exists():
            return p
    return None


def wrapper_name(skill: str) -> str:
    return skill if skill.startswith("fanout-") else f"fanout-{skill}"


def skill_declares_contract(skill_md: Path) -> bool:
    text = skill_md.read_text()
    return "SUMMARY.md" in text and "QUESTION.md" in text


def preflight(cfg: RunConfig) -> list[str]:
    """Returns a list of problems. Empty means go."""
    problems: list[str] = []
    if cfg.worker == "sdk":
        if not find_skill(cfg.wrapper or cfg.skill):
            problems.append(f"skill {cfg.wrapper or cfg.skill!r} not found in {[str(d) for d in skill_dirs()] or 'any skill dir'}")
        try:
            import claude_agent_sdk  # noqa: F401
        except ImportError:
            problems.append("claude-agent-sdk not importable (pip install fanout[sdk])")
    for t in cfg.targets:
        p = Path(t.path)
        if not p.exists():
            problems.append(f"{t.id}: path does not exist: {t.path}")
            continue
        if not git_ops.is_repo(p):
            problems.append(f"{t.id}: not a git repo: {t.path}")
            continue
        if t.subpath and not (p / t.subpath).exists():
            problems.append(f"{t.id}: subpath missing: {t.subpath}")
        # another live run already holds a branch on this repo?
        for other in runs_dir().iterdir():
            if other.name == cfg.run_id or not (other / "run.yaml").exists():
                continue
            wt = other / "worktrees" / t.id
            if wt.exists() and (other / "runner.json").exists():
                problems.append(f"{t.id}: worktree held by active run {other.name}")
    for c in cfg.context:
        if not Path(c).exists():
            problems.append(f"context file missing: {c}")
    if cfg.verifier and shutil.which(cfg.verifier.split()[0]) is None and not cfg.verifier.startswith(("./", "python", "make")):
        problems.append(f"verifier command not on PATH: {cfg.verifier.split()[0]}")
    free = shutil.disk_usage(runs_dir()).free
    if free < 500 * 1024 * 1024:
        problems.append(f"low disk under {runs_dir()}: {free // 1_000_000} MB free")
    return problems


def build_config(skill: str, sources: tuple[str, ...], **over) -> RunConfig:
    personal = personal_config()
    targets = load_targets(*sources)
    cfg = RunConfig(
        run_id=over.pop("run_id", None) or new_run_id(skill),
        skill=skill,
        targets=targets,
        parallel=over.pop("parallel", None) or personal.get("parallel", 3),
        budget_usd=over.pop("budget_usd", None) or personal.get("budget_usd", 5.0),
        **{k: v for k, v in over.items() if v is not None},
    )
    for t in cfg.targets:
        if t.base is None and Path(t.path).exists() and git_ops.is_repo(Path(t.path)):
            t.base = git_ops.default_branch(Path(t.path))
    return cfg
