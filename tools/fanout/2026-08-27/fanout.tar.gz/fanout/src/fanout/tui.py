"""Review screen (Textual). One screen, one job: decide on finished targets with confidence.

Left: the batch. Right: summary + diff for the selected target.
Keys: j/k or ↑/↓ move · a approve · r reject (asks for a note) · s skip · n note · d toggle summary/diff · q done.
Writes only the decisions the CLI's `review` writes; shipping stays in the CLI after this screen exits.
"""
from __future__ import annotations

from pathlib import Path

from rich import box
from rich.console import Group
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Footer, Header, Input, Label, ListItem, ListView, Static

from . import git_ops
from .ledger import Ledger, TargetState

DECISION_GLYPH = {"approved": "✓", "rejected": "↩", None: "·"}


class NoteModal(ModalScreen[str | None]):
    """One-line input for a reject reason or a note."""

    DEFAULT_CSS = """
    NoteModal { align: center middle; }
    #box { width: 80; height: auto; border: round $accent; padding: 1 2; background: $surface; }
    """

    def __init__(self, title: str) -> None:
        super().__init__()
        self._title = title

    def compose(self) -> ComposeResult:
        with Vertical(id="box"):
            yield Label(self._title)
            yield Input(placeholder="type, then Enter · Esc to cancel", id="note")

    def on_mount(self) -> None:
        self.query_one(Input).focus()

    @on(Input.Submitted)
    def _submit(self, ev: Input.Submitted) -> None:
        self.dismiss(ev.value.strip() or None)

    def key_escape(self) -> None:
        self.dismiss(None)


class ReviewApp(App[None]):
    TITLE = "fanout review"
    CSS = """
    #left { width: 34; border-right: solid $panel; }
    #right { width: 1fr; }
    #hdr { height: auto; padding: 0 1; background: $panel; }
    #body { height: 1fr; padding: 0 1; }
    ListItem { padding: 0 1; }
    ListItem.approved { color: $success; }
    ListItem.rejected { color: $warning; }
    ListItem.skipped { color: $text-muted; }
    """
    BINDINGS = [
        Binding("j,down", "next", "next", show=False),
        Binding("k,up", "prev", "prev", show=False),
        Binding("a", "approve", "approve"),
        Binding("r", "reject", "reject"),
        Binding("s", "skip", "skip"),
        Binding("n", "note", "note"),
        Binding("d", "toggle", "summary/diff"),
        Binding("q", "quit", "done"),
    ]

    def __init__(self, ledger: Ledger, targets: list[TargetState]) -> None:
        super().__init__()
        self.ledger = ledger
        self.targets = targets
        self.show_diff = True
        self._diff_cache: dict[str, str] = {}

    # ---------------------------------------------------------------- layout
    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Horizontal():
            with Vertical(id="left"):
                yield ListView(*[self._item(st) for st in self.targets], id="list")
            with Vertical(id="right"):
                yield Static("", id="hdr")
                yield VerticalScroll(Static("", id="body"), id="scroll")
        yield Footer()

    def on_mount(self) -> None:
        self.sub_title = f"{len(self.targets)} to review · {self.ledger.cfg.skill}"
        lv = self.query_one(ListView)
        if self.targets:
            lv.index = 0
            self._show(self.targets[0])

    @staticmethod
    def _item_text(st: TargetState) -> tuple[str, str]:
        glyph = DECISION_GLYPH.get(st.decision, "·") if st.state == "done" else ("–" if st.state == "skipped" else "↩")
        cls = st.decision or ("skipped" if st.state == "skipped" else ("rejected" if st.reason == "rework" else ""))
        v = "" if st.verifier_ok is None else (" ✓" if st.verifier_ok else " ✗")
        return f"{glyph} {st.id}{v}", cls

    def _item(self, st: TargetState) -> ListItem:
        text, cls = self._item_text(self.ledger.get(st.id))
        li = ListItem(Label(text))
        if cls:
            li.add_class(cls)
        return li

    # ---------------------------------------------------------------- data
    def _current(self) -> TargetState | None:
        lv = self.query_one(ListView)
        if lv.index is None or not self.targets:
            return None
        return self.ledger.get(self.targets[lv.index].id)

    def _diff(self, st: TargetState) -> str:
        if st.id not in self._diff_cache:
            try:
                self._diff_cache[st.id] = git_ops.diff(Path(st.worktree), st.base or "main")
            except Exception as e:  # noqa: BLE001
                self._diff_cache[st.id] = f"(diff unavailable: {e})"
        return self._diff_cache[st.id]

    def _show(self, st: TargetState) -> None:
        st = self.ledger.get(st.id)
        v = "ok" if st.verifier_ok else ("—" if st.verifier_ok is None else "FAILED")
        hdr = Text()
        hdr.append(f"{st.id}", style="bold")
        hdr.append(f"   {st.state}" + (f" · {st.decision}" if st.decision else ""), style="cyan")
        hdr.append(f"   {st.attempts} sessions · verifier {v} · ${st.cost_usd:.2f}", style="dim")
        hdr.append(f"\n{st.branch} → {st.base}", style="dim")
        self.query_one("#hdr", Static).update(hdr)
        summary = (self.ledger.read_artifact(st.id, "summary.md") or "(no summary)").strip()
        parts = [Panel(Text(summary), title="summary", title_align="left", border_style="grey50", box=box.ROUNDED)]
        if self.show_diff:
            d = self._diff(st)
            parts.append(Syntax(d, "diff", theme="ansi_dark", word_wrap=False) if d.strip() else Text("(no changes)", style="dim"))
        self.query_one("#body", Static).update(Group(*parts))
        self.query_one("#scroll", VerticalScroll).scroll_home(animate=False)

    def _refresh_item(self, st: TargetState) -> None:
        lv = self.query_one(ListView)
        idx = next(i for i, t in enumerate(self.targets) if t.id == st.id)
        item = lv.children[idx]
        text, cls = self._item_text(self.ledger.get(st.id))
        item.query_one(Label).update(text)
        item.remove_class("approved", "rejected", "skipped")
        if cls:
            item.add_class(cls)

    # ---------------------------------------------------------------- events
    @on(ListView.Highlighted)
    def _hl(self, ev: ListView.Highlighted) -> None:
        st = self._current()
        if st:
            self._show(st)

    def action_next(self) -> None:
        self.query_one(ListView).action_cursor_down()

    def action_prev(self) -> None:
        self.query_one(ListView).action_cursor_up()

    def action_toggle(self) -> None:
        self.show_diff = not self.show_diff
        st = self._current()
        if st:
            self._show(st)

    def action_approve(self) -> None:
        st = self._current()
        if not st or st.state != "done":
            return
        self.ledger.update(st.id, decision="approved")
        self.ledger.event(st.id, "done", "approved", "")
        self._refresh_item(st)
        self._show(st)
        self.action_next()

    def action_reject(self) -> None:
        st = self._current()
        if not st or st.state != "done":
            return

        def done(note: str | None) -> None:
            if not note:
                return
            self.ledger.transition(st.id, "queued", "rework", note, decision=None)
            self._refresh_item(st)
            self._show(st)
            self.action_next()

        self.push_screen(NoteModal(f"Reject {st.id} — why? (goes back to the worker)"), done)

    def action_skip(self) -> None:
        st = self._current()
        if not st or st.state != "done":
            return
        self.ledger.transition(st.id, "skipped", "reviewer", "skipped in review")
        self._refresh_item(st)
        self._show(st)
        self.action_next()

    def action_note(self) -> None:
        st = self._current()
        if not st:
            return

        def done(note: str | None) -> None:
            if note:
                self.ledger.event(st.id, st.state, "note", note)

        self.push_screen(NoteModal(f"Note on {st.id}"), done)


def run_review_tui(ledger: Ledger, targets: list[TargetState]) -> None:
    ReviewApp(ledger, targets).run()
