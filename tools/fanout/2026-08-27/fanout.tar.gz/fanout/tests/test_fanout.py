from __future__ import annotations

import json
import subprocess
from pathlib import Path

from fanout.config import RunConfig, resolve_run
from fanout.ledger import Ledger, redact, runner_alive
from fanout.runner import Runner
from fanout.workers.fake import FakeWorker

from conftest import open_run, run_to_quiescence


def plan(cli, targets, *extra):
    r = cli("plan", "hello", "--on", str(targets), "--worker", "fake", "--yes", *extra)
    assert r.exit_code == 0, r.output
    return r


def test_plan_writes_config_and_gate(cli, fleet):
    _, targets, _ = fleet
    r = cli("plan", "hello", "--on", str(targets()), "--worker", "fake", "--mode", "change",
            input="\nn\n")  # verifier blank, then decline the gate
    assert r.exit_code == 0, r.output
    cfg, ledger = open_run()
    assert cfg.skill == "hello" and len(cfg.targets) == 3
    assert not cfg.approved
    assert ledger.phase() == "planning"
    assert "Next" in r.output
    # run refuses without approval and names the fix
    r = cli("run", "--foreground")
    assert r.exit_code != 0 and "plan not approved" in r.output


def test_happy_path_to_review(cli, fleet):
    _, targets, paths = fleet
    plan(cli, targets())
    ledger = run_to_quiescence()
    assert ledger.counts()["done"] == 3
    assert ledger.phase() == "reviewing"
    st = ledger.get("alpha")
    assert st.attempts == 1 and st.branch == f"fanout/{ledger.cfg.run_id}/alpha"
    # branch exists in the target repo, main untouched
    out = subprocess.run(["git", "branch", "--list", "fanout/*"], cwd=paths["alpha"], capture_output=True, text=True).stdout
    assert "alpha" in out
    assert (paths["alpha"] / "hello.txt").read_text() == "hello\n"
    # worktree lives under the run dir, has the change committed and an attempt tag
    wt = Path(st.worktree)
    assert ledger.cfg.dir in wt.parents
    tags = subprocess.run(["git", "tag", "-l"], cwd=wt, capture_output=True, text=True).stdout
    assert "@prepared" in tags and "@attempt-1" in tags
    assert (ledger.cfg.dir / "PROGRESS.md").exists() and (ledger.cfg.dir / "progress.html").exists()
    assert "review" in ledger.next_hint()


def test_questions_grouped_and_answered(cli, fleet):
    _, targets, _ = fleet
    scripts = {
        "alpha": [{"kind": "question", "key": "scope", "text": "Migrate both connections?"}, {"kind": "done"}],
        "beta": [{"kind": "question", "key": "scope", "text": "Migrate both connections?"}, {"kind": "done"}],
        "gamma": [{"kind": "done"}],
    }
    plan(cli, targets(scripts))
    worker = FakeWorker()
    ledger = run_to_quiescence(worker=worker)
    assert ledger.counts()["blocked"] == 2 and ledger.counts()["done"] == 1
    assert ledger.phase() == "blocked"
    assert "answer" in ledger.next_hint() and "2 questions" in ledger.next_hint()
    # review refuses while questions are open and names the fix
    r = cli("review")
    assert r.exit_code != 0 and "fanout answer" in r.output
    # one answer applies to both (same key)
    r = cli("answer", input="both\ny\nn\n")
    assert r.exit_code == 0, r.output
    assert "2 targets" in r.output and "2 answered" in r.output
    assert (ledger.cfg.dir / "targets/alpha/answer.md").read_text() == "both"
    assert ledger.get("alpha").state == "queued" and ledger.get("alpha").reason == "answered"
    # runner picks answers up and continues with the same session
    ledger = run_to_quiescence(worker=worker)
    assert ledger.counts()["done"] == 3
    assert ledger.get("alpha").session_id == "fake-alpha-0"  # resumed, not fresh
    assert ledger.get("alpha").attempts == 2


def test_continuation_on_stall_and_exhaustion(cli, fleet):
    _, targets, _ = fleet
    scripts = {
        "alpha": [{"kind": "stalled"}, {"kind": "done"}],                          # recovers
        "beta": [{"kind": "stalled", "resumable": False}, {"kind": "stalled"}, {"kind": "stalled"}],  # exhausts
        "gamma": [{"kind": "error", "text": "boom"}, {"kind": "done"}],
    }
    plan(cli, targets(scripts), "--max-attempts", "3")
    ledger = run_to_quiescence(worker=FakeWorker())
    a, b, g = ledger.get("alpha"), ledger.get("beta"), ledger.get("gamma")
    assert a.state == "done" and a.attempts == 2
    assert b.state == "failed" and b.reason == "stalled" and b.attempts == 3 and b.failures == 3
    assert "partial.txt" in (ledger.read_artifact("beta", "notes.md") or "")  # NOTES.md carried into the ledger
    assert g.state == "done" and g.attempts == 2
    # partial work from the stalled attempt was committed and tagged, not lost
    tags = subprocess.run(["git", "tag", "-l"], cwd=b.worktree, capture_output=True, text=True).stdout
    assert "@attempt-1" in tags and "@attempt-3" in tags
    assert "failed" in ledger.next_hint() and "retry" in ledger.next_hint()
    # operator retry grants one more attempt
    r = subprocess.run(["fanout", "target", "beta", "retry"], capture_output=True, text=True,
                       env={**__import__("os").environ})
    assert r.returncode == 0, r.stderr
    assert ledger.get("beta").state == "queued"


def test_many_questions_do_not_exhaust_attempts(cli, fleet):
    _, targets, _ = fleet
    qs = [{"kind": "question", "key": f"q{i}", "text": f"question {i}?"} for i in range(5)] + [{"kind": "done"}]
    plan(cli, targets({"alpha": qs}), "--max-attempts", "2")
    worker = FakeWorker()
    for i in range(5):
        ledger = run_to_quiescence(worker=worker)
        assert ledger.get("alpha").state == "blocked", i
        cli("answer", "--target", "alpha", input="ok\n")
    ledger = run_to_quiescence(worker=worker)
    a = ledger.get("alpha")
    assert a.state == "done" and a.attempts == 6 and a.failures == 0


def test_rollover_is_not_a_failure(cli, fleet):
    _, targets, _ = fleet
    plan(cli, targets({"alpha": [{"kind": "rollover"}, {"kind": "rollover"}, {"kind": "done"}]}), "--max-attempts", "2")
    ledger = run_to_quiescence(worker=FakeWorker())
    a = ledger.get("alpha")
    assert a.state == "done" and a.attempts == 3 and a.failures == 0
    assert "other half" in (ledger.read_artifact("alpha", "notes.md") or "")
    assert any(e["reason"] == "rollover" for e in ledger.events() if e["target"] == "alpha")


def test_worker_env_passthrough(cli, fleet, tmp_path):
    _, targets, _ = fleet
    ef = tmp_path / ".env"
    ef.write_text("SNOWFLAKE_TOKEN=abc123456789xyz\n# comment\nJENKINS_URL='https://j'\n")
    plan(cli, targets())
    cfg, ledger = open_run()
    cfg.env_file = str(ef); cfg.env = {"MODE": "x"}; cfg.save()
    cfg, _ = open_run()
    assert cfg.worker_env() == {"MODE": "x", "SNOWFLAKE_TOKEN": "abc123456789xyz", "JENKINS_URL": "https://j"}


def test_throttle_backs_off_without_counting_failure(cli, fleet, monkeypatch):
    monkeypatch.setenv("FANOUT_BACKOFF", "0.05,0.05")
    import importlib, fanout.runner as R
    importlib.reload(R)
    _, targets, _ = fleet
    plan(cli, targets({"alpha": [{"kind": "error", "text": "ThrottlingException: Rate limit exceeded (429)"},
                                  {"kind": "error", "text": "429 too many requests"},
                                  {"kind": "done"}]}), "--max-attempts", "2")
    cfg, ledger = open_run()
    r = R.Runner(cfg, ledger, worker=FakeWorker(), poll_s=0.02)
    r.run()
    a = ledger.get("alpha")
    assert a.state == "done" and a.failures == 0 and a.attempts == 3
    assert sum(1 for e in ledger.events() if e["target"] == "alpha" and e["reason"] == "throttled") == 2


def test_verifier_loop(cli, fleet):
    _, targets, _ = fleet
    scripts = {"alpha": [{"kind": "verify_fail"}, {"kind": "done"}], "beta": [{"kind": "done"}], "gamma": [{"kind": "done"}]}
    plan(cli, targets(scripts), "--verifier", "test ! -e FAIL")
    ledger = run_to_quiescence(worker=FakeWorker())
    a = ledger.get("alpha")
    assert a.state == "done" and a.attempts == 2 and a.verifier_ok is True
    evs = [e for e in ledger.events() if e["target"] == "alpha" and e["reason"] == "verify"]
    assert evs and "verifier failed" in evs[0]["note"]


def test_take_give_and_rewind(cli, fleet):
    _, targets, _ = fleet
    scripts = {"alpha": [{"kind": "stalled"}] * 3}
    plan(cli, targets(scripts), "--max-attempts", "2")
    ledger = run_to_quiescence(worker=FakeWorker())
    assert ledger.get("alpha").state == "failed"
    r = cli("target", "alpha", "take")
    assert r.exit_code == 0 and "claude" in r.output and "give" in r.output
    st = ledger.get("alpha")
    assert st.state == "blocked" and st.reason == "taken"
    # only valid actions are offered
    r = cli("target", "alpha")
    assert "actions: give, skip, rewind" in r.output
    r = cli("target", "alpha", "retry")
    assert r.exit_code != 0 and "not valid" in r.output
    # operator does work, gives it back
    (Path(st.worktree) / "manual.txt").write_text("done by hand\n")
    r = cli("target", "alpha", "give")
    assert r.exit_code == 0
    st = ledger.get("alpha")
    assert st.state == "done"
    assert "completed manually" in (ledger.read_artifact("alpha", "summary.md") or "")
    # rewind to prepared drops everything and requeues
    r = cli("target", "alpha", "rewind", "--to", "prepared")
    assert r.exit_code == 0
    st = ledger.get("alpha")
    assert st.state == "queued" and st.attempts == 0 and not (Path(st.worktree) / "manual.txt").exists()


def test_review_approve_reject_and_no_push(cli, fleet, monkeypatch):
    _, targets, _ = fleet
    plan(cli, targets())
    ledger = run_to_quiescence()
    pushed = []
    monkeypatch.setattr("fanout.git_ops.push", lambda wt, br: pushed.append(br) or "")
    monkeypatch.setattr("fanout.git_ops.pr_create", lambda wt, base, t, b: "https://pr/1")
    # approve alpha, reject beta with note, skip gamma, then decline the ship confirmation
    r = cli("review", input="a\nr\ntoo broad\ns\nn\n")
    assert r.exit_code == 0, r.output
    assert ledger.get("alpha").decision == "approved" and ledger.get("alpha").state == "done"
    b = ledger.get("beta")
    assert b.state == "queued" and b.reason == "rework" and "too broad" in b.last_note
    assert ledger.get("gamma").state == "skipped"
    assert pushed == []  # nothing left the machine without the final yes
    assert ledger.phase() == "running"  # beta is queued for rework
    # rework runs as another attempt with the note in context
    ledger = run_to_quiescence(worker=FakeWorker())
    assert ledger.get("beta").state == "done" and ledger.get("beta").attempts == 2
    # now approve beta and ship both
    r = cli("review", input="a\ny\n")
    assert r.exit_code == 0, r.output
    assert sorted(pushed) == sorted([ledger.get("alpha").branch, ledger.get("beta").branch])
    assert ledger.get("alpha").state == "shipped" and "https://pr/1" in ledger.get("alpha").last_note
    assert ledger.phase() == "complete"


def test_report_mode(cli, fleet, monkeypatch):
    _, targets, paths = fleet
    plan(cli, targets(), "--mode", "report")
    ledger = run_to_quiescence()
    assert ledger.counts()["done"] == 3
    # no file changes in report mode
    for st in ledger.all():
        d = subprocess.run(["git", "diff", "--stat", "main", "HEAD"], cwd=st.worktree, capture_output=True, text=True).stdout
        assert d == ""
    r = cli("review")
    assert r.exit_code == 0 and "aggregate written" in r.output
    assert ledger.phase() == "complete"
    prog = (ledger.cfg.dir / "PROGRESS.md").read_text()
    assert "## Summaries" in prog and "alpha" in prog


def test_crash_recovery_reconciles_running(cli, fleet):
    _, targets, _ = fleet
    plan(cli, targets())
    cfg, ledger = open_run()
    ledger.init_targets()
    # simulate a runner that died mid-flight
    ledger.transition("alpha", "running", None, "attempt 1")
    ledger.update("alpha", worktree=None)
    assert not runner_alive(cfg.dir)
    ledger = run_to_quiescence()
    a = ledger.get("alpha")
    assert a.state == "done"
    assert any(e["note"] == "reconciled after runner restart" for e in ledger.events() if e["target"] == "alpha")


def test_status_and_next_and_runs(cli, fleet):
    _, targets, _ = fleet
    plan(cli, targets())
    r = cli("status")
    assert "queued" in r.output and "Next" in r.output and "fanout run" in r.output
    run_to_quiescence()
    r = cli()  # bare
    assert "review" in r.output
    r = cli("runs")
    assert "hello" in r.output and "reviewing" in r.output
    r = cli("target", "nope")
    assert r.exit_code != 0 and "no target" in r.output


def test_budget_exhaustion(cli, fleet):
    _, targets, _ = fleet
    scripts = {"alpha": [{"kind": "stalled", "cost": 3.0}, {"kind": "stalled", "cost": 3.0}, {"kind": "done"}]}
    plan(cli, targets(scripts), "--budget", "5", "--max-attempts", "5")
    ledger = run_to_quiescence(worker=FakeWorker())
    a = ledger.get("alpha")
    assert a.state == "failed" and a.reason == "budget" and a.cost_usd == 6.0


def test_duplicate_target_ids_rejected(cli, fleet, tmp_path):
    _, _, paths = fleet
    f = tmp_path / "dup.jsonl"
    f.write_text("\n".join(json.dumps({"id": "x", "path": str(paths["alpha"])}) for _ in range(2)))
    r = cli("plan", "hello", "--on", str(f), "--worker", "fake", "--yes")
    assert r.exit_code != 0 and "duplicate" in r.output


def test_plan_accepts_repo_dirs_directly(cli, fleet):
    _, _, paths = fleet
    r = cli("plan", "hello", "--on", str(paths["alpha"]), "--on", str(paths["gamma"]), "--worker", "fake", "--yes")
    assert r.exit_code == 0, r.output
    cfg, _ = open_run()
    assert [t.id for t in cfg.targets] == ["alpha", "gamma"]


def test_redaction():
    assert "[REDACTED]" in redact("token=abcdefghijklmnop123")
    assert "AKIA" not in redact("key AKIAABCDEFGHIJKLMNOP here")
    assert redact("plain text stays") == "plain text stays"


def test_clean_removes_worktrees_and_branches(cli, fleet):
    _, targets, paths = fleet
    plan(cli, targets())
    ledger = run_to_quiescence()
    rid = ledger.cfg.run_id
    r = cli("clean", rid)
    assert r.exit_code == 0, r.output
    assert not (ledger.cfg.dir / "worktrees").exists()
    out = subprocess.run(["git", "branch", "--list", "fanout/*"], cwd=paths["alpha"], capture_output=True, text=True).stdout
    assert out.strip() == ""
    assert (ledger.cfg.dir / "PROGRESS.md").exists()  # ledger kept


def test_review_tui_decisions(cli, fleet):
    """Drive the Textual review screen with the pilot: approve alpha, skip beta, reject gamma with a note."""
    import asyncio
    pytest = __import__("pytest")
    pytest.importorskip("textual")
    from fanout.tui import ReviewApp
    _, targets, _ = fleet
    plan(cli, targets())
    ledger = run_to_quiescence()
    items = ledger.reviewable()
    assert [s.id for s in items] == ["alpha", "beta", "gamma"]

    async def drive():
        app = ReviewApp(ledger, items)
        async with app.run_test(size=(120, 40)) as pilot:
            await pilot.press("a")            # approve alpha, cursor moves to beta
            await pilot.press("s")            # skip beta, cursor moves to gamma
            await pilot.press("r")            # reject gamma -> modal
            await pilot.pause()
            for ch in "too broad":
                await pilot.press(ch)
            await pilot.press("enter")
            await pilot.pause()
            await pilot.press("q")

    asyncio.run(drive())
    assert ledger.get("alpha").decision == "approved" and ledger.get("alpha").state == "done"
    assert ledger.get("beta").state == "skipped"
    g = ledger.get("gamma")
    assert g.state == "queued" and g.reason == "rework" and "too broad" in g.last_note
