---
name: hello
description: Demo skill for fanout's fixture fleet. Appends a line to hello.txt and reports. Use only for testing fanout.
---

# hello

Append the line `hello from fanout` to `hello.txt` at the repo root (create it if missing).

When finished, write `SUMMARY.md`:

```
status: complete
items:
  - hello.txt: done — appended one line
notes: none
```

If `hello.txt` already contains more than 10 lines, do not edit it; write `QUESTION.md` with
`key: hello-too-long` asking whether to truncate or append anyway, and stop.
