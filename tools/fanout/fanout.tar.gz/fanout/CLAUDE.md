# fanout — working notes for Claude Code

Read SPEC.md first (design, states, files, and the cut list). Then README.md (readiness).

## Where things stand
- Deterministic core is complete: `uv run pytest -q` → 18 tests, no model calls, ~10s.
- Dev workflow is uv: `uv sync --extra sdk`, then `uv run fanout ...`. Commit `uv.lock`.
- `src/fanout/workers/sdk.py` has never executed. Everything else has.
- Demo without a model: README "Try it without a model".

## Do this first, in order
1. Confirm `claude-agent-sdk` installs from Artifactory. Check its version and read
   its `ClaudeAgentOptions`, `ClaudeSDKClient`, and `HookMatcher` signatures.
2. Reconcile `workers/sdk.py` against the installed SDK: option names, hook return
   shape, `resume`, `setting_sources`, how a slash-command skill is invoked from
   `client.query()`. Edit only that file.
3. Run one skill in report mode on 2 real repos:
   `fanout plan <skill> --on targets.jsonl --mode report --yes && fanout run --foreground`.
   Report mode changes no files. Check `targets/<id>/session.jsonl` for the tool stream.
4. Only then: a change-mode run with a verifier on 2 repos, `fanout review --no-ship`.

## Rules the code depends on
- `ledger.py` is the only writer of run state. Never write `state.json` or
  `events.jsonl` from anywhere else; never edit files under `~/.fanout/runs/` by hand.
- The runner (`runner.py`) is a plain process. No model calls in the runner. Ever.
- Workers never push, never open PRs, never write outside their worktree. The
  hooks in `sdk.py` enforce this; the preamble states it. Keep both.
- `_ship()` in `cli.py` is the only place anything leaves the machine, and it
  requires an explicit `y` at the prompt. Do not add a `--yes` to it.
- No skill-specific code anywhere in `src/`. If a skill needs something, it goes
  in that skill's wrapper (`fanout-<skill>/SKILL.md`), not here.
- Contract files (`SUMMARY.md`, `QUESTION.md`) are moved to the ledger and never
  committed to a branch. `_apply()` does this; keep the order.

## Do not add
See SPEC.md "Cut (do not re-add)" and "Deferred". If a real run seems to need
one of those, write down why in SPEC.md before building it.

## Conventions
- Every CLI command ends with `_next(ledger)`. Every refusal names the fixing command.
- States are 7; new information goes in `reason`, not a new state.
- Tests use `--worker fake` and a fixture fleet built in `tests/conftest.py`.
  Add a scripted outcome to `workers/fake.py` before adding a runner feature.
