---
name: fanout
description: Apply any Claude Code skill across many repositories at once (a fleet) with isolated branches, automatic retries, batched questions and batched human review. Use this whenever the user wants to run a skill, directive, migration, remediation, audit, or check "across repos", "on all models", "fleet-wide", "on these N repositories", or asks about the status of such a run, its questions, or its review. Also use when the user mentions fanout, a fanout run, or asks what to do next on one.
---

# fanout — driver instructions

You drive the `fanout` CLI on the user's behalf. The CLI is the source of truth;
you narrate it. You never hold run state yourself.

## The workflow (always in this order)

```
fanout plan <skill> --on <repo-dir>... [--mode change|report] [--verifier CMD] [--context FILE...] [--yes]
#   (--on also accepts a targets.jsonl; only needed for per-target params, subpaths, or a custom base)
fanout run                 # detaches; safe to rerun (resumes)
fanout status [--watch]
fanout answer              # walks open questions, grouped by key
fanout review              # approve/reject diffs; one confirmation before anything is pushed
fanout next                # does whatever the run is waiting on
```

Every command prints a `Next:` line. Read it and tell the user in one sentence.
Bare `fanout` prints status. `fanout target <id>` shows one target and the
actions valid for it (`retry`, `skip`, `rewind`, `take`, `give`).

## Hard rules

1. **Never answer a worker's question yourself.** `fanout answer` shows questions
   from the workers. Relay each question to the user verbatim and wait. Enter
   only the user's words as the answer. If the user is not present, stop and
   report the open questions.
2. **Never approve, reject, or ship on your own.** `fanout review` is a human
   gate. Show the summary and the diff stat; ask the user for a/r/s per target;
   at the final "Push N branches and open PRs?" prompt, ask the user explicitly
   and answer only what they say. Default to no.
3. **Never run `fanout plan` with `--yes` unless the user has seen the plan
   summary** and said yes. Show them the plan first.
4. Do not edit files inside `~/.fanout/runs/`. State is written only by the CLI.
5. Do not start a second run on the same repos while one is active
   (`fanout runs` shows active runs).

## Targets file

`targets.jsonl`, one JSON object per line:

```
{"id": "bank-foo", "path": "~/repos/bank-foo", "params": {"cves": ["CVE-2026-1234"]}}
{"id": "risk-svc-model", "path": "~/repos/risk-svc", "subpath": "models/scorer", "base": "develop"}
```

`id` must be unique. `params` are passed to the skill for that target only.
If the user just gives repo paths and no per-target params, pass them straight to
`--on` (repeat the flag); write `targets.jsonl` only when params or subpaths are needed.

## Typical session

1. User: "run the remediator on these five repos."
2. You write `targets.jsonl`, run `fanout plan vuln-remediator --on targets.jsonl`
   (answer the interview from what the user told you; ask if unsure), show the
   plan summary, ask "approve?".
3. On yes: `fanout run`. Report the `Next:` line.
4. Later: `fanout status`. If questions are open, `fanout answer` and relay
   them one group at a time.
5. When targets are done: `fanout review`. Show each summary + diff stat,
   collect the user's decision, and stop at the push confirmation for an
   explicit yes.

## When something is wrong with one target

`fanout target <id>` shows its timeline, question, summary, and the exact
command to open its worktree and resume the session. Offer `take` if the user
wants to work on it by hand; remind them to `give` when done.

## Reference

Skill authors: `references/skill-authoring.md` explains how a skill declares
"done" and asks questions so it fans out without a wrapper.
