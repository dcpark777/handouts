# Writing skills that fan out

fanout runs your skill unattended in one session per repo. The runner reads
two files to know what happened. Everything else is up to you.

## The contract (the preamble supplies this; you can also state it in the skill)

**Done:** write `SUMMARY.md` at the repo root (or scope root) and stop.

```
status: complete            # or partial
items:
  - CVE-2026-1234: done — bumped requests to 2.32.4
  - CVE-2026-5678: skipped — not present in this repo
notes: ran pytest; one pre-existing failure in test_legacy.py unrelated to this change
```

**Need a decision:** write `QUESTION.md` and stop.

```
key: multiple-snowflake-connections
This repo has two Snowflake connections (etl and scoring). Migrate both to OAuth,
or only the scoring one used by the model?
A) both  B) scoring only  C) neither, flag for manual
Recommendation: A
```

`key` is a short slug for the *kind* of question. Reuse the same key across
repos; the operator answers once and it applies everywhere. One question per file.

**Long jobs:** keep `NOTES.md` (Done / In progress / Next) updated as you go.
If your session ends early, the next one starts from it. fanout keeps it out
of the branch.

## Three levels of accommodation

1. **Native** — the skill mentions SUMMARY.md and QUESTION.md itself. fanout
   uses it directly.
2. **Preamble only** — the skill is interactive but well-behaved. The preamble
   (system prompt) overrides its habits. Most skills land here.
3. **Wrapper** — the skill needs more: a done condition it doesn't state, an
   argument mapping, steps to skip. Create `fanout-<skill>/SKILL.md` that
   invokes the original and adds the contract. `fanout plan` picks the wrapper
   up automatically when it exists.

## Rules that make a skill fan out well

- State your done condition. "Finish when all listed CVEs are addressed or
  explicitly skipped" beats "fix the vulnerabilities".
- Prefer one question with options over an open question. Include a recommendation.
- Be idempotent. The runner may resume you after a stall; check the branch
  state before redoing work.
- Commit as you go with clear messages. The operator reviews the branch, not
  your transcript.
- Never push, never open PRs, never touch other repos. Hooks deny these anyway;
  a skill that tries just wastes an attempt.
- If a verifier is configured, run it before writing SUMMARY.md. If it fails
  and you can't fix it, say so under `notes`.
- Per-target parameters arrive as `params` in the preamble (JSON). Read them
  first.

## Report-mode skills

Set `--mode report` at plan time. Change nothing; write findings in
SUMMARY.md. fanout aggregates all summaries into PROGRESS.md. This is how
you answer "which repos do X" across the fleet with evidence.

## Standing answers

When the operator answers a grouped question, `fanout answer` can append a
"Standing answer — key: ..." section to your wrapper. Read those sections
before asking: if a standing answer exists for your key, use it and don't ask.
