# fanout

Apply any Claude Code skill across a fleet of repos. Isolated branch per target,
automatic retries and continuation, questions batched and grouped, one human
review gate before anything is pushed.

```
uv sync --extra sdk           # dev: editable install + lockfile
uv run pytest -q
pip install fanout            # teammates, from Artifactory once published
fanout plan vuln-remediator --on ~/repos/a --on ~/repos/b --verifier "pytest -q"
# or --on targets.jsonl when targets need params / subpaths
fanout run
fanout status --watch
fanout answer
fanout review
```

Every command prints `Next:`. Bare `fanout` prints status. `fanout next` does
whatever the run is waiting on. See `SPEC.md` for the design and the list of
things deliberately cut; see `skill/fanout/` for the Claude-driver skill and the
skill-authoring guide.

## Try it without a model

```
export FANOUT_HOME=/tmp/fanout-demo
python -c "
import json,pathlib,subprocess
for n in ['alpha','beta']:
    p=pathlib.Path('/tmp/fleet')/n; p.mkdir(parents=True,exist_ok=True)
    subprocess.run(['git','init','-q','-b','main'],cwd=p); (p/'hello.txt').write_text('hi\n')
    subprocess.run(['git','add','-A'],cwd=p); subprocess.run(['git','-c','user.name=d','-c','user.email=d@d','commit','-qm','init'],cwd=p)
open('/tmp/targets.jsonl','w').write('\n'.join(json.dumps({'id':n,'path':f'/tmp/fleet/{n}'}) for n in ['alpha','beta'])+'\n')
"
fanout plan hello --on /tmp/targets.jsonl --worker fake --yes
fanout run --foreground
fanout review --no-ship
```

## Layout

```
src/fanout/
  cli.py        the nine verbs
  config.py     run.yaml, targets.jsonl
  ledger.py     state machine, events, redaction — the only writer of run state
  runner.py     the orchestrator (a plain process; never a model)
  git_ops.py    worktrees, branches, attempt tags, diffs, rebase, push
  plan.py       interview, preflight, plan summary
  render.py     PROGRESS.md, progress.html, terminal table (read-only views)
  workers/      base.py (contract) · sdk.py (Claude Agent SDK) · fake.py (tests/demos)
  templates/    preamble.md (the worker contract) · progress.html
skill/fanout/   SKILL.md (driver) · references/skill-authoring.md
tests/          fixture fleet + 14 tests, no model calls
```

## Status

Deterministic core complete and tested. `workers/sdk.py` is written against
the documented Claude Agent SDK surface but not yet verified in a real
environment — see SPEC.md "Verify before building".

## Readiness (Aug 25, 2026)

Ready: install from the wheel, run the fixture fleet with `--worker fake`, exercise every verb.
Not yet: a real skill on a real repo. Blockers, in order:

1. `workers/sdk.py` has never executed. Verify option names, hook return shape, resume, and
   skill invocation against the installed SDK version. Expect edits to this one file.
2. Confirm `claude-agent-sdk` (Python) is on Artifactory under that name.
3. Confirm managed-settings gates apply under the SDK, and that the policy owner is fine
   with `fanout review` pushing via git after human approval.
4. `_ship` assumes `gh` is installed and authenticated against internal GitHub.
5. The driver skill (`skill/fanout/SKILL.md`) is untested against a real Claude session.

First real run: `fanout plan <skill> --on targets.jsonl --mode report` on 2–3 repos.
Report mode changes nothing, so it's the safe way to find out whether the SDK worker works.
