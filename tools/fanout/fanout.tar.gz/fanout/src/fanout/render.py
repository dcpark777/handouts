"""Read-only projections of the ledger. Never write state. Never have buttons."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from jinja2 import Environment, FileSystemLoader
from rich.console import Console
from rich.table import Table

from .ledger import Ledger, TargetState

TEMPLATES = Path(__file__).parent / "templates"
_env = Environment(loader=FileSystemLoader(str(TEMPLATES)), autoescape=True)

STATE_STYLE = {
    "queued": "dim", "running": "cyan", "blocked": "yellow", "done": "green",
    "failed": "red", "shipped": "bold green", "skipped": "dim",
}


def _elapsed(st: TargetState) -> str:
    if not st.started:
        return "-"
    try:
        start = datetime.fromisoformat(st.started)
        end = datetime.fromisoformat(st.updated) if st.state not in ("running",) else datetime.now(timezone.utc)
        s = int((end - start).total_seconds())
        return f"{s // 60}m{s % 60:02d}s" if s >= 60 else f"{s}s"
    except ValueError:
        return "-"


def _label(st: TargetState) -> str:
    lab = st.state
    if st.reason and st.state in ("blocked", "failed", "queued", "running"):
        lab += f" ({st.reason})"
    if st.state == "done" and st.decision:
        lab += f" ({st.decision})"
    if st.attempts > 1:
        lab += f" ·{st.attempts} sessions"
    if st.failures:
        lab += f" ·{st.failures} fail"
    return lab


def rows(ledger: Ledger) -> list[dict]:
    out = []
    for st in ledger.all():
        note = st.last_note.splitlines()[0] if st.last_note else ""
        if st.state == "blocked" and st.reason == "question":
            q = ledger.read_artifact(st.id, "question.md") or ""
            body = [l for l in q.splitlines() if not l.lower().startswith("key:")]
            note = "Q: " + (body[0] if body else "")
        out.append({
            "id": st.id, "state": st.state, "label": _label(st), "reason": st.reason or "",
            "decision": st.decision or "", "attempts": st.attempts, "elapsed": _elapsed(st),
            "cost": f"${st.cost_usd:.2f}", "note": note[:90], "branch": st.branch or "",
            "summary": ledger.read_artifact(st.id, "summary.md") or "",
            "question": ledger.read_artifact(st.id, "question.md") or "",
            "answer": ledger.read_artifact(st.id, "answer.md") or "",
            "updated": st.updated,
        })
    return out


def header(ledger: Ledger) -> str:
    c = ledger.cfg
    return f"{c.run_id} · skill {c.wrapper or c.skill} · mode {c.mode} · {len(c.targets)} targets · parallel {c.parallel} · ${ledger.total_cost():.2f}"


def summary_line(ledger: Ledger) -> str:
    c = ledger.counts()
    parts = [f"{len(ledger.cfg.targets)} targets"]
    for s in ("shipped", "done", "blocked", "running", "queued", "failed", "skipped"):
        if c[s]:
            label = {"done": "to review" if ledger.reviewable() else "done", "blocked": "waiting on you"}.get(s, s)
            parts.append(f"{c[s]} {label}")
    return " · ".join(parts)


def rich_status(ledger: Ledger, console: Console | None = None) -> None:
    console = console or Console()
    console.print(f"[bold]{header(ledger)}[/bold]")
    t = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
    for col in ("target", "state", "elapsed", "cost", "note"):
        t.add_column(col)
    for r in rows(ledger):
        style = STATE_STYLE.get(r["state"], "")
        t.add_row(r["id"], f"[{style}]{r['label']}[/{style}]", r["elapsed"], r["cost"], r["note"])
    console.print(t)
    console.print(f"\n{summary_line(ledger)}")
    console.print(f"[bold]Next:[/bold] {ledger.next_hint()}")


def write_progress(ledger: Ledger) -> None:
    """Called on every ledger change. Both files are pure functions of the ledger."""
    md = [f"# {header(ledger)}", "", f"Phase: **{ledger.phase()}** — Next: `{ledger.next_hint()}`", "",
          "| target | state | attempts | elapsed | cost | note |", "|---|---|---|---|---|---|"]
    rs = rows(ledger)
    for r in rs:
        md.append(f"| {r['id']} | {r['label']} | {r['attempts']} | {r['elapsed']} | {r['cost']} | {r['note'].replace('|', '/')} |")
    md += ["", summary_line(ledger), ""]
    qs = [r for r in rs if r["state"] == "blocked" and r["reason"] == "question"]
    if qs:
        md += ["## Open questions", ""]
        for r in qs:
            md += [f"### {r['id']}", "", r["question"].strip(), ""]
    if ledger.phase() in ("reviewing", "shipping", "complete") or ledger.cfg.mode == "report":
        done = [r for r in rs if r["summary"]]
        if done:
            md += ["## Summaries", ""]
            for r in done:
                md += [f"### {r['id']} — {r['label']}", "", "```", r["summary"].strip(), "```", ""]
    (ledger.cfg.dir / "PROGRESS.md").write_text("\n".join(md))
    try:
        html = _env.get_template("progress.html").render(
            header=header(ledger), phase=ledger.phase(), next_hint=ledger.next_hint(),
            summary=summary_line(ledger), rows_json=json.dumps(rs), rows=rs,
            generated=datetime.now(timezone.utc).isoformat(timespec="seconds"))
        (ledger.cfg.dir / "progress.html").write_text(html)
    except Exception:
        pass
