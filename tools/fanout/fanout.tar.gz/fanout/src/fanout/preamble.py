from __future__ import annotations

import json
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from .workers.base import WorkerContext

TEMPLATES = Path(__file__).parent / "templates"
_env = Environment(loader=FileSystemLoader(str(TEMPLATES)), autoescape=False, trim_blocks=True, lstrip_blocks=True)

PREAMBLE_VERSION = "v1"


def render_preamble(ctx: WorkerContext, verifier: str | None) -> str:
    t = _env.get_template("preamble.md")
    return t.render(
        skill=ctx.skill,
        subpath=ctx.subpath,
        params=ctx.params,
        params_json=json.dumps(ctx.params, indent=2),
        context_files=[str(f) for f in ctx.context_files],
        mode=ctx.mode,
        attempt=ctx.attempt,
        max_attempts=ctx.max_attempts,
        continuation_note=ctx.continuation_note,
        answer=ctx.answer,
        handoff=ctx.handoff,
        verifier=verifier,
    )
