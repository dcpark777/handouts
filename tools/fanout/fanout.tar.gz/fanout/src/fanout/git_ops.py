"""All git interaction. Worktrees live under the run dir; target repos only ever gain a branch."""
from __future__ import annotations

import subprocess
from pathlib import Path


class GitError(RuntimeError):
    pass


def git(args: list[str], cwd: Path | str | None = None, check: bool = True) -> str:
    r = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True)
    if check and r.returncode != 0:
        raise GitError(f"git {' '.join(args)} failed in {cwd}: {r.stderr.strip() or r.stdout.strip()}")
    return r.stdout.strip()


def is_repo(path: Path) -> bool:
    return subprocess.run(["git", "rev-parse", "--git-dir"], cwd=path, capture_output=True).returncode == 0


def default_branch(repo: Path) -> str:
    """origin/HEAD if set, else main/master, else current."""
    try:
        ref = git(["symbolic-ref", "refs/remotes/origin/HEAD"], repo)
        return ref.rsplit("/", 1)[-1]
    except GitError:
        pass
    for cand in ("main", "master"):
        if subprocess.run(["git", "show-ref", "--verify", "--quiet", f"refs/heads/{cand}"], cwd=repo).returncode == 0:
            return cand
    return git(["rev-parse", "--abbrev-ref", "HEAD"], repo)


def has_remote(repo: Path) -> bool:
    return bool(git(["remote"], repo, check=False))


def fetch(repo: Path) -> None:
    if has_remote(repo):
        git(["fetch", "--quiet", "--prune"], repo, check=False)


def base_ref(repo: Path, base: str) -> str:
    """Prefer origin/<base> when it exists, else local <base>."""
    if subprocess.run(["git", "show-ref", "--verify", "--quiet", f"refs/remotes/origin/{base}"], cwd=repo).returncode == 0:
        return f"origin/{base}"
    return base


def prepare_worktree(repo: Path, worktree: Path, branch: str, base: str) -> None:
    """Create branch at base in a fresh worktree. Idempotent."""
    if worktree.exists():
        return
    worktree.parent.mkdir(parents=True, exist_ok=True)
    exists = subprocess.run(["git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"], cwd=repo).returncode == 0
    if exists:
        git(["worktree", "add", str(worktree), branch], repo)
    else:
        git(["worktree", "add", "-b", branch, str(worktree), base_ref(repo, base)], repo)


def remove_worktree(repo: Path, worktree: Path, branch: str | None = None, delete_branch: bool = False) -> None:
    if worktree.exists():
        git(["worktree", "remove", "--force", str(worktree)], repo, check=False)
    git(["worktree", "prune"], repo, check=False)
    if delete_branch and branch:
        git(["branch", "-D", branch], repo, check=False)
        for t in git(["tag", "-l", f"{branch}@*"], repo, check=False).splitlines():
            git(["tag", "-d", t], repo, check=False)


def tag(worktree: Path, name: str) -> None:
    git(["tag", "-f", name], worktree)


def commit_all(worktree: Path, message: str) -> bool:
    """Stage and commit everything; returns False if nothing to commit."""
    git(["add", "-A"], worktree)
    if not git(["status", "--porcelain"], worktree):
        return False
    ident = []
    if not git(["config", "user.email"], worktree, check=False):
        ident = ["-c", "user.name=fanout", "-c", "user.email=fanout@local"]
    git([*ident, "commit", "-q", "--no-verify", "-m", message], worktree)
    return True


def is_dirty(worktree: Path) -> bool:
    return bool(git(["status", "--porcelain"], worktree))


def diff(worktree: Path, base: str, stat: bool = False) -> str:
    merge_base = git(["merge-base", base_ref(worktree, base), "HEAD"], worktree)
    args = ["diff", "--stat" if stat else "--no-color", merge_base, "HEAD"]
    return git(args, worktree)


def reset_to_tag(worktree: Path, tagname: str) -> None:
    git(["reset", "--hard", tagname], worktree)
    git(["clean", "-fdq"], worktree)


def rebase_onto_base(worktree: Path, base: str) -> bool:
    """Returns True on success, False on conflict (aborts the rebase)."""
    r = subprocess.run(["git", "rebase", base_ref(worktree, base)], cwd=worktree, capture_output=True, text=True)
    if r.returncode != 0:
        subprocess.run(["git", "rebase", "--abort"], cwd=worktree, capture_output=True)
        return False
    return True


def push(worktree: Path, branch: str) -> str:
    return git(["push", "-u", "origin", branch, "--force-with-lease"], worktree)


def pr_create(worktree: Path, base: str, title: str, body: str) -> str:
    r = subprocess.run(["gh", "pr", "create", "--base", base, "--head", git(["rev-parse", "--abbrev-ref", "HEAD"], worktree),
                        "--title", title, "--body", body], cwd=worktree, capture_output=True, text=True)
    if r.returncode != 0:
        raise GitError(f"gh pr create failed: {r.stderr.strip()}")
    return r.stdout.strip()
