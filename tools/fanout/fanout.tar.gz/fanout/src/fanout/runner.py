"""The orchestrator. Never a model. Owns retries, continuation, budgets, heartbeat.

Loop: reconcile stale 'running' targets, collect finished workers and apply their
outcomes, schedule queued targets up to `parallel`, sleep; exit when nothing can move.
Operator commands (answer/retry/rewind/give) requeue targets through the ledger and
restart the runner if needed; the runner never watches for them.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from typing import Any

from . import git_ops
from .config import RunConfig, Target, now_iso
from .ledger import Ledger, TargetState, runner_alive
from .preamble import render_preamble
from .workers import Outcome, WorkerContext, make_worker
from .workers.base import clear_contract_files, read_notes, summary_status

HEARTBEAT_S = 5
STALE_S = 60
THROTTLE_RE = re.compile(r"(?i)rate.?limit|throttl|429|too many requests|overloaded|503")
THROTTLE_BACKOFF_S = tuple(float(x) for x in os.environ.get('FANOUT_BACKOFF', '15,30,60,120,300').split(','))


class Runner:
    def __init__(self, cfg: RunConfig, ledger: Ledger, worker=None, poll_s: float = 1.0):
        self.cfg = cfg
        self.ledger = ledger
        self.worker = worker or make_worker(cfg.worker)
        self.poll_s = poll_s
        self.futures: dict[str, Future] = {}
        self._not_before: dict[str, float] = {}   # target -> epoch; throttle backoff
        self._throttles = 0
        self._stop = threading.Event()
        self._lock = threading.Lock()

    # ------------------------------------------------------------ lifecycle
    def heartbeat(self) -> None:
        (self.cfg.dir / "runner.json").write_text(json.dumps({"pid": os.getpid(), "ts": now_iso(), "epoch": time.time()}))

    def stop(self) -> None:
        self._stop.set()

    def reconcile(self) -> None:
        """Crash recovery: targets left 'running' by a dead runner go back to queued as continuation."""
        for st in self.ledger.all():
            if st.state == "running" and st.id not in self.futures:
                self.ledger.transition(st.id, "queued", "stalled", "reconciled after runner restart")

    # ------------------------------------------------------------ helpers
    def target_cfg(self, tid: str) -> Target:
        return self.cfg.target(tid)

    def _branch(self, tid: str) -> str:
        return f"fanout/{self.cfg.run_id}/{tid}"

    def _tag(self, tid: str, name: str) -> str:
        return f"{self._branch(tid)}@{name}"

    def prepare(self, tid: str) -> TargetState:
        t = self.target_cfg(tid)
        repo = Path(t.path)
        st = self.ledger.get(tid)
        if st.worktree and Path(st.worktree).exists():
            return st
        git_ops.fetch(repo)
        base = t.base or git_ops.default_branch(repo)
        wt = self.cfg.dir / "worktrees" / tid
        branch = self._branch(tid)
        git_ops.prepare_worktree(repo, wt, branch, base)
        git_ops.tag(wt, self._tag(tid, "prepared"))
        return self.ledger.update(tid, worktree=str(wt), branch=branch, base=base)

    def _handoff(self, tid: str, st: TargetState) -> str | None:
        """Diff so far + transcript tail, for a fresh session picking up stalled work."""
        if not st.worktree:
            return None
        parts = []
        notes = self.ledger.read_artifact(tid, "notes.md")
        if notes:
            parts.append("The previous session's own notes (NOTES.md):\n" + notes.strip())
        try:
            d = git_ops.diff(Path(st.worktree), st.base or "main", stat=True)
            if d:
                parts.append("Changes on the branch so far:\n" + d)
        except git_ops.GitError:
            pass
        sess = self.ledger.path(tid, "session.jsonl")
        if sess.exists():
            tail = sess.read_text().splitlines()[-15:]
            parts.append("Last actions of the previous session:\n" + "\n".join(l[:200] for l in tail))
        return "\n\n".join(parts) or None

    def _ctx(self, tid: str, st: TargetState) -> WorkerContext:
        t = self.target_cfg(tid)
        answer = self.ledger.read_artifact(tid, "answer.md")
        cont = None
        handoff = None
        resume = st.session_id
        if st.reason == "throttled":
            cont = None  # resume as if nothing happened
        elif st.reason == "rollover":
            cont = "The previous session reached its turn limit and was rolled over on purpose. Continue from your NOTES.md and the branch."
        elif st.reason in ("stalled", "timeout", "error"):
            cont = f"The previous attempt ended without finishing ({st.reason}). Continue from the current state of the worktree."
            handoff = self._handoff(tid, st)  # notes help even when resuming
        elif st.reason == "verify":
            cont = "The verifier failed after your last attempt. Fix the cause.\n\n" + (st.last_note or "")
        elif st.reason == "rework":
            cont = "The reviewer rejected the change with this note. Address it.\n\n" + (st.last_note or "")
        elif st.reason == "rebase":
            cont = "The branch no longer rebases cleanly onto its base. Rebase and resolve conflicts, then re-run the verifier."
        ctx = WorkerContext(
            target_id=tid,
            worktree=Path(st.worktree),
            subpath=t.subpath,
            skill=self.cfg.wrapper or self.cfg.skill,
            params=t.params,
            preamble="",
            context_files=[Path(c) for c in self.cfg.context],
            attempt=st.attempts + 1,
            max_attempts=self.cfg.max_attempts,
            timeout_s=self.cfg.timeout_s,
            budget_usd=self.cfg.budget_usd,
            mode=self.cfg.mode,
            max_turns=self.cfg.max_turns_per_session,
            env=self.cfg.worker_env(),
            mcp_servers=self.cfg.mcp_servers,
            resume_session_id=resume,
            answer=answer,
            continuation_note=cont,
            handoff=handoff,
            on_tool_event=lambda rec, tid=tid: self.ledger.append_session(tid, {"ts": now_iso(), **rec}),
        )
        ctx.preamble = render_preamble(ctx, self.cfg.verifier)
        return ctx

    # ------------------------------------------------------------ verifier
    def verify(self, st: TargetState) -> tuple[bool, str]:
        if not self.cfg.verifier or self.cfg.mode == "report":
            return True, ""
        cwd = Path(st.worktree) / (self.target_cfg(st.id).subpath or "")
        for attempt in (1, 2):  # flaky guard: one free re-run
            r = subprocess.run(self.cfg.verifier, shell=True, cwd=cwd, capture_output=True, text=True, timeout=self.cfg.timeout_s)
            if r.returncode == 0:
                return True, ""
            out = (r.stdout + "\n" + r.stderr).strip()
            if attempt == 1:
                time.sleep(0.2)
        return False, out[-2000:]

    # ------------------------------------------------------------ execution
    def _run_one(self, tid: str) -> Outcome:
        st = self.ledger.get(tid)
        ctx = self._ctx(tid, st)
        clear_contract_files(ctx.worktree, ctx.subpath)
        self.ledger.event(tid, "running", None, f"attempt {ctx.attempt} start")
        return self.worker.run(ctx)

    def _apply(self, tid: str, out: Outcome | None, exc: BaseException | None) -> None:
        """Turn a worker outcome into exactly one ledger transition."""
        st = self.ledger.get(tid)
        t = self.target_cfg(tid)
        wt = Path(st.worktree)
        attempts = st.attempts + 1
        cost = round(st.cost_usd + (out.cost_usd if out else 0.0), 4)
        session = out.session_id if (out and out.resumable) else None
        fields = dict(attempts=attempts, cost_usd=cost, session_id=session)

        # contract files go to the ledger, never into the branch; then commit + tag the attempt
        notes = read_notes(wt, t.subpath)
        if notes:
            self.ledger.write_artifact(tid, "notes.md", notes)
        clear_contract_files(wt, t.subpath)
        try:
            if self.cfg.mode == "change":
                git_ops.commit_all(wt, f"fanout: {self.cfg.skill} attempt {attempts}")
            else:
                git_ops.reset_to_tag(wt, self._tag(tid, "prepared"))  # report mode never changes files
            git_ops.tag(wt, self._tag(tid, f"attempt-{attempts}"))
        except git_ops.GitError as e:
            self.ledger.event(tid, "running", "error", f"git: {e}")
        self.ledger.clear_artifact(tid, "answer.md")

        def retry_or_fail(reason: str, note: str) -> None:
            fields["failures"] = st.failures + 1
            if fields["failures"] >= self.cfg.max_attempts:
                self.ledger.transition(tid, "failed", reason, f"{note} ({fields['failures']} failures; max_attempts {self.cfg.max_attempts})", **fields)
            elif cost >= self.cfg.budget_usd:
                self.ledger.transition(tid, "failed", "budget", f"{note} (budget ${cost:.2f} >= ${self.cfg.budget_usd:.2f})", **fields)
            else:
                self.ledger.transition(tid, "queued", reason, note, **fields)

        err_text = str(exc) if exc is not None else (out.note if out and out.kind == "error" else "")
        if err_text and THROTTLE_RE.search(err_text):
            # provider throttling is not the target's fault: back off, keep the session, count nothing
            self._throttles += 1
            delay = THROTTLE_BACKOFF_S[min(self._throttles - 1, len(THROTTLE_BACKOFF_S) - 1)]
            self._not_before[tid] = time.time() + delay
            fields["session_id"] = st.session_id
            return self.ledger.transition(tid, "queued", "throttled", f"backing off {delay}s: {err_text[:120]}", **fields) and None
        if exc is not None:
            return retry_or_fail("error", str(exc)[:300])
        assert out is not None
        if out.resumed_fresh:
            self.ledger.event(tid, "running", "resume-failed", "resume failed; fell back to a fresh session with handoff")
        if out.kind == "rollover":  # planned context reset: not a failure, no budget beyond cost
            if cost >= self.cfg.budget_usd:
                return self.ledger.transition(tid, "failed", "budget", f"{out.note} (budget ${cost:.2f} >= ${self.cfg.budget_usd:.2f})", **fields) and None
            return self.ledger.transition(tid, "queued", "rollover", out.note, **fields) and None
        if out.kind == "error":
            return retry_or_fail("error", out.note[:300])
        if out.kind == "stalled":
            return retry_or_fail("stalled", "session ended without SUMMARY.md or QUESTION.md")
        if out.kind == "question":
            self.ledger.write_artifact(tid, "question.md", (f"key: {out.question_key}\n" if out.question_key else "") + (out.question or ""))
            return self.ledger.transition(tid, "blocked", "question", (out.question or "")[:120], question_key=out.question_key, **fields) and None

        # done
        self._throttles = 0
        self.ledger.write_artifact(tid, "summary.md", out.summary or "")
        ok, excerpt = self.verify(st)
        if not ok:
            self.ledger.update(tid, verifier_ok=False)
            return retry_or_fail("verify", "verifier failed:\n" + excerpt)
        note = f"status: {summary_status(out.summary or '')}"
        if self.cfg.mode == "change" and not git_ops.diff(wt, st.base or "main", stat=True):
            note += " (no changes)"
        self.ledger.transition(tid, "done", None, note, verifier_ok=True if self.cfg.verifier else None, **fields)

    # ------------------------------------------------------------ main loop
    def can_move(self) -> bool:
        c = self.ledger.counts()
        return bool(c["queued"] or c["running"] or self.futures)

    def waiting_on_backoff(self) -> bool:
        return any(t > time.time() for t in self._not_before.values())

    def step(self, pool: ThreadPoolExecutor) -> None:
        self.heartbeat()
        # collect finished
        for tid, fut in list(self.futures.items()):
            if fut.done():
                del self.futures[tid]
                exc = fut.exception()
                out = None if exc else fut.result()
                try:
                    self._apply(tid, out, exc)
                except Exception as e:  # never let a bad apply kill the runner
                    self.ledger.transition(tid, "failed", "error", f"apply: {type(e).__name__}: {e}")
        # schedule
        if self.ledger.total_cost() >= self.cfg.run_budget_usd:
            for st in self.ledger.all():
                if st.state == "queued":
                    self.ledger.transition(st.id, "failed", "budget", f"run budget ${self.cfg.run_budget_usd:.2f} exhausted")
            return
        free = self.cfg.parallel - len(self.futures)
        for st in self.ledger.all():
            if free <= 0:
                break
            if st.state == "queued" and st.id not in self.futures:
                if self._not_before.get(st.id, 0) > time.time():
                    continue
                try:
                    self.prepare(st.id)
                except git_ops.GitError as e:
                    self.ledger.transition(st.id, "failed", "error", f"prepare: {e}")
                    continue
                self.ledger.transition(st.id, "running", None, f"attempt {st.attempts + 1}")
                self.futures[st.id] = pool.submit(self._run_one, st.id)
                free -= 1

    def run(self, once: bool = False) -> None:
        self.reconcile()
        self.ledger.event(None, "runner", None, f"start pid {os.getpid()}")
        with ThreadPoolExecutor(max_workers=max(1, self.cfg.parallel)) as pool:
            while not self._stop.is_set():
                self.step(pool)
                if once or not self.can_move():
                    # drain futures if any
                    while self.futures:
                        time.sleep(self.poll_s)
                        self.step(pool)
                    if once or not self.can_move():
                        break
                time.sleep(self.poll_s)
        self.ledger.event(None, "runner", None, "exit")
        p = self.cfg.dir / "runner.json"
        if p.exists():
            p.unlink()


def spawn_detached(run_dir: Path) -> int:
    """Start `fanout run --foreground` as a detached process; returns pid. FANOUT_NO_DETACH=1 disables (tests)."""
    if os.environ.get("FANOUT_NO_DETACH"):
        return 0
    log = (run_dir / "runner.log").open("ab")
    env = dict(os.environ, FANOUT_RUN=run_dir.name)
    proc = subprocess.Popen(
        [sys.executable, "-m", "fanout.cli", "run", "--foreground", "--run", run_dir.name],
        stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
        start_new_session=True, env=env,
    )
    return proc.pid
