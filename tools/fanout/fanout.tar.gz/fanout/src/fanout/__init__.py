"""fanout — apply any Claude Code skill across a fleet of repos."""
__version__ = "0.1.0"
