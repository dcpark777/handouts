"""Worker backed by the Claude Agent SDK.

STATUS: written against the documented SDK surface; NOT yet verified in Dan's
environment. Before trusting it, confirm (see SPEC.md "Verify before building"):
  1. a named skill invokes cleanly in a programmatic session with setting_sources
     loading user + project skills
  2. system-prompt additions (the preamble) override the skill body
  3. managed-settings gates apply under the SDK

Everything the runner needs from this module is the Worker contract in base.py;
if the SDK API differs, only this file changes.
"""
from __future__ import annotations

import asyncio
import re
from pathlib import Path
from typing import Any

from .base import Outcome, WorkerContext, detect_outcome, parse_question

DENY_TOOL_PATTERNS = [
    re.compile(r"\bgit\s+push\b"),
    re.compile(r"\bgh\s+pr\s+create\b"),
    re.compile(r"\bgit\s+remote\b"),
    re.compile(r"\bgit\s+config\s+--global\b"),
]


class SDKWorker:
    name = "sdk"

    def __init__(self, model: str | None = None, permission_mode: str = "acceptEdits"):
        self.model = model
        self.permission_mode = permission_mode

    def run(self, ctx: WorkerContext) -> Outcome:
        return asyncio.run(self._run(ctx))

    # ---- hooks -------------------------------------------------------------
    def _make_pre_tool_hook(self, ctx: WorkerContext):
        worktree = ctx.worktree.resolve()

        async def hook(input_data: dict[str, Any], tool_use_id: str | None, context: Any) -> dict[str, Any]:
            name = input_data.get("tool_name", "")
            tin = input_data.get("tool_input", {}) or {}
            deny_reason = None
            if name == "Bash":
                cmd = tin.get("command", "")
                for pat in DENY_TOOL_PATTERNS:
                    if pat.search(cmd):
                        deny_reason = f"fanout: '{cmd[:60]}' is not allowed in a worker (push/PR/remote)"
                        break
            if name in ("Write", "Edit", "MultiEdit", "NotebookEdit"):
                p = tin.get("file_path") or tin.get("path") or ""
                if p:
                    rp = Path(p).resolve()
                    if worktree not in rp.parents and rp != worktree:
                        deny_reason = f"fanout: write outside worktree denied: {p}"
            if ctx.on_tool_event:
                ctx.on_tool_event({"type": "tool_use", "name": name, "input": _short(tin), "denied": deny_reason})
            if deny_reason:
                return {"hookSpecificOutput": {"hookEventName": "PreToolUse",
                                               "permissionDecision": "deny",
                                               "permissionDecisionReason": deny_reason}}
            return {}

        return hook

    def _make_post_tool_hook(self, ctx: WorkerContext):
        async def hook(input_data: dict[str, Any], tool_use_id: str | None, context: Any) -> dict[str, Any]:
            if ctx.on_tool_event:
                ctx.on_tool_event({"type": "tool_result", "name": input_data.get("tool_name"),
                                   "result": _short(input_data.get("tool_response"))})
            return {}

        return hook

    # ---- session -----------------------------------------------------------
    async def _run(self, ctx: WorkerContext) -> Outcome:
        try:
            from claude_agent_sdk import ClaudeAgentOptions, ClaudeSDKClient, HookMatcher  # type: ignore
        except ImportError as e:  # pragma: no cover
            return Outcome(kind="error", note=f"claude-agent-sdk not installed: {e}", resumable=False)

        cwd = ctx.worktree / ctx.subpath if ctx.subpath else ctx.worktree

        def make_options(resume: str | None):
            return ClaudeAgentOptions(
                cwd=str(cwd),
                system_prompt={"type": "preset", "preset": "claude_code", "append": ctx.preamble},
                setting_sources=["user", "project"],   # must load the skill; do NOT run bare
                permission_mode=self.permission_mode,
                max_turns=ctx.max_turns,
                model=self.model,
                resume=resume,
                env=ctx.env or None,
                mcp_servers=ctx.mcp_servers or None,
                hooks={
                    "PreToolUse": [HookMatcher(matcher=None, hooks=[self._make_pre_tool_hook(ctx)])],
                    "PostToolUse": [HookMatcher(matcher=None, hooks=[self._make_post_tool_hook(ctx)])],
                },
            )

        if ctx.resume_session_id and (ctx.answer or ctx.continuation_note):
            prompt = "Continue per the updated contract in your system prompt."
        else:
            prompt = f"/{ctx.skill}"
            if ctx.params:
                prompt += " " + " ".join(f"{k}={v}" for k, v in ctx.params.items() if isinstance(v, (str, int, float)))

        session_id = ctx.resume_session_id
        cost = 0.0
        error: str | None = None
        async def session() -> None:
            nonlocal session_id, cost, error
            async with ClaudeSDKClient(options=options) as client:
                await client.query(prompt)
                async for msg in client.receive_response():
                    mtype = type(msg).__name__
                    if ctx.on_tool_event:
                        ctx.on_tool_event({"type": mtype, "text": _short(getattr(msg, "content", None) or getattr(msg, "result", None))})
                    if mtype == "ResultMessage":
                        session_id = getattr(msg, "session_id", session_id)
                        cost = float(getattr(msg, "total_cost_usd", 0.0) or 0.0)
                        if getattr(msg, "is_error", False):
                            error = str(getattr(msg, "result", "error"))

        try:
            await asyncio.wait_for(session(ctx.resume_session_id), timeout=ctx.timeout_s)
        except asyncio.TimeoutError:
            error = f"timeout after {ctx.timeout_s}s"
        except Exception as e:  # noqa: BLE001
            error = f"{type(e).__name__}: {e}"

        # resume failed before doing anything: fall back to a fresh session with the handoff, same attempt
        if ctx.resume_session_id and turns == 0 and error:
            if ctx.on_tool_event:
                ctx.on_tool_event({"type": "resume_failed", "error": error})
            error, session_id, resumed_fresh = None, None, True
            prompt = f"/{ctx.skill}"
            try:
                await asyncio.wait_for(session(None), timeout=ctx.timeout_s)
            except asyncio.TimeoutError:
                error = f"timeout after {ctx.timeout_s}s"
            except Exception as e:  # noqa: BLE001
                error = f"{type(e).__name__}: {e}"

        kind, text = detect_outcome(ctx.worktree, ctx.subpath)
        if kind == "question":
            key, body = parse_question(text or "")
            return Outcome(kind="question", question=body, question_key=key, session_id=session_id, cost_usd=cost)
        if kind == "done":
            return Outcome(kind="done", summary=text, session_id=session_id, cost_usd=cost)
        if turns >= ctx.max_turns:
            return Outcome(kind="rollover", session_id=None, cost_usd=cost, note=f"max_turns {ctx.max_turns} reached", resumed_fresh=resumed_fresh)
        if error:
            resumable = "context" not in error.lower() and "session" not in error.lower()
            return Outcome(kind="error", note=error, session_id=session_id, cost_usd=cost, resumable=resumable, resumed_fresh=resumed_fresh)
        return Outcome(kind="stalled", session_id=session_id, cost_usd=cost, resumed_fresh=resumed_fresh)


def _short(x: Any, n: int = 400) -> Any:
    s = str(x) if x is not None else ""
    return s if len(s) <= n else s[:n] + "…"
