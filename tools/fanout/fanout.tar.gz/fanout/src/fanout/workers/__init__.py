from __future__ import annotations

from .base import Outcome, Worker, WorkerContext


def make_worker(name: str) -> Worker:
    if name == "fake":
        from .fake import FakeWorker
        return FakeWorker()
    if name == "sdk":
        from .sdk import SDKWorker
        return SDKWorker()
    raise ValueError(f"unknown worker {name!r} (sdk|fake)")


__all__ = ["Outcome", "Worker", "WorkerContext", "make_worker"]
