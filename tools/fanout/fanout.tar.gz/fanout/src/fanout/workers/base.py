"""Worker contract. The runner only ever sees Outcome; workers only ever see WorkerContext."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Protocol


@dataclass
class WorkerContext:
    target_id: str
    worktree: Path
    subpath: str | None
    skill: str                      # skill or wrapper name to invoke
    params: dict[str, Any]
    preamble: str                   # system-prompt addition (the contract)
    context_files: list[Path]
    attempt: int
    max_attempts: int
    timeout_s: int
    budget_usd: float
    mode: str                       # change | report
    max_turns: int = 150
    env: dict[str, str] = field(default_factory=dict)
    mcp_servers: list[dict[str, Any]] = field(default_factory=list)
    resume_session_id: str | None = None
    answer: str | None = None       # user's answer to the previous question
    continuation_note: str | None = None  # why we're continuing (stalled/verify/rework/rebase)
    handoff: str | None = None      # diff + transcript tail when a fresh session must pick up
    on_tool_event: Callable[[dict[str, Any]], None] | None = None  # streamed into session.jsonl


@dataclass
class Outcome:
    kind: str                       # done | question | stalled | rollover | error
    summary: str | None = None      # contents of summary.md (kind=done)
    question: str | None = None     # contents of question.md (kind=question)
    question_key: str | None = None
    session_id: str | None = None
    cost_usd: float = 0.0
    note: str = ""
    resumable: bool = True          # False when the session can't be resumed (context full etc.)
    resumed_fresh: bool = False     # True when a resume failed and the worker fell back to a fresh session
    extra: dict[str, Any] = field(default_factory=dict)


class Worker(Protocol):
    name: str

    def run(self, ctx: WorkerContext) -> Outcome: ...


def parse_question(text: str) -> tuple[str | None, str]:
    """question.md: optional 'key: slug' first lines, then the question body."""
    key = None
    body_lines = []
    for line in text.splitlines():
        if key is None and line.lower().startswith("key:"):
            key = line.split(":", 1)[1].strip() or None
            continue
        body_lines.append(line)
    return key, "\n".join(body_lines).strip()


def summary_status(text: str) -> str:
    """summary.md must carry 'status: complete|partial'. Missing -> 'unknown'."""
    for line in text.splitlines()[:10]:
        if line.lower().startswith("status:"):
            return line.split(":", 1)[1].strip().lower()
    return "unknown"


def detect_outcome(worktree: Path, subpath: str | None) -> tuple[str, str | None]:
    """Look for the two contract files a worker leaves behind. Returns (kind, text)."""
    root = worktree / subpath if subpath else worktree
    q = root / "QUESTION.md"
    s = root / "SUMMARY.md"
    if q.exists():
        return "question", q.read_text()
    if s.exists():
        return "done", s.read_text()
    return "stalled", None


def read_notes(worktree: Path, subpath: str | None) -> str | None:
    p = (worktree / subpath if subpath else worktree) / "NOTES.md"
    return p.read_text() if p.exists() else None


def clear_contract_files(worktree: Path, subpath: str | None) -> None:
    root = worktree / subpath if subpath else worktree
    for name in ("QUESTION.md", "SUMMARY.md", "NOTES.md"):
        p = root / name
        if p.exists():
            p.unlink()
