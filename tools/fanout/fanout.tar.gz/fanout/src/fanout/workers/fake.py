"""A worker that follows a script instead of calling a model.

Script source, in order:
  1. ctx.params["fake"]  — list of outcome specs for successive attempts, e.g.
       [{"kind":"question","key":"scope","text":"A or B?"}, {"kind":"done"}]
  2. a file FANOUT_FAKE.json in the worktree (same shape)
  3. default: edit hello.txt and finish.

Each spec: kind = done | question | stalled | error | verify_fail
  done:        writes SUMMARY.md (status from spec, default complete), edits a file if "edit" given
  question:    writes QUESTION.md with key/text
  stalled:     makes a partial edit and returns without contract files
  error:       raises
  verify_fail: makes an edit that makes the verifier fail (writes FAIL file), then done
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from .base import Outcome, WorkerContext, detect_outcome, parse_question


class FakeWorker:
    name = "fake"

    def __init__(self, delay: float = 0.0):
        self.delay = delay

    def _script(self, ctx: WorkerContext) -> list[dict]:
        if "fake" in ctx.params:
            return list(ctx.params["fake"])
        p = ctx.worktree / "FANOUT_FAKE.json"
        if p.exists():
            return json.loads(p.read_text())
        return [{"kind": "done", "edit": "hello.txt"}]

    def run(self, ctx: WorkerContext) -> Outcome:
        time.sleep(self.delay)
        root = ctx.worktree / ctx.subpath if ctx.subpath else ctx.worktree
        script = self._script(ctx)
        n = ctx.attempt - 1  # index by ledger attempt, so restarts replay correctly
        spec = script[n] if n < len(script) else {"kind": "done"}
        sid = ctx.resume_session_id or f"fake-{ctx.target_id}-{n}"
        cost = float(spec.get("cost", 0.01))

        if ctx.on_tool_event:
            ctx.on_tool_event({"type": "tool", "name": "fake", "attempt": ctx.attempt, "spec": spec.get("kind")})

        kind = spec.get("kind", "done")
        if kind == "error":
            raise RuntimeError(spec.get("text", "simulated worker error"))
        if kind == "rollover":
            (root / "NOTES.md").write_text(f"## Done\n- half\n## Next\n- other half (session {ctx.attempt})\n")
            return Outcome(kind="rollover", session_id=None, cost_usd=cost, note="max_turns reached")
        if kind == "stalled":
            (root / "partial.txt").write_text(f"partial work attempt {ctx.attempt}\n")
            (root / "NOTES.md").write_text(f"## Done\n- partial.txt\n## Next\n- finish (attempt {ctx.attempt})\n")
            return Outcome(kind="stalled", session_id=sid, cost_usd=cost, resumable=spec.get("resumable", True))
        if kind == "question":
            (root / "QUESTION.md").write_text(f"key: {spec.get('key', 'q')}\n{spec.get('text', 'Which way?')}\n")
        elif kind in ("done", "verify_fail"):
            if ctx.mode == "change":
                edit = spec.get("edit", "hello.txt")
                f = root / edit
                f.write_text((f.read_text() if f.exists() else "") + f"fanout attempt {ctx.attempt}\n")
                if kind == "verify_fail":
                    (root / "FAIL").write_text("make verifier fail\n")
                elif (root / "FAIL").exists():
                    (root / "FAIL").unlink()  # "fixed" on the next attempt
            status = spec.get("status", "complete")
            items = spec.get("items", ["- hello: done — edited"])
            (root / "SUMMARY.md").write_text(f"status: {status}\nitems:\n" + "\n".join(items) + "\nnotes: fake worker\n")

        k, text = detect_outcome(ctx.worktree, ctx.subpath)
        if k == "question":
            key, body = parse_question(text or "")
            return Outcome(kind="question", question=body, question_key=key, session_id=sid, cost_usd=cost)
        if k == "done":
            return Outcome(kind="done", summary=text, session_id=sid, cost_usd=cost)
        return Outcome(kind="stalled", session_id=sid, cost_usd=cost)
