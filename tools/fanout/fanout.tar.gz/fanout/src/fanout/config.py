"""Run configuration: run.yaml is the single config + record for a run."""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

DENY_ALWAYS = ["git push", "gh pr create", "git remote", "git config --global"]


def fanout_home() -> Path:
    return Path(os.environ.get("FANOUT_HOME", Path.home() / ".fanout"))


def runs_dir() -> Path:
    d = fanout_home() / "runs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def personal_config() -> dict[str, Any]:
    p = fanout_home() / "config.yaml"
    if p.exists():
        return yaml.safe_load(p.read_text()) or {}
    return {}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


@dataclass
class Target:
    id: str
    path: str
    subpath: str | None = None
    base: str | None = None
    params: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "Target":
        if "id" not in d or "path" not in d:
            raise ValueError(f"target needs id and path: {d}")
        if not re.fullmatch(r"[A-Za-z0-9._-]+", d["id"]):
            raise ValueError(f"target id must be [A-Za-z0-9._-]: {d['id']!r}")
        return Target(
            id=d["id"],
            path=str(Path(d["path"]).expanduser()),
            subpath=d.get("subpath"),
            base=d.get("base"),
            params=d.get("params") or {},
        )


def load_targets(*sources: str | Path) -> list[Target]:
    """Accepts any mix of: a targets.jsonl file, a text file of repo paths, or repo directories.
    Directories become targets with id = directory name and no params."""
    lines: list[str] = []
    for src in sources:
        p = Path(src).expanduser()
        if p.is_dir():
            lines.append(json.dumps({"id": p.name, "path": str(p)}))
        elif p.is_file():
            lines.extend(p.read_text().splitlines())
        else:
            raise FileNotFoundError(f"target source not found: {src}")
    targets: list[Target] = []
    seen: set[str] = set()
    for i, line in enumerate(lines, 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("{"):
            d = json.loads(line)
        else:  # bare path -> id from dir name
            d = {"id": Path(line).expanduser().name, "path": line}
        t = Target.from_dict(d)
        if t.id in seen:
            raise ValueError(f"duplicate target id {t.id!r} (line {i})")
        seen.add(t.id)
        targets.append(t)
    if not targets:
        raise ValueError(f"no targets in {path}")
    return targets


@dataclass
class RunConfig:
    run_id: str
    skill: str
    targets: list[Target]
    wrapper: str | None = None
    mode: str = "change"  # change | report
    parallel: int = 3
    max_attempts: int = 3
    timeout_s: int = 1800
    budget_usd: float = 5.0
    run_budget_usd: float = 100.0
    verifier: str | None = None
    context: list[str] = field(default_factory=list)
    max_turns_per_session: int = 150      # controlled context reset: rollover, not failure
    env: dict[str, str] = field(default_factory=dict)   # passed to worker sessions; redacted on write
    env_file: str | None = None           # KEY=VALUE lines, same treatment
    mcp_servers: list[dict[str, Any]] = field(default_factory=list)  # passthrough, if approved
    worker: str = "sdk"  # sdk | fake (tests/demos)
    created: str = field(default_factory=now_iso)
    approved: bool = False  # plan gate

    @property
    def dir(self) -> Path:
        return runs_dir() / self.run_id

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["targets"] = [asdict(t) for t in self.targets]
        return d

    def save(self) -> None:
        self.dir.mkdir(parents=True, exist_ok=True)
        (self.dir / "run.yaml").write_text(yaml.safe_dump(self.to_dict(), sort_keys=False))

    @staticmethod
    def load(run_dir: Path) -> "RunConfig":
        d = yaml.safe_load((run_dir / "run.yaml").read_text())
        d["targets"] = [Target.from_dict(t) for t in d["targets"]]
        return RunConfig(**d)

    def worker_env(self) -> dict[str, str]:
        env = dict(self.env)
        if self.env_file:
            for line in Path(self.env_file).expanduser().read_text().splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k.strip()] = v.strip().strip('"').strip("'")
        return env

    def target(self, tid: str) -> Target:
        for t in self.targets:
            if t.id == tid:
                return t
        raise KeyError(tid)


def new_run_id(skill: str) -> str:
    stamp = datetime.now().strftime("%Y%m%d-%H%M")
    base = f"{stamp}-{slug(skill)}"
    rid, n = base, 2
    while (runs_dir() / rid).exists():
        rid, n = f"{base}-{n}", n + 1
    return rid


def resolve_run(run: str | None) -> Path:
    """Explicit id, else FANOUT_RUN, else latest by mtime."""
    rid = run or os.environ.get("FANOUT_RUN")
    if rid:
        p = runs_dir() / rid
        if not p.exists():
            raise FileNotFoundError(f"no run {rid!r}. Run `fanout runs`.")
        return p
    runs = sorted((p for p in runs_dir().iterdir() if (p / "run.yaml").exists()),
                  key=lambda p: p.stat().st_mtime)
    if not runs:
        raise FileNotFoundError("no runs yet. Run `fanout plan <skill> --on targets.jsonl`.")
    return runs[-1]
