"""fanout CLI. Verbs in workflow order: plan, run, status, answer, review; plus next, runs, clean, target."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import click
from rich.console import Console

from . import git_ops
from .config import RunConfig, resolve_run, runs_dir
from .ledger import Ledger, runner_alive
from .plan import build_config, find_skill, preflight, print_plan, skill_declares_contract, wrapper_name
from .render import rich_status, write_progress
from .runner import Runner, spawn_detached

console = Console()


def _open(run: str | None) -> tuple[RunConfig, Ledger]:
    try:
        run_dir = resolve_run(run)
    except FileNotFoundError as e:
        raise click.ClickException(str(e))
    cfg = RunConfig.load(run_dir)
    ledger = Ledger(cfg)
    ledger.on_change(write_progress)
    return cfg, ledger


def _next(ledger: Ledger) -> None:
    console.print(f"[bold]Next:[/bold] {ledger.next_hint()}")


run_opt = click.option("--run", "run", default=None, help="run id (default: latest or $FANOUT_RUN)")


@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx: click.Context) -> None:
    """Apply any Claude Code skill across a fleet of repos."""
    if ctx.invoked_subcommand is None:
        try:
            _, ledger = _open(None)
        except click.ClickException as e:
            console.print(str(e))
            return
        rich_status(ledger, console)


# ------------------------------------------------------------------ plan
@main.command()
@click.argument("skill")
@click.option("--on", "targets_file", required=True, type=click.Path(exists=True, path_type=Path), help="targets.jsonl")
@click.option("--mode", type=click.Choice(["change", "report"]), default=None)
@click.option("--parallel", type=int, default=None)
@click.option("--max-attempts", type=int, default=None)
@click.option("--timeout", "timeout_s", type=int, default=None)
@click.option("--budget", "budget_usd", type=float, default=None, help="USD per target")
@click.option("--run-budget", "run_budget_usd", type=float, default=None)
@click.option("--verifier", default=None, help="shell command run in the worktree after each attempt")
@click.option("--context", multiple=True, type=click.Path(exists=True), help="reference files for the worker")
@click.option("--worker", type=click.Choice(["sdk", "fake"]), default=None)
@click.option("--from", "from_run", default=None, help="copy settings from a previous run")
@click.option("--yes", is_flag=True, help="skip the interview and approve the plan")
def plan(skill: str, targets_file: Path, from_run: str | None, yes: bool, context: tuple, **over) -> None:
    """Interview once, write run.yaml, preflight, summarize, gate."""
    if from_run:
        prev = RunConfig.load(resolve_run(from_run))
        for k in ("mode", "parallel", "max_attempts", "timeout_s", "budget_usd", "run_budget_usd", "verifier", "worker"):
            over.setdefault(k, None)
            if over[k] is None:
                over[k] = getattr(prev, k)
        if not context:
            context = tuple(prev.context)
    over["context"] = list(context)

    # interview (only what's still unknown and only when not --yes)
    if not yes:
        if over.get("mode") is None:
            over["mode"] = click.prompt("Mode", type=click.Choice(["change", "report"]), default="change")
        if over.get("verifier") is None and over["mode"] == "change":
            v = click.prompt("Verifier command (blank for none)", default="", show_default=False)
            over["verifier"] = v or None
    cfg = build_config(skill, targets_file, **{k: v for k, v in over.items() if v is not None})

    # wrapper check: does the skill already speak the contract?
    if cfg.worker == "sdk":
        smd = find_skill(skill)
        if smd and not skill_declares_contract(smd):
            w = wrapper_name(skill)
            if find_skill(w):
                cfg.wrapper = w
                console.print(f"using wrapper {w}")
            else:
                console.print(f"[yellow]{skill} does not declare the fanout contract; the preamble will supply it.[/yellow]")
                console.print(f"If it misbehaves, create a wrapper skill named {w} (see references/skill-authoring.md).")

    problems = preflight(cfg)
    print_plan(cfg, console, problems)
    if problems:
        cfg.save()
        raise click.ClickException("fix the problems above, then rerun `fanout plan` (or edit run.yaml and `fanout run`)")
    cfg.approved = yes or click.confirm("Approve this plan?", default=True)
    cfg.save()
    ledger = Ledger(cfg)
    ledger.on_change(write_progress)
    ledger.init_targets()
    ledger.event(None, "plan", None, "approved" if cfg.approved else "written, not approved")
    console.print(f"\nrun {cfg.run_id} → {cfg.dir}")
    _next(ledger)


# ------------------------------------------------------------------ run
@main.command("run")
@run_opt
@click.option("--foreground", is_flag=True, help="run in this terminal instead of detaching")
def run_cmd(run: str | None, foreground: bool) -> None:
    """Execute the plan. Detaches by default; safe to rerun (resumes)."""
    cfg, ledger = _open(run)
    if not cfg.approved:
        raise click.ClickException("plan not approved. Rerun `fanout plan ... --yes` or answer yes at the gate.")
    if runner_alive(cfg.dir):
        console.print("runner already active for this run")
        _next(ledger)
        return
    if not any(s.state in ("queued", "running") for s in ledger.all()):
        console.print("nothing to run")
        _next(ledger)
        return
    if foreground:
        r = Runner(cfg, ledger)
        try:
            r.run()
        except KeyboardInterrupt:
            r.stop()
            ledger.event(None, "runner", "interrupted", "Ctrl-C; rerun `fanout run` to resume")
        rich_status(ledger, console)
        return
    pid = spawn_detached(cfg.dir)
    console.print(f"runner started (pid {pid}); log: {cfg.dir / 'runner.log'}")
    time.sleep(0.5)
    _next(ledger)


# ------------------------------------------------------------------ status
@main.command()
@run_opt
@click.option("--watch", is_flag=True)
def status(run: str | None, watch: bool) -> None:
    """One table, any time."""
    cfg, ledger = _open(run)
    if not watch:
        rich_status(ledger, console)
        return
    try:
        while True:
            console.clear()
            rich_status(ledger, console)
            alive = runner_alive(cfg.dir)
            console.print(f"[dim]runner {'active' if alive else 'not running'} · Ctrl-C to stop watching[/dim]")
            time.sleep(2)
    except KeyboardInterrupt:
        pass


# ------------------------------------------------------------------ answer
@main.command()
@run_opt
@click.option("--target", "target_id", default=None)
def answer(run: str | None, target_id: str | None) -> None:
    """Walk open questions, grouped by key; one answer can apply to all with the same key."""
    cfg, ledger = _open(run)
    qs = ledger.questions()
    if target_id:
        qs = [q for q in qs if q.id == target_id]
    if not qs:
        console.print("no open questions")
        _next(ledger)
        return
    groups: dict[str, list] = {}
    for q in qs:
        groups.setdefault(q.question_key or f"_{q.id}", []).append(q)
    answered = 0
    for key, members in groups.items():
        first = members[0]
        console.rule(f"{key}  ·  {len(members)} target{'s' if len(members) > 1 else ''}: {', '.join(m.id for m in members)}")
        console.print(ledger.read_artifact(first.id, "question.md") or "")
        if len(members) > 1:
            for m in members[1:]:
                other = ledger.read_artifact(m.id, "question.md") or ""
                if other.strip() != (ledger.read_artifact(first.id, "question.md") or "").strip():
                    console.print(f"[dim]--- {m.id} phrased it as:[/dim]\n{other}")
        ans = click.prompt("Answer (blank to skip this group)", default="", show_default=False)
        if not ans:
            continue
        apply_all = True if len(members) == 1 else click.confirm(f"Apply this answer to all {len(members)} targets?", default=True)
        for m in (members if apply_all else members[:1]):
            ledger.write_artifact(m.id, "answer.md", ans)
            ledger.clear_artifact(m.id, "question.md")
            ledger.transition(m.id, "queued", "answered", ans[:120], question_key=None)
            answered += 1
        if len(members) > 1 and click.confirm("Promote this Q&A into the skill wrapper so it stops asking?", default=False):
            _promote(cfg, key, ledger.read_artifact(first.id, "question.md") or "", ans)
    if answered and not runner_alive(cfg.dir):
        pid = spawn_detached(cfg.dir)
        console.print(f"{answered} answered · runner restarted (pid {pid})")
        time.sleep(0.5)
    else:
        console.print(f"{answered} answered · the runner picks them up")
    _next(ledger)


def _promote(cfg: RunConfig, key: str, question: str, ans: str) -> None:
    w = cfg.wrapper or wrapper_name(cfg.skill)
    smd = find_skill(w)
    if not smd:
        console.print(f"[yellow]no wrapper skill {w} found; add this to the skill yourself:[/yellow]\n  {key}: {ans}")
        return
    with smd.open("a") as f:
        f.write(f"\n\n## Standing answer — key: {key}\n\nQuestion: {question.strip()[:300]}\n\nAnswer: {ans}\n")
    console.print(f"appended standing answer to {smd}")


# ------------------------------------------------------------------ review
@main.command()
@run_opt
@click.option("--no-ship", is_flag=True, help="approve/reject only; do not push at the end")
def review(run: str | None, no_ship: bool) -> None:
    """Walk finished targets: summary, verifier, diff. a/r/n/s. Then one confirmation before pushing."""
    cfg, ledger = _open(run)
    if ledger.questions():
        raise click.ClickException(f"{len(ledger.questions())} targets have open questions. Run `fanout answer` first.")
    items = ledger.reviewable()
    if cfg.mode == "report":
        console.rule("Report")
        for st in ledger.all():
            if st.state == "done":
                console.print(f"[bold]{st.id}[/bold]\n{ledger.read_artifact(st.id, 'summary.md') or '(no summary)'}\n")
                ledger.transition(st.id, "skipped", "report", "report reviewed", decision="approved")
        console.print(f"aggregate written to {cfg.dir / 'PROGRESS.md'}")
        _next(ledger)
        return
    if not items:
        console.print("nothing to review")
    for st in items:
        wt = Path(st.worktree)
        console.rule(f"{st.id}  ·  attempts {st.attempts}  ·  verifier {'ok' if st.verifier_ok else ('-' if st.verifier_ok is None else 'FAILED')}  ·  ${st.cost_usd:.2f}")
        # rebase onto current base before showing the diff
        try:
            git_ops.fetch(Path(cfg.target(st.id).path))
            if not git_ops.rebase_onto_base(wt, st.base or "main"):
                ledger.transition(st.id, "queued", "rebase", "base moved; rebase conflicts", decision=None)
                console.print("[yellow]rebase conflict — sent back to the worker[/yellow]")
                continue
        except git_ops.GitError as e:
            console.print(f"[yellow]rebase skipped: {e}[/yellow]")
        console.print(ledger.read_artifact(st.id, "summary.md") or "(no summary)")
        console.print(git_ops.diff(wt, st.base or "main", stat=True) or "(no changes)")
        while True:
            k = click.prompt("[a]pprove [r]eject [d]iff [n]ote [s]kip [q]uit", default="a").strip().lower()[:1]
            if k == "d":
                click.echo_via_pager(git_ops.diff(wt, st.base or "main"))
                continue
            if k == "n":
                note = click.prompt("Note")
                ledger.event(st.id, "done", "note", note)
                continue
            if k == "a":
                ledger.update(st.id, decision="approved")
                ledger.event(st.id, "done", "approved", "")
            elif k == "r":
                note = click.prompt("Why? (goes back to the worker)")
                ledger.transition(st.id, "queued", "rework", note, decision=None)
            elif k == "s":
                ledger.transition(st.id, "skipped", "reviewer", "skipped in review")
            elif k == "q":
                _next(ledger)
                return
            break
    if not no_ship:
        _ship(cfg, ledger)
    _next(ledger)


def _ship(cfg: RunConfig, ledger: Ledger) -> None:
    """The only place anything leaves the machine. One confirmation, then push + PR per approved target."""
    approved = [s for s in ledger.all() if s.state == "done" and s.decision == "approved"]
    if not approved:
        return
    console.rule("Ship")
    for s in approved:
        console.print(f"  {s.id}  {s.branch}  → PR onto {s.base}")
    if not click.confirm(f"Push {len(approved)} branch{'es' if len(approved) != 1 else ''} and open PRs?", default=False):
        return
    for s in approved:
        wt = Path(s.worktree)
        try:
            git_ops.push(wt, s.branch)
            url = git_ops.pr_create(wt, s.base or "main", f"[fanout] {cfg.skill}: {s.id}", ledger.read_artifact(s.id, "summary.md") or "")
            ledger.transition(s.id, "shipped", None, url)
            console.print(f"  [green]{s.id}[/green] {url}")
        except git_ops.GitError as e:
            ledger.event(s.id, "done", "ship-failed", str(e))
            console.print(f"  [red]{s.id}[/red] {e}")


# ------------------------------------------------------------------ next
@main.command("next")
@run_opt
@click.pass_context
def next_cmd(ctx: click.Context, run: str | None) -> None:
    """Do whatever the run is waiting on."""
    cfg, ledger = _open(run)
    ph = ledger.phase()
    if ph == "planning":
        raise click.ClickException("plan not approved. Rerun `fanout plan` and answer yes.")
    if ledger.questions():
        ctx.invoke(answer, run=run, target_id=None)
    elif ledger.reviewable() or ph == "shipping":
        ctx.invoke(review, run=run, no_ship=False)
    elif ph == "running" and not runner_alive(cfg.dir):
        ctx.invoke(run_cmd, run=run, foreground=False)
    else:
        rich_status(ledger, console)


# ------------------------------------------------------------------ runs / clean
@main.command()
def runs() -> None:
    """List runs."""
    rs = sorted((p for p in runs_dir().iterdir() if (p / "run.yaml").exists()), key=lambda p: p.stat().st_mtime, reverse=True)
    if not rs:
        console.print("no runs")
        return
    for p in rs:
        cfg = RunConfig.load(p)
        ledger = Ledger(cfg)
        alive = "active" if runner_alive(p) else ""
        console.print(f"{p.name:40} {ledger.phase():10} {alive:7} {cfg.skill}  {len(cfg.targets)} targets")


@main.command()
@click.argument("run", required=False)
@click.option("--all-complete", is_flag=True, help="clean every run whose phase is complete")
@click.option("--keep-branches", is_flag=True)
def clean(run: str | None, all_complete: bool, keep_branches: bool) -> None:
    """Remove worktrees, branches and tags for a run (ledger files are kept)."""
    targets = []
    if all_complete:
        targets = [p for p in runs_dir().iterdir() if (p / "run.yaml").exists() and Ledger(RunConfig.load(p)).phase() == "complete"]
    else:
        targets = [resolve_run(run)]
    for p in targets:
        if runner_alive(p):
            console.print(f"[yellow]{p.name}: runner active, skipping[/yellow]")
            continue
        cfg = RunConfig.load(p)
        for t in cfg.targets:
            wt = p / "worktrees" / t.id
            git_ops.remove_worktree(Path(t.path), wt, f"fanout/{cfg.run_id}/{t.id}", delete_branch=not keep_branches)
        shutil.rmtree(p / "worktrees", ignore_errors=True)
        console.print(f"cleaned {p.name}")


# ------------------------------------------------------------------ target
@main.command()
@run_opt
@click.argument("target_id")
@click.argument("action", required=False, type=click.Choice(["retry", "skip", "rewind", "take", "give"]))
@click.option("--to", "tag", default=None, help="rewind: tag name (prepared | attempt-N)")
@click.option("--skip", "give_skip", is_flag=True, help="give: mark skipped instead of done")
def target(run: str | None, target_id: str, action: str | None, tag: str | None, give_skip: bool) -> None:
    """Show one target; optional action. Only actions valid in its state are offered."""
    cfg, ledger = _open(run)
    try:
        st = ledger.get(target_id)
        cfg.target(target_id)
    except KeyError:
        raise click.ClickException(f"no target {target_id!r} in {cfg.run_id}")
    valid = {
        "queued": ["skip", "take"], "running": ["take"], "blocked": ["give", "skip", "rewind"] if st.reason == "taken" else ["skip", "take", "rewind"],
        "done": ["rewind", "take", "skip"], "failed": ["retry", "take", "skip", "rewind"], "shipped": [], "skipped": ["rewind"],
    }[st.state]
    if action is None:
        console.rule(f"{st.id}  ·  {st.state}" + (f" ({st.reason})" if st.reason else ""))
        console.print(f"attempts {st.attempts}   cost ${st.cost_usd:.2f}   decision {st.decision or '-'}   verifier {st.verifier_ok}")
        console.print(f"branch   {st.branch or '-'}\nworktree {st.worktree or '-'}\nsession  {st.session_id or '-'}")
        if st.worktree:
            console.print(f"\nopen it:   $EDITOR {st.worktree}")
            console.print(f"continue:  cd {st.worktree} && claude" + (f" --resume {st.session_id}" if st.session_id else ""))
        q = ledger.read_artifact(st.id, "question.md")
        if q:
            console.print(f"\n[yellow]Question[/yellow]\n{q}")
        s = ledger.read_artifact(st.id, "summary.md")
        if s:
            console.print(f"\n[green]Summary[/green]\n{s}")
        console.print("\n[bold]Timeline[/bold]")
        for e in ledger.events():
            if e["target"] == st.id:
                console.print(f"  {e['ts'][11:19]}  {e['state']:8} {e['reason'] or '':10} {e['note'][:80]}")
        console.print(f"\nactions: {', '.join(valid) or 'none'}")
        return
    if action not in valid:
        raise click.ClickException(f"{action} not valid for {st.state}. Valid: {', '.join(valid) or 'none'}")
    if action == "retry":
        ledger.transition(st.id, "queued", "retry", "operator retry", attempts=max(0, st.attempts - 1))
        console.print(f"{st.id} queued (one more attempt granted)")
    elif action == "skip":
        ledger.transition(st.id, "skipped", "operator", "skipped by operator")
    elif action == "take":
        ledger.transition(st.id, "blocked", "taken", "taken by operator")
        console.print(f"yours. worktree: {st.worktree}\ncontinue: cd {st.worktree} && claude" + (f" --resume {st.session_id}" if st.session_id else ""))
        console.print("when done: fanout target %s give" % st.id)
    elif action == "give":
        wt = Path(st.worktree)
        git_ops.commit_all(wt, "fanout: operator changes")
        if give_skip:
            ledger.transition(st.id, "skipped", "operator", "given back as skipped")
        else:
            root = wt / (cfg.target(st.id).subpath or "")
            summ = (root / "SUMMARY.md").read_text() if (root / "SUMMARY.md").exists() else "status: complete\nnotes: completed manually by operator\n"
            ledger.write_artifact(st.id, "summary.md", summ)
            ledger.transition(st.id, "done", None, "completed by operator", decision=None)
    elif action == "rewind":
        if not st.worktree:
            raise click.ClickException("nothing to rewind (never prepared)")
        tagname = f"{st.branch}@{tag or 'prepared'}"
        git_ops.reset_to_tag(Path(st.worktree), tagname)
        n = 0 if (tag or "prepared") == "prepared" else int(tag.split("-")[-1])
        ledger.transition(st.id, "queued", "rewind", f"rewound to {tag or 'prepared'}", attempts=n, decision=None, session_id=None, verifier_ok=None)
        ledger.clear_artifact(st.id, "summary.md")
        ledger.clear_artifact(st.id, "question.md")
    if action in ("retry", "rewind") and not runner_alive(cfg.dir):
        pid = spawn_detached(cfg.dir)
        console.print(f"runner restarted (pid {pid})")
        time.sleep(0.5)
    _next(ledger)


if __name__ == "__main__":  # pragma: no cover
    main()
