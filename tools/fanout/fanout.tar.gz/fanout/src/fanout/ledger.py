"""The ledger owns every write to run state. Nothing else touches targets/*/state.json."""
from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterator

from .config import RunConfig, now_iso

STATES = ("queued", "running", "blocked", "done", "failed", "shipped", "skipped")

# shipped is terminal; everything else can move. Reasons carry the detail.
TERMINAL = {"shipped"}

SECRET_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key|secret|token|password|passwd|pwd)\s*[=:]\s*['\"]?([A-Za-z0-9_\-./+]{8,})"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"ghp_[A-Za-z0-9]{20,}"),
    re.compile(r"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}"),
]


def runner_alive(run_dir: Path, stale_s: int = 60) -> bool:
    p = run_dir / "runner.json"
    if not p.exists():
        return False
    try:
        d = json.loads(p.read_text())
    except json.JSONDecodeError:
        return False
    if time.time() - d.get("epoch", 0) > stale_s:
        return False
    try:
        os.kill(int(d["pid"]), 0)
        return True
    except (OSError, KeyError, ValueError):
        return False


def redact(text: str) -> str:
    out = text
    for pat in SECRET_PATTERNS:
        out = pat.sub(lambda m: (m.group(0)[: m.start(2) - m.start(0)] + "[REDACTED]") if m.lastindex else "[REDACTED]", out)
    # env values that look like secrets
    for k, v in os.environ.items():
        if v and len(v) >= 12 and re.search(r"(?i)key|secret|token|pass", k):
            out = out.replace(v, f"[${k}]")
    return out


@dataclass
class TargetState:
    id: str
    state: str = "queued"
    reason: str | None = None
    decision: str | None = None  # approved | rejected
    attempts: int = 0       # sessions started (informational)
    failures: int = 0       # stalls + errors + verifier failures; counts against max_attempts
    session_id: str | None = None
    branch: str | None = None
    worktree: str | None = None
    base: str | None = None
    cost_usd: float = 0.0
    last_note: str = ""
    question_key: str | None = None
    verifier_ok: bool | None = None
    started: str | None = None
    updated: str = field(default_factory=now_iso)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class Ledger:
    def __init__(self, cfg: RunConfig):
        self.cfg = cfg
        self.dir = cfg.dir
        self.tdir = self.dir / "targets"
        self.tdir.mkdir(parents=True, exist_ok=True)
        self._on_change: list = []

    # ---------- wiring ----------
    def on_change(self, fn) -> None:
        self._on_change.append(fn)

    def _changed(self) -> None:
        for fn in self._on_change:
            try:
                fn(self)
            except Exception:  # renderers must never break the runner
                pass

    # ---------- paths ----------
    def target_dir(self, tid: str) -> Path:
        d = self.tdir / tid
        d.mkdir(parents=True, exist_ok=True)
        return d

    def path(self, tid: str, name: str) -> Path:
        return self.target_dir(tid) / name

    # ---------- state ----------
    def init_targets(self) -> None:
        for t in self.cfg.targets:
            if not self.path(t.id, "state.json").exists():
                self._write(TargetState(id=t.id))
        self._changed()

    def get(self, tid: str) -> TargetState:
        p = self.path(tid, "state.json")
        if not p.exists():
            return TargetState(id=tid)
        return TargetState(**json.loads(p.read_text()))

    def all(self) -> list[TargetState]:
        return [self.get(t.id) for t in self.cfg.targets]

    def _write(self, st: TargetState) -> None:
        st.updated = now_iso()
        tmp = self.path(st.id, "state.json.tmp")
        tmp.write_text(json.dumps(st.to_dict(), indent=1))
        os.replace(tmp, self.path(st.id, "state.json"))

    def update(self, tid: str, **fields: Any) -> TargetState:
        """Update attributes without a state transition."""
        st = self.get(tid)
        for k, v in fields.items():
            setattr(st, k, v)
        self._write(st)
        self._changed()
        return st

    def transition(self, tid: str, new_state: str, reason: str | None = None,
                   note: str = "", **fields: Any) -> TargetState:
        st = self.get(tid)
        if new_state not in STATES:
            raise ValueError(f"unknown state {new_state}")
        if st.state in TERMINAL and new_state != st.state:
            raise ValueError(f"{tid}: {st.state} is terminal")
        st.state, st.reason, st.last_note = new_state, reason, note or st.last_note
        if new_state == "running" and not st.started:
            st.started = now_iso()
        for k, v in fields.items():
            setattr(st, k, v)
        self._write(st)
        self.event(tid, new_state, reason, note)
        return st

    # ---------- events ----------
    def event(self, target: str | None, state: str, reason: str | None = None, note: str = "") -> None:
        rec = {"ts": now_iso(), "target": target, "state": state, "reason": reason, "note": redact(note)[:500]}
        with (self.dir / "events.jsonl").open("a") as f:
            f.write(json.dumps(rec) + "\n")
        self._changed()

    def events(self) -> Iterator[dict[str, Any]]:
        p = self.dir / "events.jsonl"
        if not p.exists():
            return iter(())
        return (json.loads(l) for l in p.read_text().splitlines() if l.strip())

    # ---------- worker artifacts ----------
    def write_artifact(self, tid: str, name: str, text: str) -> None:
        self.path(tid, name).write_text(redact(text))

    def read_artifact(self, tid: str, name: str) -> str | None:
        p = self.path(tid, name)
        return p.read_text() if p.exists() else None

    def clear_artifact(self, tid: str, name: str) -> None:
        p = self.path(tid, name)
        if p.exists():
            p.unlink()

    def append_session(self, tid: str, record: dict[str, Any]) -> None:
        with self.path(tid, "session.jsonl").open("a") as f:
            f.write(redact(json.dumps(record)) + "\n")

    # ---------- summaries ----------
    def counts(self) -> dict[str, int]:
        c = {s: 0 for s in STATES}
        for st in self.all():
            c[st.state] += 1
        return c

    def total_cost(self) -> float:
        return round(sum(s.cost_usd for s in self.all()), 4)

    def questions(self) -> list[TargetState]:
        return [s for s in self.all() if s.state == "blocked" and s.reason == "question"]

    def reviewable(self) -> list[TargetState]:
        return [s for s in self.all() if s.state == "done" and s.decision is None]

    def phase(self) -> str:
        """planning | running | blocked | reviewing | shipping | complete"""
        if not self.cfg.approved:
            return "planning"
        c = self.counts()
        if c["queued"] or c["running"]:
            return "running"
        if self.questions() or any(s.state == "blocked" for s in self.all()):
            return "blocked"
        if self.reviewable():
            return "reviewing"
        if any(s.state == "done" and s.decision == "approved" for s in self.all()):
            return "shipping"
        return "complete"

    def next_hint(self) -> str:
        ph, c = self.phase(), self.counts()
        q = len(self.questions())
        qs = f"{q} question{'s' if q != 1 else ''}"
        failed = [s.id for s in self.all() if s.state == "failed"]
        taken = [s.id for s in self.all() if s.state == "blocked" and s.reason == "taken"]
        if ph == "planning":
            return "fanout plan   (not yet approved: rerun and answer yes)"
        if ph == "running":
            if not runner_alive(self.dir):
                return "fanout run" + (f"   (then fanout answer: {qs})" if q else "   (runner not active)")
            busy = ", ".join(f"{c[s]} {s}" for s in ("running", "queued") if c[s])
            if q:
                return f"fanout answer   ({qs} while {busy})"
            if self.reviewable():
                return f"fanout review   ({len(self.reviewable())} ready while {busy})"
            return f"nothing — {busy}. `fanout status --watch` to follow"
        if ph == "blocked":
            return f"fanout answer   ({qs})" if q else f"fanout target {taken[0]} give   (you took it)"
        if ph in ("reviewing", "shipping"):
            hint = f"fanout review   ({len(self.reviewable())} ready)" if ph == "reviewing" else "fanout review   (approved targets waiting to ship)"
            return hint + (f"   · {len(failed)} failed: fanout target {failed[0]} retry|take|skip" if failed else "")
        return f"complete with {len(failed)} failed: fanout target {failed[0]} retry|take|skip" if failed else "complete"
