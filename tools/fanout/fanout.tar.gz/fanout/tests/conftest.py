from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest
from click.testing import CliRunner

from fanout import cli as cli_mod
from fanout.config import RunConfig, resolve_run
from fanout.ledger import Ledger
from fanout.render import write_progress
from fanout.runner import Runner


def _git(args, cwd):
    subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True)


def make_repo(path: Path, name: str) -> Path:
    repo = path / name
    repo.mkdir(parents=True)
    _git(["init", "-q", "-b", "main"], repo)
    _git(["config", "user.email", "t@t"], repo)
    _git(["config", "user.name", "t"], repo)
    (repo / "hello.txt").write_text("hello\n")
    (repo / "README.md").write_text(f"# {name}\n")
    _git(["add", "-A"], repo)
    _git(["commit", "-q", "-m", "init"], repo)
    return repo


@pytest.fixture
def fleet(tmp_path, monkeypatch):
    """Three tiny repos + isolated FANOUT_HOME. Returns (repos dir, targets file writer)."""
    monkeypatch.setenv("FANOUT_HOME", str(tmp_path / "home"))
    monkeypatch.delenv("FANOUT_RUN", raising=False)
    monkeypatch.setenv("FANOUT_NO_DETACH", "1")
    repos = tmp_path / "repos"
    names = ["alpha", "beta", "gamma"]
    paths = {n: make_repo(repos, n) for n in names}

    def targets(scripts: dict[str, list] | None = None, extra: dict | None = None) -> Path:
        f = tmp_path / "targets.jsonl"
        lines = []
        for n in names:
            d = {"id": n, "path": str(paths[n]), "params": {}}
            if scripts and n in scripts:
                d["params"]["fake"] = scripts[n]
            if extra and n in extra:
                d.update(extra[n])
            lines.append(json.dumps(d))
        f.write_text("\n".join(lines) + "\n")
        return f

    return repos, targets, paths


@pytest.fixture
def cli():
    runner = CliRunner()

    def invoke(*args, input: str | None = None):
        r = runner.invoke(cli_mod.main, list(args), input=input, catch_exceptions=False)
        return r

    return invoke


def open_run(run: str | None = None) -> tuple[RunConfig, Ledger]:
    cfg = RunConfig.load(resolve_run(run))
    ledger = Ledger(cfg)
    ledger.on_change(write_progress)
    return cfg, ledger


def run_to_quiescence(run: str | None = None, worker=None, **kw) -> Ledger:
    """Run the runner in-process until nothing can move (test helper; foreground)."""
    cfg, ledger = open_run(run)
    r = Runner(cfg, ledger, worker=worker, poll_s=0.02)
    r.run(**kw)
    return ledger
