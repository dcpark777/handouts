"""pipelines/pipeline.py — the KFP mirror. Declarative python: this module
constructs DATA (no environment conditionals, no side effects).

Execution model, readable top to bottom:
  * list order IS execution order (each entry starts after the previous
    entry fully completes)
  * parallel(...) entries run concurrently
  * reads/writes don't decide order — they ENFORCE it: runtime pre/post
    checks, plus a load-time consistency check (a step listed before its
    data exists is an error naming both sides).
"""
from kubeflow_utils import Pipeline, Step, Dataset, Resources, parallel, compile_pipeline

from mypackage.steps.compute_snap_date import compute_snap_date
from mypackage.steps.pull import pull
from mypackage.steps.process import process
from mypackage.steps.make_graph import make_graph
from mypackage.steps.publish_primary import publish_primary
from mypackage.steps.publish_mirror import publish_mirror

# ── datasets: name + ONE location ────────────────────────────────────
# relative (no scheme)  -> joined onto the run's base path: env-portable
# scheme'd / absolute   -> standalone, fixed location
raw       = Dataset("raw",       "snap_date={snap_date}/raw/")
features  = Dataset("features",  "s3://shared-features/reference/latest")
processed = Dataset("processed", "snap_date={snap_date}/processed.parquet")
graph     = Dataset("graph",     "snap_date={snap_date}/graph/")
published = Dataset("published", "prodlake://{dataset_id}")
mirror    = Dataset("mirror",    "snap_date={snap_date}/mirror/")

pipeline = Pipeline(
    "graph-pipeline",
    params={
        "snap_date":  str,             # satisfied by compute_snap_date's output
        "base_path":  str,             # the run's base for relative datasets
        "dataset_id": str,
        "update":     (bool, False),   # (type, default)
    },
    steps=[
        Step(compute_snap_date, outputs=["snap_date"]),
        Step(pull,       writes=[raw],
             resources=Resources(cpu="4", memory="16Gi")),
        Step(process,    reads=[raw, features],  writes=[processed]),
        Step(make_graph, reads=[raw, processed], writes=[graph],
             resources=Resources(cpu="8", memory="32Gi",
                                 image="registry.example.com/spark:latest")),
        parallel(
            Step(publish_primary, reads=[graph], writes=[published]),
            Step(publish_mirror,  reads=[graph], writes=[mirror]),
        ),
    ],
)

if __name__ == "__main__":
    compile_pipeline(pipeline, "pipeline.yaml")     # CICD: python pipelines/pipeline.py
