# kubeflow-utils authoring structure — worked example

Reading order:
  1. src/mypackage/steps/     the component entrypoints (one module each; `ls` = the component list)
  2. src/mypackage/lib/       helpers — never entrypoints
  3. run_pipeline.py          the LOCAL truth: plain python, runs end-to-end
  4. pipelines/pipeline.py    the KFP mirror: declarative, ordered, checked
  5. notebook_cells.py        what the dev loop looks like in a notebook
  6. validate_output.txt      what `kubeflow-utils validate` / `kubeflow-utils dag` show you

Layout:
  src/mypackage/
    steps/          entrypoints: pull, process, make_graph, publish_primary,
                    publish_mirror, compute_snap_date
    lib/            transforms, spark part-renaming, sql helpers
  pipelines/
    pipeline.py     the manifest (ordered steps, parallel(), params, datasets)
  sql/              jinja sql templates (used by pull via SqlRunner)
  run_pipeline.py   local end-to-end script
