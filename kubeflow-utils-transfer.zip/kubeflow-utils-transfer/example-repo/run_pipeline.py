"""run_pipeline.py — the LOCAL truth. Plain python; runs end-to-end in a
notebook or terminal. Indistinguishable from any run.py you'd write today.

The KFP mirror (pipelines/pipeline.py) MIRRORS this file; the functions
are the shared, unmodified computation.
"""
from mypackage.steps.compute_snap_date import compute_snap_date
from mypackage.steps.pull import pull
from mypackage.steps.process import process
from mypackage.steps.make_graph import make_graph
from mypackage.steps.publish_primary import publish_primary
from mypackage.steps.publish_mirror import publish_mirror


def run_pipeline(snap_date: str | None = None, base: str = "./data",
                 dataset_id: str = "graph_dev", update: bool = False) -> None:
    snap_date = snap_date or compute_snap_date()
    root = f"{base}/snap_date={snap_date}"

    pull(raw=f"{root}/raw/", snap_date=snap_date)
    process(raw=f"{root}/raw/",
            features="s3://shared-features/reference/latest",
            processed=f"{root}/processed.parquet",
            snap_date=snap_date)
    make_graph(raw=f"{root}/raw/", processed=f"{root}/processed.parquet",
               graph=f"{root}/graph/", snap_date=snap_date, update=update)
    publish_primary(graph=f"{root}/graph/", published=f"prodlake://{dataset_id}",
                    dataset_id=dataset_id, snap_date=snap_date)
    publish_mirror(graph=f"{root}/graph/", mirror=f"{root}/mirror/",
                   snap_date=snap_date)


if __name__ == "__main__":
    run_pipeline("2026-08-06")
