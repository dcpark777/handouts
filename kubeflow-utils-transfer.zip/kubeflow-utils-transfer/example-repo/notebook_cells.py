"""What the dev loop looks like in a notebook — as cells. kubeflow-utils's
structural layer is absent; only resolvers appear, and only where needed.

# ── cell 1: explore raw data (no functions yet) ──
import polars as pl
snap, root = "2026-08-06", "./data/snap_date=2026-08-06"
df = pl.read_parquet(f"{root}/raw/customers.parquet")
df.group_by("segment").len()

# ── cell 2: iterate on the transform (pure — no IO involved) ──
from mypackage.lib.transforms import enrich_and_dedupe
result = enrich_and_dedupe(df, accounts, reference, snap_date=snap)
result.head()

# ── cell 3: run one step, inspect its output on disk, tweak, rerun ──
from mypackage.steps.process import process
process(raw=f"{root}/raw/", features="s3://shared-features/reference/latest",
        processed=f"{root}/processed.parquet", snap_date=snap)
pl.read_parquet(f"{root}/processed.parquet").describe()

# ── cell 4: end-to-end when you want the whole thing ──
from run_pipeline import run_pipeline
run_pipeline(snap)
"""
