"""Pure transforms — no IO, no resolvers, unit-testable with in-memory frames."""
import polars as pl


def enrich_and_dedupe(customers: pl.DataFrame, accounts: pl.DataFrame,
                      reference: pl.DataFrame, *, snap_date: str) -> pl.DataFrame:
    return (
        customers
        .join(accounts, on="customer_id", how="left")
        .join(reference, on="segment", how="left")
        .filter(pl.col("as_of") <= snap_date)
        .unique(subset=["customer_id"], keep="last")
    )
