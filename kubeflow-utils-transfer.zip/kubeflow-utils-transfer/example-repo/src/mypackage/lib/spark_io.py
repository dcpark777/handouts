"""Spark write shaping — DOMAIN code (kubeflow-utils ships no rename helper).
Works locally and remotely because the caller passes the store's fsspec
filesystem (mv = local move / remote copy+delete)."""


def rename_parts(fs, target: str, name_fn) -> None:
    parts = sorted(p for p in fs.ls(target) if "/part-" in p)
    total = len(parts)
    for index, old_path in enumerate(parts):
        fs.mv(old_path, f"{target}/{name_fn(index, total)}")
    success = f"{target}/_SUCCESS"
    if fs.exists(success):
        fs.rm(success)
