"""Scalar step: computes runtime values, writes no datasets.

Returns are the declared `outputs` (scalars only — a returned DataFrame is
a runner error). On KFP the value rides native parameter passing to any
downstream signature that names it. Locally you just call it.
"""
import datetime


def compute_snap_date() -> str:
    # real logic: business-calendar lookup, source probe, etc.
    return (datetime.date.today() - datetime.timedelta(days=1)).isoformat()
