"""Second publisher — runs in parallel with publish_primary on KFP (both
sit inside parallel(...) in the manifest); locally it's simply the next
function call. Nothing in THIS file knows it is parallel."""
import polars as pl


def publish_mirror(graph: str, mirror: str, snap_date: str) -> None:
    # glob (not bare dir): Spark-written dirs can carry marker files
    # (_SUCCESS) that a bare-directory read would try to parse as parquet.
    frames = pl.read_parquet(f"{graph}/*.parquet")
    frames.write_parquet(f"{mirror}/graph_{snap_date}.parquet")
