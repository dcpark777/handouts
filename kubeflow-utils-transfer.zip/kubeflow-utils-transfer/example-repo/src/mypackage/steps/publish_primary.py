"""Publish to a remote, credential-brokered destination.

`published` arrives as "prodlake://<dataset_id>" (resolved from the manifest
location template). DataStore(published) resolves the brokered credentials —
the one place the resolver is REQUIRED rather than convenient, because a
plain engine call can't broker this backend's auth on its own.
"""
from kubeflow_utils import DataStore, Spark


def publish_primary(graph: str, published: str,
                    dataset_id: str, snap_date: str) -> None:
    spark = Spark().get_session()
    graph_df = spark.read.parquet(graph)

    store = DataStore(published)                 # prodlake://... -> fs + creds
    graph_df.write.mode("overwrite").parquet(store.uri)
