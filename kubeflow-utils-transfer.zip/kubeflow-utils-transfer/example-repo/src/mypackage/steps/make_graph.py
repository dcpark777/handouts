"""Spark step with a bespoke write (coalesce + deterministic part names).

Patterns shown:
  * Spark(...) returns a real SparkSession: framework base conf applied,
    user extra_conf layered on top (user wins on clashes).
  * bespoke write logic (coalesce count, part naming) is DOMAIN code in
    lib/ — kubeflow-utils resolved the session; the write is yours.
"""
from kubeflow_utils import DataStore, Spark

from mypackage.lib.spark_io import rename_parts


def make_graph(raw: str, processed: str, graph: str,
               snap_date: str, update: bool) -> None:
    spark = Spark(app_name="make-graph",
                  extra_conf={"spark.sql.shuffle.partitions": "400"}).get_session()

    txns = spark.read.parquet(f"{raw}/transactions.parquet")
    processed_df = spark.read.parquet(processed)

    graph_df = _build_edges(txns, processed_df, incremental=update)   # transform

    graph_df.coalesce(30).write.mode("overwrite").parquet(graph)      # bespoke write
    rename_parts(DataStore(graph).filesystem, graph,
                 name_fn=lambda i, n: f"graph_{i:02d}.parquet")


def _build_edges(txns, processed_df, incremental: bool):
    ...  # your graph logic
