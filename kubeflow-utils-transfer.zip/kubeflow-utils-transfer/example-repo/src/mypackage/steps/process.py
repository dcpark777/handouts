"""Plain polars ETL in the read/transform/write shape.

read + write are one line each; the transform is pure and lives in lib/
so it is unit-testable with no IO at all.
"""
import polars as pl

from mypackage.lib.transforms import enrich_and_dedupe


def process(raw: str, features: str, processed: str, snap_date: str) -> None:
    customers = pl.read_parquet(f"{raw}/customers.parquet")        # read
    accounts = pl.read_parquet(f"{raw}/accounts.parquet")
    reference = pl.read_parquet(features)                          # s3:// works too
    # note: raw is SqlRunner-written (only .parquet files), so reading the
    # bare directory pl.read_parquet(raw) would work too; the explicit file
    # reads here are because process uses specific datasets.

    result = enrich_and_dedupe(customers, accounts, reference,     # transform (pure)
                               snap_date=snap_date)

    result.write_parquet(processed)                                # write
