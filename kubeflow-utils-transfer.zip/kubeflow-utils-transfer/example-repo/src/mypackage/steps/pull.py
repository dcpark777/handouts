"""Pull step: N warehouse queries -> N parquet files under `raw`.

Patterns shown:
  * internal parallelism (concurrent queries) stays INSIDE one step —
    one KFP component, not N.
  * SqlRunner is the optional helper for exactly this recurring shape; a
    hand-rolled loop over Snowflake().get_connection() is equally valid.
  * `raw` is a plain string path (local dir or s3://...) — the function
    neither knows nor cares which.
"""
from kubeflow_utils import Snowflake
from kubeflow_utils.helpers import SqlRunner, SqlQuery, date_window

DATA_TYPES = {"customers": 30, "accounts": 61, "transactions": 10_000}


def pull(raw: str, snap_date: str) -> None:
    runner = SqlRunner(
        connection_factory=Snowflake().get_connection,
        output=raw,                              # string path; resolver inside
        sql_root="sql",
        queries=[
            SqlQuery(f"{name}.sql.j2", dataset=name,
                     vars=date_window(snap_date, lookback),
                     output_file=f"{name}.parquet")
            for name, lookback in DATA_TYPES.items()
        ],
        params={"snap_date": snap_date},
        concurrency=8,
        skip_existing=True,
    )
    runner.run()
