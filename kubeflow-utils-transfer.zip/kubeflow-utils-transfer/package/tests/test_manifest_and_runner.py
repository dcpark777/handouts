"""Manifest load-time checks + runner enforcement, end to end."""
import json
import pathlib
import pytest
from kubeflow_utils.manifest import Pipeline, Step, Dataset, parallel, ManifestError
from kubeflow_utils.compile import compile_spec
from kubeflow_utils import runner as R

raw = Dataset("raw", "snap_date={snap_date}/raw/")
summed = Dataset("summed", "snap_date={snap_date}/summed.txt")


def make_data(raw: str, snap_date: str) -> None:
    pathlib.Path(raw).mkdir(parents=True, exist_ok=True)
    pathlib.Path(f"{raw}/rows.json").write_text(json.dumps([1, 2, 3]))


def total(raw: str, summed: str, snap_date: str, factor: int = 1) -> None:
    rows = json.loads(pathlib.Path(f"{raw}/rows.json").read_text())
    pathlib.Path(summed).write_text(str(sum(rows) * factor))


def pick_date() -> str:
    return "2026-08-06"


def broken(raw: str, summed: str, snap_date: str):
    return None


def leaky(raw: str, snap_date: str):
    return {"df": [1, 2, 3]}


def params_for(base) -> dict:
    return {"snap_date": json.dumps("2026-08-06"),
            "base_path": str(base), "factor": "2"}


def pipeline() -> Pipeline:
    return Pipeline("t", params={"snap_date": str, "base_path": str,
                                 "factor": (int, 2)},
                    steps=[Step(pick_date, outputs=["snap_date"]),
                           Step(make_data, writes=[raw]),
                           Step(total, reads=[raw], writes=[summed])])


def test_compile_spec_routing():
    spec = compile_spec(pipeline())
    assert [s.stage for s in spec.steps] == [0, 1, 2]
    total_step = next(s for s in spec.steps if s.name == "total")
    assert "factor" in total_step.consumes_params
    assert "snap_date" in total_step.consumes_outputs


def test_end_to_end_through_runner(tmp_path):
    params = params_for(tmp_path)
    scalars = R.run_step(pick_date, step_name="pick_date", reads={}, writes={},
                         params={}, outputs=["snap_date"], mapping={})
    assert scalars == {"snap_date": "2026-08-06"}
    R.run_step(make_data, step_name="make_data", reads={},
               writes={"raw": raw.location}, params=params, outputs=[], mapping={})
    R.run_step(total, step_name="total", reads={"raw": raw.location},
               writes={"summed": summed.location}, params=params, outputs=[], mapping={})
    assert (tmp_path / "snap_date=2026-08-06/summed.txt").read_text() == "12"


def test_precondition_missing_read(tmp_path):
    with pytest.raises(R.RunnerError, match="not found"):
        R.run_step(total, step_name="total",
                   reads={"raw": "snap_date={snap_date}/nope/"},
                   writes={"summed": summed.location},
                   params=params_for(tmp_path), outputs=[], mapping={})


def test_postcondition_unwritten_write(tmp_path):
    params = params_for(tmp_path)
    R.run_step(make_data, step_name="make_data", reads={},
               writes={"raw": raw.location}, params=params, outputs=[], mapping={})
    with pytest.raises(R.RunnerError, match="declared it writes"):
        R.run_step(broken, step_name="broken", reads={"raw": raw.location},
                   writes={"summed": "snap_date={snap_date}/never.txt"},
                   params=params, outputs=[], mapping={})


def test_scalar_only_returns(tmp_path):
    params = params_for(tmp_path)
    R.run_step(make_data, step_name="make_data", reads={},
               writes={"raw": raw.location}, params=params, outputs=[], mapping={})
    with pytest.raises(R.RunnerError, match="communicate through storage"):
        R.run_step(leaky, step_name="leaky", reads={"raw": raw.location},
                   writes={}, params=params, outputs=[], mapping={})


def test_order_vs_dataflow():
    with pytest.raises(ManifestError, match="order-vs-dataflow"):
        Pipeline("bad", params={"snap_date": str, "base_path": str},
                 steps=[Step(total, reads=[raw], writes=[summed]),
                        Step(make_data, writes=[raw])])


def test_unmatched_signature_param():
    with pytest.raises(ManifestError, match="matches no dataset"):
        Pipeline("bad", params={"base_path": str},
                 steps=[Step(make_data, writes=[Dataset("raw2", "raw2/")])])


def test_template_typo_and_missing_base_path():
    with pytest.raises(ManifestError, match="neither a pipeline param"):
        Pipeline("bad", params={"snap_date": str, "base_path": str},
                 steps=[Step(make_data,
                             writes=[Dataset("raw3", "snap_date={snap_dat}/r/")])])
    with pytest.raises(ManifestError, match="no base_path param"):
        Pipeline("bad", params={"snap_date": str},
                 steps=[Step(make_data, writes=[Dataset("raw4", "r/")])])


def test_parallel_stage_and_runner_cli(tmp_path):
    pipe = Pipeline("p", params={"snap_date": str, "base_path": str},
                    steps=[Step(make_data, writes=[raw]),
                           parallel(Step(total, reads=[raw], writes=[summed]),
                                    Step(pick_date, outputs=["snap_date"]))])
    spec = compile_spec(pipe)
    assert [s.stage for s in spec.steps] == [0, 1, 1]
    out = tmp_path / "out.txt"
    R.main(["--fn", f"{__name__}:pick_date", "--step", "pick_date",
            "--output", f"snap_date={out}"])
    assert json.loads(out.read_text()) == "2026-08-06"
