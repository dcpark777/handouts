"""kubeflow_utils.runner — the generic component entrypoint. One runner for every
step; the framework SURROUNDS the function (never inherited, never wrapped
in user code):

    resolve dataset templates -> pre-check reads exist -> build kwargs by
    signature -> call fn -> post-check writes exist -> enforce scalar-only
    returns -> serialize declared outputs        (+ uniform logging/timing)

Invoked in-container as:
  python -m kubeflow_utils.runner --fn mypackage.steps.process:process
      --read raw='snap_date={snap_date}/raw/' --write processed='...'
      --param snap_date='"2026-08-06"' --param base_path='"s3://..."'
      [--output snap_date=/kfp/outputs/snap_date]

Params arrive JSON-encoded; decoded by the function's own annotations.
The SAME machinery backs local `kubeflow-utils run` for parity.
"""
from __future__ import annotations

import argparse
import importlib
import inspect
import json
import time
from typing import Any, Callable

SCALARS = (str, int, float, bool, type(None))


class RunnerError(RuntimeError):
    pass


def import_fn(dotted_path: str) -> Callable[..., Any]:
    module_name, _, attr = dotted_path.partition(":")
    return getattr(importlib.import_module(module_name), attr)


def decode_param(raw: str, annotation: Any) -> Any:
    """JSON first; a bare string that isn't valid JSON is the string itself
    (so plain CLI values work). Annotation wins for str: '2026' stays str."""
    if annotation is str:
        try:
            decoded = json.loads(raw)
            return decoded if isinstance(decoded, str) else raw
        except (json.JSONDecodeError, ValueError):
            return raw
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return raw


def build_kwargs(fn: Callable, resolved: dict[str, str],
                 params: dict[str, Any], mapping: dict[str, str]) -> dict:
    """Signature is the filter: dataset names -> resolved paths; other
    names -> params (pipeline params + upstream outputs); args= mapping
    rewires individual names."""
    kwargs: dict[str, Any] = {}
    sig = inspect.signature(fn)
    for pname, parameter in sig.parameters.items():
        source = mapping.get(pname, pname)
        if source in resolved:
            kwargs[pname] = resolved[source]
        elif source in params:
            kwargs[pname] = decode_param(params[source], parameter.annotation)
        elif parameter.default is not inspect.Parameter.empty:
            continue
        else:
            raise RunnerError(
                f"{fn.__name__}() parameter {pname!r}: nothing supplies it "
                f"(not a dataset of this step, not a param). This should "
                f"have been caught by `kubeflow-utils validate`.")
    return kwargs


def check_exists(kind: str, step: str, names_to_uris: dict[str, str]) -> None:
    from kubeflow_utils import DataStore
    missing = {name: uri for name, uri in names_to_uris.items()
               if not DataStore(uri).exists()}
    if missing:
        listing = "\n".join(f"  - {n}: {u}" for n, u in missing.items())
        verb = "requires" if kind == "read" else "declared it writes"
        raise RunnerError(
            f"step {step!r} {verb} the following dataset(s), not found:\n"
            f"{listing}\n"
            + ("Upstream may not have run, or the location template differs "
               "from what the writer used." if kind == "read" else
               f"{step}() returned without writing them — every declared "
               f"write must exist when the step ends."))


def run_step(fn: Callable, *, step_name: str, reads: dict[str, str],
             writes: dict[str, str], params: dict[str, str],
             outputs: list[str], mapping: dict[str, str]) -> dict[str, Any]:
    from kubeflow_utils import get_logger
    log = get_logger(f"kubeflow_utils.step.{step_name}")

    resolved_reads = _resolve(reads, params, fn)
    resolved_writes = _resolve(writes, params, fn)

    check_exists("read", step_name, resolved_reads)                 # pre
    log.info("start reads=%s writes=%s", list(reads), list(writes))
    started = time.monotonic()

    kwargs = build_kwargs(fn, {**resolved_reads, **resolved_writes},
                          params, mapping)
    result = fn(**kwargs)

    check_exists("write", step_name, resolved_writes)               # post
    scalars = _enforce_scalar_returns(step_name, outputs, result)
    log.info("done in %.1fs", time.monotonic() - started)
    return scalars


def _resolve(templates: dict[str, str], params: dict[str, str], fn) -> dict:
    decoded = {k: decode_param(v, str) for k, v in params.items()}
    out = {}
    for name, template in templates.items():
        located = template.format(**decoded)
        if "://" in located or located.startswith("/"):
            out[name] = located.rstrip("/")
        else:
            out[name] = f"{str(decoded.get('base_path','')).rstrip('/')}/{located}".rstrip("/")
    return out


def _enforce_scalar_returns(step: str, outputs: list[str], result: Any) -> dict:
    if not outputs:
        if result is not None:
            raise RunnerError(
                f"step {step!r} returned a {type(result).__name__} but "
                f"declares no outputs. Steps communicate through storage — "
                f"write datasets; return values are only for declared "
                f"scalar outputs.")
        return {}
    values = result if isinstance(result, tuple) else (result,)
    if len(values) != len(outputs):
        raise RunnerError(f"step {step!r} declares outputs {outputs} but "
                          f"returned {len(values)} value(s)")
    for name, value in zip(outputs, values):
        if not isinstance(value, SCALARS):
            raise RunnerError(
                f"step {step!r} output {name!r} is {type(value).__name__} — "
                f"outputs ride the orchestrator's param passing and must be "
                f"scalars. Dataframes cross through storage.")
    return dict(zip(outputs, values))


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="kubeflow_utils.runner")
    parser.add_argument("--fn", required=True)
    parser.add_argument("--step", required=True)
    parser.add_argument("--read", action="append", default=[])
    parser.add_argument("--write", action="append", default=[])
    parser.add_argument("--param", action="append", default=[])
    parser.add_argument("--map", action="append", default=[])
    parser.add_argument("--output", action="append", default=[],
                        help="name=/path/to/kfp/output/file")
    ns = parser.parse_args(argv)

    split = lambda pairs: dict(p.split("=", 1) for p in pairs)
    out_paths = split(ns.output)
    scalars = run_step(
        import_fn(ns.fn), step_name=ns.step,
        reads=split(ns.read), writes=split(ns.write),
        params=split(ns.param), outputs=list(out_paths), mapping=split(ns.map))
    for name, path in out_paths.items():
        with open(path, "w") as f:
            f.write(json.dumps(scalars[name]))


if __name__ == "__main__":
    main()
