"""kubeflow_utils.compile — manifest -> deployable pipeline.

Two halves, deliberately separated:

  1. compile_spec(pipeline)  PURE: manifest -> CompiledPipeline (per-step
     runner command, env, resources, stage edges). Fully testable anywhere;
     `kubeflow-utils run` executes it locally with the SAME runner as the cluster.
  2. to_kfp(compiled)        the ONLY kfp-touching code. Builds container
     components around the runner commands, wires stage barriers with
     .after(), scalar outputs via output params, stamps RUNTIME_MODE=kfp
     + KUBEFLOW_UTILS_* env. Dev provisioning (inline zip + pip) vs prod (baked
     image) is chosen HERE at compile time.  [validate on the work KFP —
     marked, not guessed]
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from kubeflow_utils.manifest import Pipeline, Step


@dataclass
class CompiledStep:
    name: str
    command: list[str]
    stage: int
    resources: dict[str, Any]
    consumes_params: list[str]           # pipeline params this step needs
    consumes_outputs: list[str]          # upstream scalar outputs it needs
    produces_outputs: list[str]


@dataclass
class CompiledPipeline:
    name: str
    params: dict[str, Any]               # name -> {"type","default"?}
    env: dict[str, str]
    steps: list[CompiledStep] = field(default_factory=list)

    def stage_of(self, name: str) -> int:
        return next(s.stage for s in self.steps if s.name == name)


def _step_command(step: Step, pipeline: Pipeline,
                  scalar_sources: dict[str, str]) -> tuple[list[str], list[str], list[str]]:
    import inspect
    cmd = ["python", "-m", "kubeflow_utils.runner",
           "--fn", step.dotted_path, "--step", step.name]
    for ds in step.reads:
        cmd += ["--read", f"{ds.name}={ds.location}"]
    for ds in step.writes:
        cmd += ["--write", f"{ds.name}={ds.location}"]
    for target, source in step.args.items():
        name = source.name if hasattr(source, "name") else str(source)
        cmd += ["--map", f"{target}={name}"]

    dataset_names = {ds.name for ds in (*step.reads, *step.writes)}
    needed_params, needed_outputs = [], []
    for pname in inspect.signature(step.fn).parameters:
        source = step.args.get(pname, pname)
        source = source.name if hasattr(source, "name") else source
        if source in dataset_names:
            continue
        if source in scalar_sources and scalar_sources[source] != step.name:
            needed_outputs.append(source)
        elif source in pipeline.param_types:
            needed_params.append(source)
    # location templates may need params the signature doesn't mention
    for ds in (*step.reads, *step.writes):
        for pname in pipeline.param_types:
            if f"{{{pname}}}" in ds.location and pname not in needed_params:
                needed_params.append(pname)
    if "base_path" in pipeline.param_types and "base_path" not in needed_params:
        if any("://" not in d.location and not d.location.startswith("/")
               for d in (*step.reads, *step.writes)):
            needed_params.append("base_path")
    return cmd, needed_params, needed_outputs


def compile_spec(pipeline: Pipeline) -> CompiledPipeline:
    scalar_sources = {out: step.name
                      for step in pipeline.flat_steps for out in step.outputs}
    compiled = CompiledPipeline(
        name=pipeline.name,
        params={n: ({"type": t.__name__, "default": pipeline.param_defaults[n]}
                    if n in pipeline.param_defaults else {"type": t.__name__})
                for n, t in pipeline.param_types.items()},
        env=dict(pipeline.env))
    for stage_index, stage in enumerate(pipeline.stages):
        for step in stage:
            cmd, needs_p, needs_o = _step_command(step, pipeline, scalar_sources)
            compiled.steps.append(CompiledStep(
                name=step.name, command=cmd, stage=stage_index,
                resources={k: v for k, v in vars(step.resources).items() if v},
                consumes_params=needs_p, consumes_outputs=needs_o,
                produces_outputs=list(step.outputs)))
    return compiled


def render_dag(compiled: CompiledPipeline) -> str:
    """Text DAG, printed on every compile — the explicit order, on demand
    without being a separate command."""
    lines = [compiled.name]
    stages: dict[int, list[CompiledStep]] = {}
    for step in compiled.steps:
        stages.setdefault(step.stage, []).append(step)
    for index in sorted(stages):
        group = stages[index]
        for position, step in enumerate(group):
            marker = ("   " if len(group) == 1 else
                      (" ├─" if position < len(group) - 1 else " └─"))
            wiring = []
            if step.consumes_outputs:
                wiring.append("<- " + ", ".join(
                    f"{o}[output]" for o in step.consumes_outputs))
            if step.produces_outputs:
                wiring.append("-> " + ", ".join(step.produces_outputs))
            tag = "  (parallel)" if len(group) > 1 else ""
            lines.append(f"  {index + 1}.{marker} {step.name}{tag}"
                         + (("  " + " ".join(wiring)) if wiring else ""))
    return "\n".join(lines)


def compile_pipeline(pipeline: Pipeline, output_path: str = "pipeline.yaml",
                     *, mode: str = "prod", steps_package: str = "",
                     check: "bool | None" = None) -> Any:
    """THE one shipping entry, used by pipelines/pipeline.py __main__.
    Validates, prints findings + the DAG, then compiles — so there is no
    separate validate/dag command to remember. `--check` (or check=True
    via CLI arg) validates and prints without emitting a pipeline: same
    command in CI.

    Auto-detects the steps package for the bidirectional sweep from the
    first step's module (mypackage.steps.pull -> mypackage.steps).
    """
    import sys
    from kubeflow_utils.validate import validate

    if not steps_package and pipeline.flat_steps:
        module = pipeline.flat_steps[0].fn.__module__
        steps_package = module.rsplit(".", 1)[0] if "." in module else ""

    findings = validate(pipeline, steps_package)
    for finding in findings:
        print(("ERROR " if finding.startswith("ERROR") else "warn  ")
              + finding.removeprefix("ERROR "), file=sys.stderr)
    compiled = compile_spec(pipeline)
    print(render_dag(compiled))

    errors = [f for f in findings if f.startswith("ERROR")]
    if errors:
        raise SystemExit(f"{len(errors)} error(s) — pipeline not compiled.")
    if check is None:                       # __main__ convenience only;
        check = "--check" in sys.argv       # programmatic callers pass check=
    if check:
        print(f"ok: {len(compiled.steps)} steps, "
              f"{len(compiled.params)} params — nothing emitted (--check).")
        return compiled
    return to_kfp(compiled, output_path, mode=mode)


def to_kfp(compiled: CompiledPipeline, output_path: str, *, mode: str) -> Any:
    """The kfp binding. mode='dev' -> inline-compiler provisioning (zip on
    path + per-component pip incl. kubeflow-utils); mode='prod' -> baked image.

    SKETCH to be validated against the work cluster's KFP version + the
    existing inline compiler; the container contract is fixed though:
      command  = compiled.step.command
                 + [--param name={{kfp input}} ...]
                 + [--output name={{kfp output path}} ...]
      env      = RUNTIME_MODE=kfp, KUBEFLOW_UTILS_<K>=<v> for compiled.env
      after    = every component of stage N-1 (stage barrier)
      resources= cpu/memory/image per CompiledStep.resources
    """
    raise NotImplementedError(
        "kfp binding is validated on the work environment (inline compiler "
        "+ platform submit); compile_spec() above is the portable half.")
