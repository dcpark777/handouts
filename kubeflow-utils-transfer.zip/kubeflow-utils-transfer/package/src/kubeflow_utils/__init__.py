"""kubeflow-utils — resolvers + structure for notebook<->KFP pipelines.

Resolvers (importable from mypackage; the ONLY kubeflow-utils surface user
functions touch):
    DataStore(path)                    path + credentials
    Spark(...).get_session()           session
    Snowflake(...).get_connection()    warehouse auth
    get_logger(name)                   pre-configured logging

Structure (imported ONLY by pipelines/pipeline.py):
    Pipeline, Step, Dataset, Resources, parallel, compile_pipeline
"""
from kubeflow_utils.datastore import DataStore, SourceKind, StoreLike, classify_source  # noqa
from kubeflow_utils.spark import Spark                                          # noqa
from kubeflow_utils.snowflake import Snowflake                                  # noqa


def get_logger(name: str = "kubeflow-utils"):
    import logging
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)s %(name)s :: %(message)s"))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger
