"""fs_io — one DataStore over local, generic S3, staging-lake S3, and production lake.

Faithful implementation of the FS_IO design:
  * ONE concrete implementation (FsspecDataStore). No per-backend
    subclasses — fsspec supplies the polymorphism; only the path and
    the credentials vary.
  * No dataframe read/write methods (guardrail #1). The store exposes
    uri / filesystem / storage_options / polars_provider and each call
    site reads or writes with its own engine.
  * No Snowflake store (guardrail #2): Snowflake is tables, not paths.
  * join() uses '/', never os.path.join (Windows backslash breaks S3).

staging lake / production lake branches need the lake-broker sdk and are imported lazily —
local and generic-S3 work without it.
"""
from __future__ import annotations

import re
from enum import Enum, auto
from pathlib import Path
from typing import IO, Any, Callable, Optional, Protocol
from urllib.parse import urlsplit

PolarsCredentialProvider = Callable[[], Any]


class SourceKind(Enum):
    """Which backend a source path resolves to, before any credentials
    are fetched."""
    LOCAL = auto()
    PRODUCTION_LAKE_DATASET = auto()
    STAGING_LAKE = auto()
    GENERIC_S3 = auto()


class StoreLike(Protocol):
    @property
    def kind(self) -> SourceKind: ...
    @property
    def uri(self) -> str: ...
    @property
    def filesystem(self) -> Any: ...                 # fsspec AbstractFileSystem
    @property
    def storage_options(self) -> dict[str, Any]: ...
    @property
    def polars_provider(self) -> Optional[PolarsCredentialProvider]: ...
    def join(self, *path_segments: str) -> str: ...
    def exists(self, relative_path: str = "") -> bool: ...
    def ls(self, relative_path: str = "") -> list[str]: ...
    def glob(self, glob_pattern: str) -> list[str]: ...
    def open(self, relative_path: str = "", file_mode: str = "rb") -> IO[bytes]: ...


class FsspecDataStore:
    """The only concrete DataStore. All backends collapse here."""

    def __init__(
        self,
        filesystem: Any,
        base_path: str,
        *,
        kind: SourceKind = SourceKind.LOCAL,
        polars_provider: Optional[PolarsCredentialProvider] = None,
        storage_options: Optional[dict[str, Any]] = None,
        uri_prefix: str = "",            # e.g. "s3://" for engine-native URIs
    ) -> None:
        self._filesystem = filesystem
        self._base_path = base_path.lstrip("/")
        # what the fsspec filesystem sees: local paths keep their
        # leading slash; bucket-style backends (s3, memory) don't.
        self._fs_base = (f"/{self._base_path}" if uri_prefix == "/"
                         else self._base_path)
        self._kind = kind
        self._polars_provider = polars_provider
        self._storage_options = storage_options or {}
        self._uri_prefix = uri_prefix

    @property
    def kind(self) -> SourceKind:
        return self._kind

    @property
    def uri(self) -> str:
        return f"{self._uri_prefix}{self._base_path}"

    @property
    def filesystem(self) -> Any:
        return self._filesystem

    @property
    def storage_options(self) -> dict[str, Any]:
        return self._storage_options

    @property
    def polars_provider(self) -> Optional[PolarsCredentialProvider]:
        return self._polars_provider

    def join(self, *path_segments: str) -> str:
        segments = [s.strip("/") for s in path_segments if s]
        if not segments:
            return self.uri
        return f"{self.uri}/{'/'.join(segments)}"

    # path contract: methods ACCEPT paths relative to the store (or one of
    # the store's own URIs); everything they RETURN is a full URI that any
    # engine can consume directly. A URI from a DIFFERENT store is an error.

    def _relative(self, path: str) -> str:
        own = f"{self.uri}/"
        if path.startswith(own):
            return path[len(own):]
        if path == self.uri:
            return ""
        if "://" in path:
            raise ValueError(
                f"{path!r} is not under this store ({self.uri!r}). Pass a "
                f"path relative to the store, or build a DataStore for that "
                f"location.")
        return path

    def _full(self, relative_path: str) -> str:
        return (f"{self._fs_base}/{relative_path.strip('/')}"
                if relative_path else self._fs_base)

    def _to_uri(self, fs_path: str) -> str:
        bare = fs_path.lstrip("/")
        return (f"/{bare}" if self._uri_prefix == "/"
                else f"{self._uri_prefix}{bare}")

    def exists(self, relative_path: str = "") -> bool:
        return self._filesystem.exists(self._full(self._relative(relative_path)))

    def ls(self, relative_path: str = "") -> list[str]:
        found = self._filesystem.ls(
            self._full(self._relative(relative_path)), detail=False)
        return [self._to_uri(f) for f in found]

    def glob(self, glob_pattern: str) -> list[str]:
        found = self._filesystem.glob(self._full(self._relative(glob_pattern)))
        return [self._to_uri(f) for f in found]

    def open(self, relative_path: str = "", file_mode: str = "rb") -> IO[bytes]:
        return self._filesystem.open(
            self._full(self._relative(relative_path)), file_mode)


_LOCAL_HINT = re.compile(r"[/\\.]")      # a separator or a dot


def classify_source(source_path: str) -> SourceKind:
    """Classify by URI *scheme*, never by a leading slash.

    Ordering fix vs. the draft: a bare token is only tried as a production lake
    dataset id when it can't plausibly be a local path — dataset ids and
    bare relative dir names are both schemeless tokens, so LOCAL must
    win when the token contains a separator/dot or exists locally.
    """
    scheme = urlsplit(source_path).scheme
    if scheme in ("", "file"):
        bare = not _LOCAL_HINT.search(source_path)
        if bare and not Path(source_path).exists() and _is_dataset_id(source_path):
            return SourceKind.PRODUCTION_LAKE_DATASET
        return SourceKind.LOCAL
    if scheme in ("s3", "s3a"):
        if _is_staging_lake_path(source_path):
            return SourceKind.STAGING_LAKE
        return SourceKind.GENERIC_S3
    return SourceKind.GENERIC_S3         # unknown scheme: generic fsspec


def _is_dataset_id(token: str) -> bool:
    from kubeflow_utils import lake_broker
    return lake_broker.is_dataset_id(token)          # False when sdk absent


def _is_staging_lake_path(source_path: str) -> bool:
    from kubeflow_utils import lake_broker
    return lake_broker.is_staging_lake_path(source_path)


def strip_scheme(source_path: str) -> str:
    split = urlsplit(source_path)
    return f"{split.netloc}{split.path}" if split.scheme else source_path


def staging_profile_for_path(source_path: str) -> str:
    """Longest-prefix match of the path against configured sidecar
    profile roots. Raises rather than defaulting — fetching credentials
    for the wrong staging lake is worse than a loud failure."""
    from kubeflow_utils import lake_broker
    bare_path = strip_scheme(source_path).lstrip("/")
    location_to_profile = lake_broker.sidecar_profile_mapping()
    matching_roots = [
        location for location in location_to_profile
        if bare_path == location or bare_path.startswith(f"{location}/")
    ]
    if not matching_roots:
        raise ValueError(f"No sidecar profile's root matches {source_path!r}")
    return location_to_profile[max(matching_roots, key=len)]


def open_data_store(source_path: str) -> StoreLike:
    """Build the right DataStore for source_path: no creds for local, the
    default IAM chain for generic S3, sidecar creds for the staging lake,
    a broker-issued dataset resource for production-lake dataset ids.
    All platform calls route through kubeflow_utils.lake_broker."""
    import fsspec
    kind = classify_source(source_path)

    if kind is SourceKind.LOCAL:
        return FsspecDataStore(
            fsspec.filesystem("file"),
            str(Path(strip_scheme(source_path)).absolute()),
            kind=kind,
            uri_prefix="/",
        )

    if kind is SourceKind.GENERIC_S3:
        scheme = urlsplit(source_path).scheme or "s3"
        return FsspecDataStore(
            fsspec.filesystem(scheme),
            strip_scheme(source_path),
            kind=kind,
            uri_prefix=f"{scheme}://",
        )

    if kind is SourceKind.STAGING_LAKE:
        from kubeflow_utils import lake_broker
        sidecar = lake_broker.staging_sidecar(
            profile=staging_profile_for_path(source_path))
        deeper = strip_scheme(source_path).lstrip("/")
        root = sidecar.location.lstrip("/")
        base = deeper if deeper.startswith(root) else root
        return FsspecDataStore(
            sidecar.get_s3fs(), base, kind=kind,
            polars_provider=getattr(sidecar, "polars_provider", None),
            storage_options=getattr(sidecar, "storage_options", {}) or {},
            uri_prefix="s3://",
        )

    # PRODUCTION_LAKE_DATASET
    from kubeflow_utils import lake_broker
    dataset = lake_broker.production_dataset(dataset_id=source_path)
    return FsspecDataStore(
        dataset.get_s3fs(), dataset.location.lstrip("/"),
        kind=SourceKind.PRODUCTION_LAKE_DATASET,
        polars_provider=getattr(dataset, "polars_provider", None),
        storage_options=getattr(dataset, "storage_options", {}) or {},
        uri_prefix="s3://",
    )
