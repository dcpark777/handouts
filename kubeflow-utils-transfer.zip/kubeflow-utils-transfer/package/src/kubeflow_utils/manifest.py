"""kubeflow_utils.manifest — the declaration classes behind pipelines/pipeline.py.

A manifest module constructs DATA: Dataset / Step / parallel / Resources /
Pipeline. Pipeline.__post_init__ runs the load-time checks, so authoring
mistakes fail at import with an error naming both sides.

Execution model (ratified): steps is an ORDERED list — list order IS
execution order with stage-barrier semantics; parallel(...) entries run
concurrently. reads/writes never decide order: they drive runtime pre/post
enforcement and the order-vs-dataflow consistency check here.
"""
from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Sequence, Union


class ManifestError(ValueError):
    """The manifest contradicts itself or the code it references."""


@dataclass(frozen=True)
class Dataset:
    """A located, named piece of data. ONE location field:
    relative (no scheme)   -> joined onto the run's base_path (portable)
    scheme'd or absolute   -> standalone, fixed location
    {param} placeholders are formatted with run params at runtime."""
    name: str
    location: str

    def resolve(self, params: dict[str, Any]) -> str:
        try:
            located = self.location.format(**params)
        except KeyError as e:
            raise ManifestError(
                f"dataset {self.name!r} location needs param {e.args[0]!r} "
                f"which is not defined on the pipeline") from None
        if "://" in located or located.startswith("/"):
            return located.rstrip("/")
        base = str(params.get("base_path", "")).rstrip("/")
        if not base:
            raise ManifestError(
                f"dataset {self.name!r} is base-relative but no base_path "
                f"param was provided")
        return f"{base}/{located}".rstrip("/")


@dataclass(frozen=True)
class Resources:
    cpu: Optional[str] = None
    memory: Optional[str] = None
    image: Optional[str] = None
    pip: tuple[str, ...] = ()


@dataclass
class Step:
    fn: Callable[..., Any]
    reads: Sequence[Dataset] = ()
    writes: Sequence[Dataset] = ()
    outputs: Sequence[str] = ()              # scalar outputs (KFP param passing)
    resources: Resources = field(default_factory=Resources)
    args: dict[str, Union[Dataset, str]] = field(default_factory=dict)
    # args: per-step override when a signature name doesn't match a
    # dataset/param name, e.g. {"source": graph, "target": archive}

    @property
    def name(self) -> str:
        return self.fn.__name__

    @property
    def dotted_path(self) -> str:
        return f"{self.fn.__module__}:{self.fn.__qualname__}"


class parallel(tuple):
    """Steps that run concurrently as one stage: parallel(a, b, c)."""
    def __new__(cls, *steps: Step):
        return super().__new__(cls, steps)


StageEntry = Union[Step, parallel]


@dataclass
class Pipeline:
    name: str
    params: dict[str, Any]                   # name -> type | (type, default)
    steps: list[StageEntry]
    env: dict[str, str] = field(default_factory=dict)   # -> KUBEFLOW_UTILS_* at compile

    def __post_init__(self) -> None:
        self.param_types: dict[str, type] = {}
        self.param_defaults: dict[str, Any] = {}
        for name, spec in self.params.items():
            if isinstance(spec, tuple):
                self.param_types[name], self.param_defaults[name] = spec
            else:
                self.param_types[name] = spec
        self._check()

    # ── derived views ────────────────────────────────────────────────
    @property
    def stages(self) -> list[tuple[Step, ...]]:
        return [tuple(e) if isinstance(e, parallel) else (e,)
                for e in self.steps]

    @property
    def flat_steps(self) -> list[Step]:
        return [s for stage in self.stages for s in stage]

    @property
    def datasets(self) -> dict[str, Dataset]:
        found: dict[str, Dataset] = {}
        for step in self.flat_steps:
            for ds in (*step.reads, *step.writes):
                if ds.name in found and found[ds.name] is not ds:
                    raise ManifestError(
                        f"two different Dataset objects share the name "
                        f"{ds.name!r} — datasets must be single instances")
                found[ds.name] = ds
        return found

    # ── the load-time checks ─────────────────────────────────────────
    def _check(self) -> None:
        seen_names: set[str] = set()
        written: set[str] = set()
        scalars: set[str] = set()
        _ = self.datasets                              # duplicate-name check
        self._check_locations()

        for stage in self.stages:
            for step in stage:
                if step.name in seen_names:
                    raise ManifestError(f"step {step.name!r} appears twice")
                seen_names.add(step.name)
                self._check_signature(step, scalars)
                for ds in step.reads:
                    external = "://" in ds.location or ds.location.startswith("/")
                    if ds.name not in written and not external:
                        raise ManifestError(
                            f"step {step.name!r} reads {ds.name!r} before any "
                            f"earlier step writes it (order-vs-dataflow): move "
                            f"the writer earlier or mark the dataset external "
                            f"by giving it an absolute/scheme'd location")
            # stage barrier: writes visible only after the whole stage
            for step in stage:
                written.update(ds.name for ds in step.writes)
                scalars.update(step.outputs)

    def _check_locations(self) -> None:
        """Location templates are statically checkable: every {placeholder}
        must be a declared param (or an upstream scalar output), and any
        base-relative dataset needs a base_path param to join onto."""
        import string
        scalar_names = {o for s in self.flat_steps for o in s.outputs}
        needs_base = []
        for ds in self.datasets.values():
            for _, placeholder, _, _ in string.Formatter().parse(ds.location):
                if placeholder and placeholder not in self.param_types \
                        and placeholder not in scalar_names:
                    raise ManifestError(
                        f"dataset {ds.name!r} location references "
                        f"{{{placeholder}}} which is neither a pipeline "
                        f"param nor a step output — typo, or add it to "
                        f"Pipeline params")
            if "://" not in ds.location and not ds.location.startswith("/"):
                needs_base.append(ds.name)
        if needs_base and "base_path" not in self.param_types:
            raise ManifestError(
                f"dataset(s) {needs_base} are base-relative but the "
                f"pipeline declares no base_path param to join them onto — "
                f"add params={{'base_path': str, ...}} or make their "
                f"locations absolute/scheme'd")

    def _check_signature(self, step: Step, upstream_scalars: set[str]) -> None:
        sig = inspect.signature(step.fn)
        dataset_names = {ds.name for ds in (*step.reads, *step.writes)}
        mapped = set(step.args)
        for pname, param in sig.parameters.items():
            if pname in mapped or pname in dataset_names:
                continue
            if pname in self.param_types or pname in upstream_scalars:
                continue
            if param.default is not inspect.Parameter.empty:
                continue
            raise ManifestError(
                f"step {step.name!r}: signature parameter {pname!r} matches "
                f"no dataset on this step, no pipeline param, and no upstream "
                f"output. Rename one side, or map it with "
                f"args={{{pname!r}: <Dataset or param name>}}")
        for target in step.args:
            if target not in sig.parameters:
                raise ManifestError(
                    f"step {step.name!r}: args maps {target!r} but "
                    f"{step.name}() has no such parameter")
