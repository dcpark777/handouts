"""kubeflow_utils.validate — semantic checks + teaching lints.

Pipeline.__post_init__ already enforces the hard rules at import (name
matching, order-vs-dataflow, duplicates). This module adds the sweep and
the AST lints, with error messages that TEACH the guideline they enforce.
Run: `kubeflow-utils validate pipelines/pipeline.py` (also in CI / pre-commit).
"""
from __future__ import annotations

import ast
import importlib
import inspect
from pathlib import Path

from kubeflow_utils.manifest import Pipeline


def validate(pipeline: Pipeline, steps_package: str = "") -> list[str]:
    """Returns human-readable findings; hard errors already raised at
    manifest import. Findings are warnings unless prefixed ERROR."""
    findings: list[str] = []
    findings += _unused(pipeline)
    if steps_package:
        findings += steps_sweep(pipeline, steps_package)
    for step in pipeline.flat_steps:
        findings += lint_step_source(step.fn)
    return findings


def _unused(pipeline: Pipeline) -> list[str]:
    consumed: set[str] = set()
    for step in pipeline.flat_steps:
        for pname in inspect.signature(step.fn).parameters:
            consumed.add(step.args.get(pname, pname) if isinstance(
                step.args.get(pname, pname), str) else pname)
        for ds in (*step.reads, *step.writes):
            consumed.update(
                p for p in pipeline.param_types if f"{{{p}}}" in ds.location)
    consumed.add("base_path")
    return [f"pipeline param {p!r} is consumed by no step"
            for p in pipeline.param_types if p not in consumed]


def steps_sweep(pipeline: Pipeline, steps_package: str) -> list[str]:
    """Bidirectional 1:1 check between mypackage/steps/ and the manifest."""
    findings = []
    package = importlib.import_module(steps_package)
    step_fns = {s.fn for s in pipeline.flat_steps}
    root = Path(package.__file__).parent
    for module_path in sorted(root.glob("[!_]*.py")):
        module = importlib.import_module(f"{steps_package}.{module_path.stem}")
        public = [o for name, o in vars(module).items()
                  if callable(o) and not name.startswith("_")
                  and getattr(o, "__module__", "") == module.__name__]
        for fn in public:
            if fn not in step_fns:
                findings.append(
                    f"{module.__name__}.{fn.__name__} is a public function "
                    f"in steps/ but appears in no manifest — entrypoints "
                    f"live in steps/; helpers belong in lib/")
    for step in pipeline.flat_steps:
        if not step.fn.__module__.startswith(steps_package):
            findings.append(
                f"ERROR step {step.name!r} resolves to {step.fn.__module__} "
                f"— manifest steps must live under {steps_package}/")
    return findings


_LINTS = {
    "os.path": ("step code uses os.path.{attr} — os.path lies about object "
                "storage (exists() is silently False on s3://). Use "
                "DataStore(path).{hint} or plain string paths."),
    "os.environ": ("mypackage reads os.environ — environment awareness "
                   "belongs to kubeflow-utils's providers (RUNTIME_MODE), never "
                   "user code. Take the value as a function parameter."),
}


def lint_step_source(fn) -> list[str]:
    try:
        source = inspect.getsource(inspect.getmodule(fn))
    except (OSError, TypeError):
        return []
    findings = []
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if not isinstance(node, ast.Attribute):
            continue
        base = node.value
        if isinstance(base, ast.Attribute) and isinstance(base.value, ast.Name) \
                and base.value.id == "os" and base.attr == "path":
            hint = {"exists": "exists()", "join": "join()"}.get(node.attr, "uri")
            findings.append(f"{fn.__module__}:{node.lineno} " +
                            _LINTS["os.path"].format(attr=node.attr, hint=hint))
        if isinstance(base, ast.Name) and base.id == "os" \
                and node.attr == "environ":
            findings.append(f"{fn.__module__}:{node.lineno} " +
                            _LINTS["os.environ"])
    return findings
