"""kubeflow_utils.snowflake — Snowflake(...).get_connection(): the auth resolver.

Two auth paths, one call site:

  local  : token/keypair from the developer's environment (SNOWFLAKE_*
           env vars / local secret file) — a CREDENTIAL, never code.
  cluster: Vault -> client_id + client_secret -> OAuth token -> connection.
           Vault coordinates are PIPELINE-level (they differ between
           pipelines): declared on Pipeline(...), stamped as KUBEFLOW_UTILS_*
           env at compile, read here — user code never sees them.

Tokens are cached per process with an expiry margin; conn_kwargs merge
{**base, **user} — user wins, same rule as Spark.
"""
from __future__ import annotations

import time
from typing import Any, Optional

from kubeflow_utils.runtime import is_cluster, pipeline_env

_TOKEN_CACHE: dict[str, tuple[str, float]] = {}
_EXPIRY_MARGIN_S = 300


class Snowflake:
    def __init__(self, **conn_kwargs: Any) -> None:
        self._conn_kwargs = conn_kwargs

    def get_connection(self) -> Any:
        import snowflake.connector

        base = self._cluster_auth() if is_cluster() else self._local_auth()
        merged = {**base, **self._conn_kwargs}          # user wins
        return snowflake.connector.connect(**merged)

    # ── auth layers ─────────────────────────────────────────────────
    def _local_auth(self) -> dict[str, Any]:
        import os
        return {
            "account":       os.environ["SNOWFLAKE_ACCOUNT"],
            "user":          os.environ["SNOWFLAKE_USER"],
            "authenticator": "oauth",
            "token":         os.environ["SNOWFLAKE_TOKEN"],   # dev-issued
        }

    def _cluster_auth(self) -> dict[str, Any]:
        return {
            "account":       pipeline_env("SNOWFLAKE_ACCOUNT"),
            "user":          pipeline_env("SNOWFLAKE_USER"),
            "authenticator": "oauth",
            "token":         _oauth_token(),
        }


def _oauth_token() -> str:
    """Vault client_id/secret -> OAuth token, cached with expiry margin."""
    vault_path = pipeline_env("VAULT_PATH")
    cached = _TOKEN_CACHE.get(vault_path)
    if cached and cached[1] - time.time() > _EXPIRY_MARGIN_S:
        return cached[0]

    client_id, client_secret = _read_vault(vault_path)
    token, expires_at = _request_token(
        token_url=pipeline_env("OAUTH_TOKEN_URL"),
        client_id=client_id, client_secret=client_secret)
    _TOKEN_CACHE[vault_path] = (token, expires_at)
    return token


def _read_vault(vault_path: str) -> tuple[str, str]:
    import hvac                                       # env's vault client
    client = hvac.Client()                            # addr/auth from pod env
    secret = client.secrets.kv.read_secret_version(path=vault_path)
    data = secret["data"]["data"]
    return data["client_id"], data["client_secret"]


def _request_token(*, token_url: str, client_id: str,
                   client_secret: str) -> tuple[str, float]:
    import requests
    response = requests.post(token_url, data={
        "grant_type": "client_credentials",
        "client_id": client_id, "client_secret": client_secret})
    response.raise_for_status()
    payload = response.json()
    return payload["access_token"], time.time() + float(payload["expires_in"])
