"""kubeflow_utils.helpers — optional, composable, never mandatory.

SqlRunner is the one shipped helper (recurring pull pattern earned it):
the validated sqlrunner implementation, vendored. Its `output` accepts a
plain string path — resolved through DataStore internally — matching the
authoring rule that datasets travel as strings.

    SqlRunner(connection_factory=Snowflake().get_connection,
              output=raw, sql_root="sql", queries=[...],
              params={...}, concurrency=8, skip_existing=True).run()

Everything else you might reach for (rename_parts, publish shapes,
custom writes) is deliberately YOUR code: kubeflow-utils ships resolvers and
structure, never IO opinions.
"""
from kubeflow_utils.helpers._sqlrunner import (   # noqa: F401
    EffectiveDates, SqlQuery, SqlRunner, date_window, write_parquet,
)
