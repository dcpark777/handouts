"""sqlrunner — threaded Jinja SQL pulls to parquet, on one IO layer.

    from sqlrunner import SqlQuery, SqlRunner, EffectiveDates
    from sqlrunner import open_data_store, date_window

    store = open_data_store(data_path)         # local, s3://, staging_lake, or
                                               # a production-lake dataset id
    runner = SqlRunner(
        connection_factory=create_snowflake_conn,
        output=store,                          # or just the path/uri string
        sql_root=sql_path,
        queries=[
            SqlQuery(f"{dt}.sql.j2", dataset=dt,
                     vars=date_window(snap_dt, days),
                     output_file=f"{snap_dt}_data_{dt}.parquet")
            for dt, days in data_types.items()
        ],
        params={"snap_date": snap_dt},
        concurrency=8,
        post_query=EffectiveDates(EFFECTIVE_DATE_QUERIES, snap_dt),
        skip_existing=not rerun,
    )
    urls = runner.run()

Storage is fs_io's DataStore (the only storage contract in this
package): local / generic S3 / staging lake / production lake collapse into one
fsspec-backed implementation, and writes stay engine-native — polars
writes parquet with the store's credential_provider (guardrail: the
store never grows dataframe methods).

Write atomicity, by kind: LOCAL = temp + os.replace; remote = direct
engine write (S3 PUT is atomic per key). Either way a dead run never
leaves a final-named partial file, so skip_existing is trustworthy.
The effective-dates log appends locally and becomes one distinct
object per run on remote stores (backend-portable, concurrency-safe).
"""
from __future__ import annotations

import datetime
import re
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional, Sequence, Union

from kubeflow_utils.fs_io import (StoreLike, FsspecDataStore, SourceKind, classify_source,
                    staging_profile_for_path, open_data_store)

__all__ = ["SqlQuery", "SqlRunner", "SqlRunError", "EffectiveDates",
           "date_window", "StoreLike", "FsspecDataStore", "SourceKind",
           "classify_source", "open_data_store", "staging_profile_for_path"]


class SqlRunError(RuntimeError):
    """One or more queries failed; the message is the full report."""


# ─────────────────────────────── queries ───────────────────────────────

@dataclass
class SqlQuery:
    """One templated query -> one dataset -> one parquet file.

    Template variables come from two places:
      * SqlRunner(params=...) — shared; every query sees them
      * SqlQuery(vars=...)    — this query only; wins over params on clashes
    Typical: params carries run-scoped values (snap_date); vars carries
    query-specific ones (this query's date_window(...), table names).
    """

    template: str                           # template path under sql_root (in)
    dataset: Optional[str] = None           # dataset name; default: template stem
    vars: dict[str, Any] = field(default_factory=dict)   # per-query jinja vars
    output_file: Optional[str] = None       # output file name (out);
                                            # default: "<dataset>.parquet"

    def __post_init__(self) -> None:
        if self.dataset is None:
            self.dataset = re.sub(r"\.sql(\.j2)?$", "", Path(self.template).name)
        if self.output_file is None:
            self.output_file = f"{self.dataset}.parquet"

    def render_context(self, params: dict[str, Any]) -> dict[str, Any]:
        """params + per-query vars (per-query wins)."""
        return {**params, **self.vars}


def date_window(snap_date: str, lookback_days: int) -> dict[str, str]:
    """Jinja vars for windowed queries: end_date = snap_date,
    start_date = end - lookback_days."""
    end = datetime.date.fromisoformat(str(snap_date))
    start = end - datetime.timedelta(days=lookback_days)
    return {"start_date": start.isoformat(), "end_date": end.isoformat()}


# ─────────────────────────────── writes ────────────────────────────────
# Engine-native, atomic per kind. The one place the runner writes bytes.

def write_parquet(store: StoreLike, df: Any, relative_path: str) -> None:
    if store.kind is SourceKind.LOCAL:
        final = Path(store.join(relative_path))
        final.parent.mkdir(parents=True, exist_ok=True)
        tmp = final.parent / f".{final.name}.tmp-{uuid.uuid4().hex[:8]}"
        try:
            df.write_parquet(tmp)
            tmp.replace(final)              # atomic on the same filesystem
        finally:
            if tmp.exists():
                tmp.unlink()
        return
    target = store.join(relative_path)
    if store.polars_provider is not None:
        df.write_parquet(target, credential_provider=store.polars_provider)
    elif store.kind is SourceKind.GENERIC_S3 and target.startswith("s3"):
        df.write_parquet(target)            # polars' own S3 chain
    else:                                   # any other fsspec backend
        with store.open(relative_path, file_mode="wb") as f:
            df.write_parquet(f)


def write_text(store: StoreLike, relative_path: str, text: str) -> None:
    if store.kind is SourceKind.LOCAL:
        p = Path(store.join(relative_path))
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
        return
    with store.open(relative_path, file_mode="wb") as f:
        f.write(text.encode())


# ─────────────────────────────── runner ────────────────────────────────

def _log():
    from kubeflow_utils import get_logger
    return get_logger("kubeflow_utils.sqlrunner")


def _polars_fetch(conn: Any, sql: str) -> Any:
    import polars as pl
    return pl.read_database(sql, conn)


class _ThreadConnections:
    """One connection per worker thread, closed together after the run."""

    def __init__(self, factory: Callable[[], Any]):
        self._factory = factory
        self._local = threading.local()
        self._all: list[Any] = []
        self._lock = threading.Lock()

    def get(self) -> Any:
        if not hasattr(self._local, "conn"):
            conn = self._factory()
            with self._lock:
                self._all.append(conn)
            self._local.conn = conn
        return self._local.conn

    def close_all(self) -> None:
        for conn in self._all:
            try:
                conn.close()
            except Exception:               # noqa: BLE001  best effort
                pass
        self._all.clear()


class SqlRunner:
    """Renders, executes, and lands a list of SqlQuery as parquet files."""

    def __init__(
        self,
        connection_factory: Callable[[], Any],
        output: Union[str, Path, DataStore],
        sql_root: Union[str, Path] = "sql",
        queries: Sequence[Union[str, SqlQuery]] = (),
        params: Optional[dict] = None,
        fetch: Callable[[Any, str], Any] = _polars_fetch,
        concurrency: int = 5,
        post_query: Optional[Callable[[Any, SqlQuery, str], None]] = None,
        # post_query may also expose .finish(store) — called once after the
        # run (even on failure). EffectiveDates implements this protocol.
        skip_existing: bool = False,
    ):
        self.connection_factory = connection_factory
        self.store: StoreLike = (
            output if hasattr(output, "join") and hasattr(output, "exists")
            else open_data_store(str(output)))
        self.queries = [SqlQuery(q) if isinstance(q, str) else q
                        for q in queries]
        self.params = dict(params or {})
        self.fetch = fetch
        self.concurrency = concurrency
        self.post_query = post_query
        self.skip_existing = skip_existing
        self._jinja = _strict_jinja(Path(sql_root))

    # -- public pieces (also handy on their own in a notebook) ---------

    def render(self, query: Union[str, SqlQuery]) -> str:
        """Render one query's SQL without executing it."""
        q = SqlQuery(query) if isinstance(query, str) else query
        import jinja2
        try:
            template = self._jinja.get_template(q.template)
            return template.render(**q.render_context(self.params))
        except jinja2.UndefinedError as e:
            var = re.search(r"'(\w+)' is undefined", str(e))
            raise SqlRunError(
                f"template '{q.template}' references "
                f"'{var.group(1) if var else e}' which is not in params or "
                f"vars. Add it to SqlRunner(params=...) or SqlQuery(vars=...)."
            ) from e

    # -- the run --------------------------------------------------------

    def run(self, queries: Optional[Sequence[Union[str, SqlQuery]]] = None,
            ) -> dict[str, str]:
        """Execute the configured queries (or the given list); return
        {dataset: url}."""
        if queries is None:
            qs = self.queries
        else:
            qs = [SqlQuery(q) if isinstance(q, str) else q for q in queries]
        if not qs:
            raise SqlRunError(
                "nothing to run: pass queries=[...] to SqlRunner(...) "
                "or to run().")
        urls, pending = self._skip_existing(qs)
        if not pending:
            return urls

        conns = _ThreadConnections(self.connection_factory)
        failures: list[tuple[str, BaseException]] = []
        lock = threading.Lock()

        def pull(q: SqlQuery) -> None:
            try:
                urls[q.dataset] = self._pull_one(q, conns.get())
            except BaseException as e:      # noqa: BLE001
                with lock:
                    failures.append((q.dataset, e))

        try:
            with ThreadPoolExecutor(max_workers=self.concurrency) as pool:
                list(pool.map(pull, pending))   # submitted in list order
        finally:
            conns.close_all()
            finish = getattr(self.post_query, "finish", None)
            if finish is not None:
                finish(self.store)              # runs even on failure

        if failures:
            report = "\n".join(f"  - {d}: {e!r}" for d, e in failures)
            raise SqlRunError(
                f"{len(failures)}/{len(pending)} queries failed:\n{report}")
        return urls

    # -- steps of the run, in reading order ------------------------------

    def _skip_existing(
        self, qs: list[SqlQuery],
    ) -> tuple[dict[str, str], list[SqlQuery]]:
        urls: dict[str, str] = {}
        pending: list[SqlQuery] = []
        for q in qs:
            if self.skip_existing and self.store.exists(q.output_file):
                urls[q.dataset] = self.store.join(q.output_file)
                _log().info("skip %s: output exists", q.dataset)
            else:
                pending.append(q)
        return urls, pending

    def _pull_one(self, q: SqlQuery, conn: Any) -> str:
        sql = self.render(q)
        write_text(self.store, f"_rendered/{q.dataset}.sql", sql)
        df = self.fetch(conn, sql)
        write_parquet(self.store, df, q.output_file)
        if self.post_query is not None:
            self.post_query(conn, q, q.dataset)
        print(f"[sqlrunner] {q.dataset}: {len(df)} rows")
        return self.store.join(q.output_file)


def _strict_jinja(root: Path):
    import jinja2
    return jinja2.Environment(
        loader=jinja2.FileSystemLoader(str(root)),
        undefined=jinja2.StrictUndefined,
        autoescape=False,
        keep_trailing_newline=True,
    )


# ─────────────────────────── effective dates ───────────────────────────

class EffectiveDates:
    """post_query probe: runs each dataset's effective-date query on the
    SAME thread + live connection as its pull, buffering thread-safely.
    The runner calls finish(store) after the run (success or failure).
    Local stores append to effective_dates.log; remote stores get one
    distinct object per run (append is local-only on object storage)."""

    def __init__(self, queries: dict[str, str], snap_dt: str):
        self.queries = queries      # {dataset: probe sql with {snap_date}}
        self.snap_dt = snap_dt
        self._lines: list[str] = []
        self._lock = threading.Lock()

    def __call__(self, conn: Any, query: SqlQuery, dataset: str) -> None:
        probe_sql = self.queries.get(dataset)
        if probe_sql is None:
            return
        import polars as pl
        rows = pl.read_database(probe_sql.format(snap_date=self.snap_dt), conn)
        rows.columns = [c.lower() for c in rows.columns]
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            self._lines += [
                f"{stamp} | snap_date={self.snap_dt} | data_type={dataset}"
                f" | source_table={row['table_name']}"
                f" | effective_date={row['effective_date']}"
                for row in rows.iter_rows(named=True)
            ]

    def finish(self, store: DataStore) -> None:
        if not self._lines:
            return
        block = "\n".join(self._lines) + "\n"
        if store.kind is SourceKind.LOCAL:
            log = Path(store.join("effective_dates.log"))
            log.parent.mkdir(parents=True, exist_ok=True)
            with open(log, "a") as f:
                f.write(block)
        else:                       # one distinct object per run
            run_id = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            write_text(store,
                       f"effective_dates/{self.snap_dt}_{run_id}.log", block)
        self._lines.clear()
