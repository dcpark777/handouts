"""kubeflow_utils.runtime — the ONE ambient contract between environments.

Everything environment-dependent in kubeflow-utils keys off two things:

  1. RUNTIME_MODE     absent/"" -> local (notebook, laptop, tests)
                      "kfp"     -> cluster component
  2. KUBEFLOW_UTILS_* vars   pipeline-level provider config, stamped onto every
                      component's env AT COMPILE TIME from the Pipeline
                      declaration. Local runs never need them (local auth
                      paths don't use them); user code never reads them.

User code imports NOTHING from this module. Providers do.
"""
from __future__ import annotations

import os

MODE_LOCAL = "local"
MODE_KFP = "kfp"


def runtime_mode() -> str:
    return os.environ.get("RUNTIME_MODE", "").strip() or MODE_LOCAL


def is_cluster() -> bool:
    return runtime_mode() == MODE_KFP


def pipeline_env(key: str, default: str | None = None) -> str:
    """Read a KUBEFLOW_UTILS_<KEY> value stamped by compile (cluster) or exported
    by the user's shell/.env (local, rarely needed)."""
    value = os.environ.get(f"KUBEFLOW_UTILS_{key}", default)
    if value is None:
        raise RuntimeError(
            f"KUBEFLOW_UTILS_{key} is not set. On KFP it is stamped at compile from "
            f"the Pipeline declaration; locally export it only if the local "
            f"auth path needs it."
        )
    return value
