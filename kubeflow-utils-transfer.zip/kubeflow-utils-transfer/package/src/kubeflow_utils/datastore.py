"""kubeflow_utils.datastore — DataStore(path): the path+credential resolver.

A thin facade over the validated fs_io implementation (vendored,
unchanged, as kubeflow_utils.fs_io). One call, one rule:

    store = DataStore("s3://bucket/prefix")     # or local path, or
    store = DataStore("prodlake://<dataset_id>") # brokered dataset

classify-by-scheme decides the backend; credentials are resolved lazily
(first filesystem/storage_options access), never at construction — so
building a store for a dataset the run never touches costs nothing.

Surface (pure resolver — guardrail #1: NO df read/write methods):
    .uri  .filesystem  .storage_options  .polars_provider
    .join(*parts)  .exists([rel])  .ls([rel])  .glob(pattern)  .open(rel)

Path contract: methods ACCEPT store-relative paths (or the store's own
URIs); everything RETURNED (uri, join, ls, glob) is a full URI any
engine reads directly. Type-annotate stores as StoreLike.
"""
from __future__ import annotations

from kubeflow_utils.fs_io import (  # noqa: F401  (re-exported surface)
    SourceKind,
    StoreLike,
    classify_source,
    open_data_store as _open_data_store,
)


def DataStore(path: str):
    """Resolve `path` to a ready store. Named like a class on purpose:
    call sites read as construction, and the return duck-types the
    DataStore protocol."""
    return _open_data_store(path)
